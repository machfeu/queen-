"""
test_benchmark.py — Tests for LOT 2: benchmark runner + fitness differentiation.

Run: python3 test_benchmark.py
"""

import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from queen_core.evolution.bench_runner import (
    run_benchmarks,
    bench_no_dangerous_patterns,
    bench_docstrings_present,
    bench_no_syntax_errors,
    bench_error_handling,
    bench_function_complexity,
)
from queen_core.evolution.fitness import compute_fitness


def _make_candidate(tmpdir, files):
    """Create a fake candidate_src with given {path: content} files."""
    src = os.path.join(tmpdir, "candidate")
    for rel, content in files.items():
        p = os.path.join(src, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w") as f:
            f.write(content)
    return src


# ── bench_runner tests ──────────────────────────────────────────────

def test_clean_code_scores_high():
    """Well-documented, clean code should score near 1.0."""
    tmpdir = tempfile.mkdtemp()
    try:
        src = _make_candidate(tmpdir, {
            "queen_core/good.py": '''
"""Good module."""

def process_data(path: str) -> dict:
    """Process data from path and return results."""
    try:
        with open(path, "r") as f:
            data = f.read()
        return {"ok": True, "data": data}
    except Exception as e:
        return {"ok": False, "error": str(e)}

class DataProcessor:
    """Processes data safely."""

    def run(self):
        """Execute processing."""
        return True
''',
        })
        score = bench_no_dangerous_patterns(src)
        assert score == 1.0, f"Expected 1.0, got {score}"
        doc_score = bench_docstrings_present(src)
        assert doc_score >= 0.8, f"Expected >= 0.8, got {doc_score}"
        syntax_score = bench_no_syntax_errors(src)
        assert syntax_score == 1.0, f"Expected 1.0, got {syntax_score}"
        err_score = bench_error_handling(src)
        assert err_score >= 0.5, f"Expected >= 0.5, got {err_score}"
        print("PASS: test_clean_code_scores_high")
    finally:
        shutil.rmtree(tmpdir)


def test_dangerous_code_scores_low():
    """Code with eval/exec should score lower."""
    tmpdir = tempfile.mkdtemp()
    try:
        src = _make_candidate(tmpdir, {
            "queen_core/bad.py": '''
import os
def do_thing(x):
    os.system("rm -rf /")
    eval(x)
    exec(x)
''',
        })
        score = bench_no_dangerous_patterns(src)
        assert score < 0.7, f"Expected < 0.7, got {score}"
        print("PASS: test_dangerous_code_scores_low")
    finally:
        shutil.rmtree(tmpdir)


def test_no_docstrings_penalized():
    """Code without docstrings should score lower."""
    tmpdir = tempfile.mkdtemp()
    try:
        src = _make_candidate(tmpdir, {
            "queen_core/nodoc.py": '''
def func_a(): pass
def func_b(): pass
class MyClass: pass
''',
        })
        score = bench_docstrings_present(src)
        assert score < 0.5, f"Expected < 0.5, got {score}"
        print("PASS: test_no_docstrings_penalized")
    finally:
        shutil.rmtree(tmpdir)


def test_syntax_error_detected():
    """Syntax error should lower the score."""
    tmpdir = tempfile.mkdtemp()
    try:
        src = _make_candidate(tmpdir, {
            "queen_core/ok.py": "x = 1\n",
            "queen_core/broken.py": "def f(\n",  # syntax error
        })
        score = bench_no_syntax_errors(src)
        assert score == 0.5, f"Expected 0.5, got {score}"  # 1/2 files ok
        print("PASS: test_syntax_error_detected")
    finally:
        shutil.rmtree(tmpdir)


def test_run_benchmarks_aggregate():
    """run_benchmarks returns a coherent aggregate."""
    tmpdir = tempfile.mkdtemp()
    try:
        src = _make_candidate(tmpdir, {
            "queen_core/ok.py": '"""Module."""\ndef greet():\n    """Say hi."""\n    return "hi"\n',
        })
        result = run_benchmarks(src)
        assert "benchmark_score" in result
        assert 0.0 <= result["benchmark_score"] <= 1.0
        assert result["benchmark_count"] >= 5  # at least the builtins
        assert "no_dangerous_patterns" in result["benchmark_results"]
        print(f"PASS: test_run_benchmarks_aggregate (score={result['benchmark_score']:.3f})")
    finally:
        shutil.rmtree(tmpdir)


def test_user_benchmarks_discovered():
    """User benchmarks from benchmarks/ dir are discovered and run."""
    tmpdir = tempfile.mkdtemp()
    try:
        src = _make_candidate(tmpdir, {"queen_core/x.py": "x = 1\n"})
        bench_dir = os.path.join(tmpdir, "benchmarks")
        os.makedirs(bench_dir)
        with open(os.path.join(bench_dir, "custom.py"), "w") as f:
            f.write("def bench_always_one(candidate_src):\n    return 1.0\n")
        result = run_benchmarks(src, benchmarks_dir=bench_dir)
        assert "custom.py::bench_always_one" in result["benchmark_results"]
        assert result["benchmark_results"]["custom.py::bench_always_one"]["score"] == 1.0
        print("PASS: test_user_benchmarks_discovered")
    finally:
        shutil.rmtree(tmpdir)


# ── fitness differentiation tests ────────────────────────────────────

def test_fitness_differentiates_variants():
    """Two variants that both compile must get DIFFERENT fitness if benchmark differs."""
    # Variant A: good benchmark
    metrics_a = {
        "smoke_ok": True, "compile_ok": True, "import_ok": True,
        "runtime_seconds": 5, "applied": [{"path": "x.py"}], "failed": [],
        "artifact_count": 1, "patch_non_empty": True,
        "benchmark_score": 0.95,
    }
    # Variant B: bad benchmark
    metrics_b = {
        "smoke_ok": True, "compile_ok": True, "import_ok": True,
        "runtime_seconds": 5, "applied": [{"path": "x.py"}], "failed": [],
        "artifact_count": 1, "patch_non_empty": True,
        "benchmark_score": 0.30,
    }
    score_a = compute_fitness(metrics_a)
    score_b = compute_fitness(metrics_b)
    diff = score_a - score_b
    assert diff > 0.15, f"Expected significant difference, got A={score_a:.3f} B={score_b:.3f} diff={diff:.3f}"
    print(f"PASS: test_fitness_differentiates_variants (A={score_a:.3f} B={score_b:.3f} diff={diff:.3f})")


def test_fitness_zero_without_smoke():
    """Variant that fails smoke must score near 0 regardless of benchmark."""
    metrics = {
        "smoke_ok": False, "compile_ok": False, "import_ok": False,
        "benchmark_score": 1.0,
        "applied": [{"path": "x.py"}], "failed": [],
        "artifact_count": 1, "patch_non_empty": True,
    }
    score = compute_fitness(metrics)
    assert score < 0.3, f"Expected < 0.3, got {score}"
    print(f"PASS: test_fitness_zero_without_smoke (score={score:.3f})")


def test_fitness_benchmark_weight():
    """Benchmark should account for ~40% of the score."""
    base = {
        "smoke_ok": True, "compile_ok": True, "import_ok": True,
        "runtime_seconds": 5, "applied": [{"path": "x.py"}], "failed": [],
        "artifact_count": 1, "patch_non_empty": True,
    }
    # With benchmark=1.0
    m1 = {**base, "benchmark_score": 1.0}
    # With benchmark=0.0
    m2 = {**base, "benchmark_score": 0.0}
    s1 = compute_fitness(m1)
    s2 = compute_fitness(m2)
    bench_contribution = s1 - s2
    assert 0.3 <= bench_contribution <= 0.5, \
        f"Expected benchmark weight ~0.4, got contribution={bench_contribution:.3f} (s1={s1:.3f} s2={s2:.3f})"
    print(f"PASS: test_fitness_benchmark_weight (contribution={bench_contribution:.3f})")


# ── Runner ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    tests = [
        test_clean_code_scores_high,
        test_dangerous_code_scores_low,
        test_no_docstrings_penalized,
        test_syntax_error_detected,
        test_run_benchmarks_aggregate,
        test_user_benchmarks_discovered,
        test_fitness_differentiates_variants,
        test_fitness_zero_without_smoke,
        test_fitness_benchmark_weight,
    ]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"FAIL: {t.__name__} — {e}")
            import traceback; traceback.print_exc()
            failed += 1
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    if failed:
        sys.exit(1)
    print("ALL TESTS PASSED")
