"""fitness.py — Fitness function for Queen evolution.

LOT 2: Benchmark-aware fitness that actually differentiates variants.

Score breakdown (weights sum to 1.0):
  - smoke/compile/import gate: 0.35  (binary pass/fail — you must pass to score above 0)
  - benchmark_score:           0.40  (the actual differentiator — quality metrics)
  - efficiency:                0.10  (runtime, cost)
  - patch quality:             0.15  (non-empty, applied without failures)

This means two variants that both compile will get DIFFERENT scores
based on code quality, error handling, docstrings, complexity, etc.
"""

from __future__ import annotations

from typing import Any, Dict


def compute_fitness(metrics: Dict[str, Any]) -> float:
    """Return a fitness score in [0.0, 1.0].

    If smoke/compile fails, score is near 0.
    If smoke passes, the benchmark_score drives differentiation.
    """

    # ── Gate: smoke / compile / import ─────────────────────────────────
    smoke_ok = bool(metrics.get("smoke_ok"))
    compile_ok = bool(metrics.get("compile_ok"))
    import_ok = bool(metrics.get("import_ok"))

    if not smoke_ok:
        # Hard floor: can't promote what doesn't pass smoke
        gate_score = 0.0
    elif compile_ok and import_ok:
        gate_score = 1.0
    elif compile_ok:
        gate_score = 0.7
    else:
        gate_score = 0.3

    # ── Benchmark score (LOT 2 — the differentiator) ──────────────────
    # This comes from bench_runner.run_benchmarks()
    benchmark_score = float(metrics.get("benchmark_score", 0.0))
    # Clamp to [0, 1]
    benchmark_score = max(0.0, min(1.0, benchmark_score))

    # ── Efficiency ─────────────────────────────────────────────────────
    runtime_s = float(metrics.get("runtime_seconds", 9999.0))
    efficiency = 0.0
    if runtime_s <= 10:
        efficiency = 1.0
    elif runtime_s <= 30:
        efficiency = 0.7
    elif runtime_s <= 60:
        efficiency = 0.4
    elif runtime_s <= 120:
        efficiency = 0.2

    budget_cost = float(metrics.get("budget_cost", 0.0))
    if budget_cost <= 0.01:
        efficiency = min(1.0, efficiency + 0.2)
    elif budget_cost <= 0.05:
        efficiency = min(1.0, efficiency + 0.1)

    # ── Patch quality ──────────────────────────────────────────────────
    failed_count = len(metrics.get("failed") or [])
    applied_count = len(metrics.get("applied") or [])
    artifact_count = int(metrics.get("artifact_count", 0) or 0)
    patch_non_empty = bool(metrics.get("patch_non_empty"))

    patch_quality = 0.0
    if patch_non_empty and applied_count > 0 and failed_count == 0:
        patch_quality = 1.0
    elif patch_non_empty and applied_count > 0:
        patch_quality = 0.5
    elif patch_non_empty:
        patch_quality = 0.2
    # empty patch or no artifacts → 0.0

    # ── Safety penalty ─────────────────────────────────────────────────
    violations = int(metrics.get("safety_violations", 0))
    safety_penalty = min(0.3, 0.05 * violations)

    # ── Weighted aggregate ─────────────────────────────────────────────
    W_GATE = 0.35
    W_BENCH = 0.40
    W_EFFICIENCY = 0.10
    W_PATCH = 0.15

    raw = (
        W_GATE * gate_score
        + W_BENCH * benchmark_score
        + W_EFFICIENCY * efficiency
        + W_PATCH * patch_quality
        - safety_penalty
    )

    # Hard rule: if smoke fails, fitness cannot exceed 0.15
    # (you get a tiny score for having a non-empty patch, but nothing real)
    if not smoke_ok:
        raw = min(raw, 0.15)

    return max(0.0, min(1.0, raw))
