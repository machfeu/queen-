"""evolver.py — DGM-like evolution loop (MVP+).

This runs *outside* the main orchestrator loop or can be triggered from the
Dashboard API via a background worker thread.

Workflow per iteration:
1) select a parent variant (or root)
2) create a candidate snapshot under /workspace/.queen_evolution/
3) ask LLM to propose artifacts (full-file contents) for a small allowlisted set
4) apply patch to candidate snapshot
5) run smoke checks
6) compute fitness and archive (patch + snapshot + metrics)

Notes:
- The candidate is NOT automatically promoted into the live system.
- Promotion is still a manual step.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import shutil
import threading
import zipfile
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

from queen_core.patcher import apply_patch, generate_patch_from_artifacts

try:
    from queen_core import redis_bus
except Exception:  # pragma: no cover
    redis_bus = None

from .archive import EvolutionArchive
from .bench_runner import run_benchmarks
from .fitness import compute_fitness
from .mutator import propose_artifacts
from .selector import select_parent
from .smoke import run_smoke

logger = logging.getLogger("queen.evolution")


DEFAULT_ALLOWLIST = [
    "queen_core/orchestrator.py",
    "queen_core/redis_bus.py",
    "queen_core/policy.py",
    "queen_core/patcher.py",
    "queen_core/notifier.py",
    "queen_core/self_heal.py",
    "workers/worker_unified.py",
]

MAX_SNAPSHOT_MB = int(os.getenv("EVOLUTION_MAX_SNAPSHOT_MB", "500"))


ProgressCallback = Callable[[Dict[str, Any]], None]


def _emit(event_type: str, payload: Dict[str, Any], on_progress: Optional[ProgressCallback] = None) -> None:
    event = {"type": event_type, **payload}
    if on_progress:
        try:
            on_progress(event)
        except Exception as e:  # pragma: no cover
            logger.warning(f"Evolution progress callback error: {e}")
    if redis_bus is not None:
        try:
            redis_bus.publish_event(event_type, payload)
        except Exception:
            pass


def _hash_tree(base_dir: str, rel_paths: List[str]) -> str:
    h = hashlib.sha256()
    for rel in sorted(set(rel_paths)):
        p = os.path.join(base_dir, rel)
        if not os.path.exists(p):
            continue
        try:
            with open(p, "rb") as f:
                h.update(rel.encode("utf-8"))
                h.update(b"\0")
                h.update(f.read())
                h.update(b"\0")
        except Exception:
            continue
    return h.hexdigest()



def _copy_snapshot(src_root: str, dst_root: str, include_dirs: Optional[List[str]] = None) -> None:
    os.makedirs(dst_root, exist_ok=True)
    include_dirs = include_dirs or ["queen_core", "workers", "dashboard/backend"]
    total_size = 0
    for d in include_dirs:
        s = os.path.join(src_root, d)
        if not os.path.exists(s):
            continue
        for dirpath, _, filenames in os.walk(s):
            for fn in filenames:
                total_size += os.path.getsize(os.path.join(dirpath, fn))
        if total_size > MAX_SNAPSHOT_MB * 1024 * 1024:
            raise ValueError(f"Snapshot too large: {total_size / 1024 / 1024:.1f}MB > {MAX_SNAPSHOT_MB}MB")
        t = os.path.join(dst_root, d)
        if os.path.exists(t):
            shutil.rmtree(t)
        shutil.copytree(s, t)



def _zip_dir(src_dir: str, out_zip: str) -> None:
    os.makedirs(os.path.dirname(out_zip), exist_ok=True)
    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(src_dir):
            for f in files:
                p = os.path.join(root, f)
                rel = os.path.relpath(p, src_dir)
                z.write(p, rel)



def run_evolution(
    iterations: int = 5,
    instruction: str = "Improve reliability and bug-resilience without changing external behavior.",
    targets: Optional[List[str]] = None,
    allowlist: Optional[List[str]] = None,
    max_files: int = 2,
    exploration: float = 0.15,
    dry_run: bool = False,
    stop_event: Optional[threading.Event] = None,
    on_progress: Optional[ProgressCallback] = None,
) -> Dict[str, Any]:
    """Run the evolution loop and return summary."""

    archive = EvolutionArchive()
    allowlist = allowlist or DEFAULT_ALLOWLIST
    targets = targets or allowlist

    src_root = os.getenv("EVOLUTION_SOURCE_ROOT", "/app")
    workspace_base = os.getenv("WORKSPACE_BASE", "/workspace")
    evo_root = os.path.join(workspace_base, ".queen_evolution")
    candidates_root = os.path.join(evo_root, "candidates")
    os.makedirs(candidates_root, exist_ok=True)

    if not os.path.isdir(src_root):
        logger.error(f"EVOLUTION_SOURCE_ROOT does not exist: {src_root}")
        error = {"created": [], "last_parent": None, "error": f"src_root not found: {src_root}"}
        _emit("evolution_error", error, on_progress)
        return error

    variants = archive.list_variants(limit=1)
    if not variants:
        code_hash = _hash_tree(src_root, allowlist)[:12]
        root_id = f"root-{code_hash}"
        patch_path = archive.patch_file_path(root_id)
        snapshot_path = archive.snapshot_file_path(root_id)
        if not os.path.exists(snapshot_path):
            tmp = os.path.join(candidates_root, root_id, "src")
            _copy_snapshot(src_root, tmp)
            _zip_dir(tmp, snapshot_path)
        if not os.path.exists(patch_path):
            with open(patch_path, "w", encoding="utf-8") as f:
                f.write("# root variant (no patch)\n")
        archive.add_variant(
            variant_id=root_id,
            parent_id=None,
            fitness=0.50,
            tests_ok=True,
            targets=[],
            tags=["root"],
            metrics={"smoke_ok": True, "compile_ok": True, "root": True},
            patch_path=patch_path,
            snapshot_path=snapshot_path,
        )

    created: List[str] = []
    last_parent: Optional[str] = None

    _emit(
        "evolution_started",
        {
            "iterations": int(iterations),
            "instruction": instruction,
            "targets": targets,
            "allowlist": allowlist,
            "max_files": int(max_files),
            "exploration": float(exploration),
            "dry_run": bool(dry_run),
        },
        on_progress,
    )

    for i in range(int(iterations)):
        if stop_event and stop_event.is_set():
            _emit("evolution_stopped", {"iteration": i, "created": created}, on_progress)
            return {"created": created, "last_parent": last_parent, "stopped": True}

        parent, selection_meta = select_parent(archive, exploration=exploration, return_meta=True)
        if not parent:
            break
        last_parent = parent.variant_id

        variant_id = archive.new_variant_id(prefix="cand")
        created.append(variant_id)
        _emit(
            "evolution_iteration_started",
            {
                "iteration": i + 1,
                "iterations": int(iterations),
                "parent_id": parent.variant_id,
                "variant_id": variant_id,
                "selection": selection_meta,
            },
            on_progress,
        )

        candidate_src = os.path.join(candidates_root, variant_id, "src")
        _copy_snapshot(src_root, candidate_src)

        run_id = f"evo-{variant_id}"
        chosen_targets = [t for t in (targets or []) if t in allowlist]
        if not chosen_targets:
            chosen_targets = allowlist[:]

        artifacts = propose_artifacts(
            parent_src=candidate_src,
            targets=chosen_targets,
            instruction=instruction,
            run_id=run_id,
            max_files=max_files,
        )

        patch_text = generate_patch_from_artifacts(artifacts, workspace_path=candidate_src)
        patch_path = archive.patch_file_path(variant_id)
        with open(patch_path, "w", encoding="utf-8") as f:
            f.write(patch_text or "")

        applied = {"applied": [], "failed": []}
        changed_paths: List[str] = []
        if patch_text.strip():
            applied = apply_patch(patch_text, workspace_path=candidate_src, dry_run=dry_run)
            if not dry_run:
                changed_paths = [os.path.join(candidate_src, x.get("path", "")) for x in applied.get("applied", [])]

        if dry_run:
            smoke_metrics = {
                "compile_ok": None,
                "smoke_ok": None,
                "import_ok": None,
                "runtime_seconds": 0,
                "note": "dry_run: smoke skipped (patch not applied to disk)",
            }
        else:
            smoke_metrics = run_smoke(candidate_src=candidate_src, changed_paths=changed_paths)

        # LOT 2: Run functional benchmarks (the differentiator)
        if dry_run:
            bench_results = {"benchmark_score": 0.0, "benchmark_count": 0, "benchmark_results": {}}
        else:
            benchmarks_dir = os.path.join(
                os.getenv("EVOLUTION_SOURCE_ROOT", "/app"), "benchmarks"
            )
            bench_results = run_benchmarks(candidate_src, benchmarks_dir=benchmarks_dir)

        metrics: Dict[str, Any] = {
            "iteration": i,
            "parent_id": parent.variant_id,
            "smoke_ok": smoke_metrics.get("smoke_ok"),
            "compile_ok": smoke_metrics.get("compile_ok"),
            "import_ok": smoke_metrics.get("import_ok"),
            "runtime_seconds": smoke_metrics.get("runtime_seconds"),
            "applied": applied.get("applied", []),
            "failed": applied.get("failed", []),
            "artifact_count": len(artifacts),
            "patch_non_empty": bool((patch_text or "").strip()),
            "notes": "dry_run" if dry_run else "",
            "selection": selection_meta,
            # LOT 2: benchmark metrics
            "benchmark_score": bench_results.get("benchmark_score", 0.0),
            "benchmark_count": bench_results.get("benchmark_count", 0),
            "benchmark_results": bench_results.get("benchmark_results", {}),
        }

        fitness = compute_fitness(metrics)
        snapshot_path = archive.snapshot_file_path(variant_id)
        _zip_dir(candidate_src, snapshot_path)

        archive.add_variant(
            variant_id=variant_id,
            parent_id=parent.variant_id,
            fitness=fitness,
            tests_ok=bool(metrics.get("smoke_ok")),
            targets=chosen_targets[:max_files],
            tags=["candidate"],
            metrics=metrics,
            patch_path=patch_path,
            snapshot_path=snapshot_path,
        )

        iteration_payload = {
            "iteration": i + 1,
            "iterations": int(iterations),
            "parent_id": parent.variant_id,
            "variant_id": variant_id,
            "fitness": float(fitness),
            "smoke_ok": metrics.get("smoke_ok"),
            "compile_ok": metrics.get("compile_ok"),
            "import_ok": metrics.get("import_ok"),
            "artifact_count": len(artifacts),
            "applied_count": len(applied.get("applied", [])),
            "failed_count": len(applied.get("failed", [])),
            "benchmark_score": metrics.get("benchmark_score", 0.0),
        }
        logger.info(
            f"Evolution candidate archived: {variant_id} parent={parent.variant_id} "
            f"fitness={fitness:.3f} bench={metrics.get('benchmark_score', 0):.3f} smoke_ok={metrics.get('smoke_ok')}"
        )
        _emit("evolution_iteration_completed", iteration_payload, on_progress)

        try:
            candidate_dir = os.path.join(candidates_root, variant_id)
            if os.path.isdir(candidate_dir):
                shutil.rmtree(candidate_dir)
        except Exception as e:
            logger.warning(f"Failed to clean up candidate dir {variant_id}: {e}")

    summary = {"created": created, "last_parent": last_parent, "stopped": False}
    _emit("evolution_completed", summary, on_progress)
    return summary



def _parse_list_arg(v: str) -> List[str]:
    if not v:
        return []
    v = v.strip()
    if v.startswith("["):
        try:
            data = json.loads(v)
            return [str(x) for x in data]
        except Exception:
            return []
    return [x.strip() for x in v.split(",") if x.strip()]


# ═════════════════════════════════════════════════════════════════════
# Promotion + Rollback (LOT 1.1 — hardened)
#
# Fixes vs LOT 1:
#   1. target_dir removed from API — hardcoded to WORKSPACE_BASE
#   2. Atomic promotion: rmtree target dirs THEN extract (no stale overlay)
#   3. Lock prevents concurrent promote/rollback
#   4. ZIP path traversal check on every member
#   5. Multi-backup history (not just last_promotion.json)
#   6. Rollback by backup_id with inventory validation
# ═════════════════════════════════════════════════════════════════════

_WORKSPACE_BASE = os.getenv("WORKSPACE_BASE", "/workspace")
PROMOTION_BACKUP_DIR = os.path.join(_WORKSPACE_BASE, ".queen_promotion_backups")
PROMOTION_INCLUDE_DIRS = ("queen_core", "workers", "dashboard/backend")
_promotion_lock = threading.Lock()


def _is_under_dir(child: str, parent: str) -> bool:
    """True if child path is strictly under parent (commonpath, not startswith)."""
    try:
        rp = os.path.realpath(parent)
        rc = os.path.realpath(child)
        return os.path.commonpath([rp, rc]) == rp and rc != rp
    except (ValueError, TypeError):
        return False


def _validate_dir_entry(d: str) -> bool:
    """Reject dir entries from meta that could escape the workspace.
    A safe entry is a short relative path with no '..' and no absolute component."""
    if not d or not isinstance(d, str):
        return False
    if os.path.isabs(d):
        return False
    if ".." in d.split("/") or ".." in d.split(os.sep):
        return False
    # Must be one of the known include dirs or a sub-path
    for allowed in PROMOTION_INCLUDE_DIRS:
        if d == allowed or d.startswith(allowed + "/"):
            return True
    return False


def _safe_zip_member(member: str, target_dir: str) -> bool:
    """Reject zip members with path traversal (zipslip)."""
    resolved = os.path.realpath(os.path.join(target_dir, member))
    return resolved.startswith(os.path.realpath(target_dir) + os.sep)


def _member_in_include_dirs(member: str) -> bool:
    """Check if a zip member belongs to one of the promotion-safe dirs."""
    for d in PROMOTION_INCLUDE_DIRS:
        if member == d or member.startswith(d + "/"):
            return True
    return False


def promote_variant(variant_id: str) -> Dict[str, Any]:
    """
    Promote an archived variant into the live workspace.

    The target is always WORKSPACE_BASE (not user-controllable).
    Promotion is atomic per directory: backup → delete → extract.
    A lock prevents concurrent promotion/rollback.
    """
    if not _promotion_lock.acquire(timeout=5):
        return {"ok": False, "error": "Another promotion or rollback is in progress"}

    try:
        return _promote_variant_locked(variant_id)
    finally:
        _promotion_lock.release()


def _promote_variant_locked(variant_id: str) -> Dict[str, Any]:
    target_dir = os.path.realpath(_WORKSPACE_BASE)

    archive = EvolutionArchive()
    variant = archive.get_variant(variant_id)
    if not variant:
        return {"ok": False, "error": f"Variant {variant_id} not found in archive"}

    if not variant.tests_ok:
        return {"ok": False, "error": f"Variant {variant_id} did not pass smoke tests — refused"}

    snapshot_path = variant.snapshot_path
    if not os.path.isfile(snapshot_path):
        return {"ok": False, "error": f"Snapshot file missing: {snapshot_path}"}

    # ── Pre-validate zip contents ──────────────────────────────────────
    try:
        with zipfile.ZipFile(snapshot_path, "r") as z:
            members = z.namelist()
    except Exception as e:
        return {"ok": False, "error": f"Cannot open snapshot zip: {e}"}

    extractable = []
    for m in members:
        if not _member_in_include_dirs(m):
            continue
        if not _safe_zip_member(m, target_dir):
            return {"ok": False, "error": f"Zip path traversal blocked: {m}"}
        extractable.append(m)

    if not extractable:
        return {"ok": False, "error": "Snapshot contains no files in the promotion-safe directories"}

    # ── Identify which dirs will be touched ────────────────────────────
    dirs_touched = set()
    for m in extractable:
        top = m.split("/")[0]
        if top in PROMOTION_INCLUDE_DIRS:
            dirs_touched.add(top)
        elif "/" in m:
            # e.g. "dashboard/backend/..." → "dashboard/backend"
            prefix = "/".join(m.split("/")[:2])
            if prefix in PROMOTION_INCLUDE_DIRS:
                dirs_touched.add(prefix)

    # ── Create backup ──────────────────────────────────────────────────
    backup_id = f"{variant_id}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
    backup_path = os.path.join(PROMOTION_BACKUP_DIR, backup_id)
    os.makedirs(backup_path, exist_ok=True)

    backed_up = []
    for d in sorted(dirs_touched):
        src = os.path.join(target_dir, d)
        if os.path.isdir(src):
            dst = os.path.join(backup_path, d)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copytree(src, dst)
            backed_up.append(d)

    # ── Atomic replace: delete target dirs THEN extract ────────────────
    try:
        # Phase 1: remove existing dirs (we have the backup)
        for d in sorted(dirs_touched):
            dst = os.path.join(target_dir, d)
            if os.path.isdir(dst):
                shutil.rmtree(dst)

        # Phase 2: extract from zip
        files_extracted = 0
        with zipfile.ZipFile(snapshot_path, "r") as z:
            for m in extractable:
                z.extract(m, target_dir)
                files_extracted += 1

    except Exception as e:
        logger.error(f"Promotion failed during extraction: {e} — rolling back")
        # LOT 1.2: Clean ALL dirs_touched (removes partial extracts) then restore
        _restore_backup(backup_path, target_dir, backed_up, list(dirs_touched))
        return {"ok": False, "error": f"Extraction failed: {e}", "rolled_back": True}

    # ── Record promotion metadata ──────────────────────────────────────
    meta = {
        "variant_id": variant_id,
        "backup_id": backup_id,
        "backup_path": backup_path,
        "target_dir": target_dir,
        "backed_up_dirs": backed_up,
        "dirs_replaced": sorted(dirs_touched),
        "files_extracted": files_extracted,
        "promoted_at": datetime.now(timezone.utc).isoformat(),
        "fitness": variant.fitness,
    }
    # Write per-backup meta
    per_backup_meta = os.path.join(backup_path, "_meta.json")
    with open(per_backup_meta, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
    # Write last_promotion pointer
    pointer_path = os.path.join(PROMOTION_BACKUP_DIR, "last_promotion.json")
    with open(pointer_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)

    logger.info(f"Variant {variant_id} promoted to {target_dir} ({files_extracted} files, backup={backup_id})")
    return {
        "ok": True,
        "variant_id": variant_id,
        "backup_id": backup_id,
        "files_extracted": files_extracted,
        "dirs_replaced": sorted(dirs_touched),
    }


def rollback_promotion(backup_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Rollback a promotion. Uses the lock to prevent concurrent ops.
    If backup_id is None, rolls back the last promotion.
    """
    if not _promotion_lock.acquire(timeout=5):
        return {"ok": False, "error": "Another promotion or rollback is in progress"}

    try:
        return _rollback_locked(backup_id)
    finally:
        _promotion_lock.release()


def _rollback_locked(backup_id: Optional[str]) -> Dict[str, Any]:
    pointer_path = os.path.join(PROMOTION_BACKUP_DIR, "last_promotion.json")

    if backup_id:
        backup_path = os.path.join(PROMOTION_BACKUP_DIR, backup_id)
        meta_file = os.path.join(backup_path, "_meta.json")
    else:
        if not os.path.isfile(pointer_path):
            return {"ok": False, "error": "No promotion to rollback"}
        with open(pointer_path, "r", encoding="utf-8") as f:
            meta = json.load(f)
        backup_path = meta.get("backup_path", "")
        backup_id = meta.get("backup_id", "")
        meta_file = os.path.join(backup_path, "_meta.json")

    if not os.path.isdir(backup_path):
        return {"ok": False, "error": f"Backup directory not found: {backup_path}"}

    # Load meta from the backup itself (authoritative, not the pointer)
    target_dir = os.path.realpath(_WORKSPACE_BASE)
    backed_up_dirs: List[str] = []
    dirs_replaced: List[str] = []
    if os.path.isfile(meta_file):
        with open(meta_file, "r", encoding="utf-8") as f:
            meta = json.load(f)
        target_dir = os.path.realpath(meta.get("target_dir", target_dir))
        backed_up_dirs = meta.get("backed_up_dirs", [])
        dirs_replaced = meta.get("dirs_replaced", [])

    # Validate target_dir is still workspace (LOT 1.3: commonpath instead of startswith)
    ws_real = os.path.realpath(_WORKSPACE_BASE)
    if not _is_under_dir(target_dir, ws_real) and os.path.realpath(target_dir) != ws_real:
        return {"ok": False, "error": "Backup target_dir is outside workspace — refusing rollback"}

    # LOT 1.3: Validate every dir entry from meta before using it
    for d in backed_up_dirs + dirs_replaced:
        if not _validate_dir_entry(d):
            return {"ok": False, "error": f"Invalid dir entry in backup meta: {d!r} — refusing rollback"}

    # LOT 1.2: Use dirs_replaced (all dirs touched by promotion) for cleanup,
    # and backed_up_dirs (dirs that had content before) for restore.
    all_dirs = sorted(set(dirs_replaced) | set(backed_up_dirs))
    restored = _restore_backup(backup_path, target_dir, backed_up_dirs, all_dirs)

    # Remove pointer if this was the last promotion
    try:
        if os.path.isfile(pointer_path):
            with open(pointer_path, "r", encoding="utf-8") as f:
                current = json.load(f)
            if current.get("backup_id") == backup_id:
                os.remove(pointer_path)
    except Exception:
        pass

    logger.info(f"Promotion rolled back from backup {backup_id} ({len(restored)} dirs restored, {len(all_dirs)} dirs cleaned)")
    return {"ok": True, "backup_id": backup_id, "restored_dirs": restored, "cleaned_dirs": all_dirs}


def _restore_backup(
    backup_path: str,
    target_dir: str,
    restore_dirs: List[str],
    clean_dirs: Optional[List[str]] = None,
) -> List[str]:
    """
    Restore backed-up directories into target.

    LOT 1.2:
      - clean_dirs: ALL dirs that were touched by promotion — these get rmtree'd
        first, even if they have no backup (i.e. they were created by the promotion).
      - restore_dirs: dirs that have a backup to restore from.

    This ensures no orphan files survive a rollback.
    """
    # Phase 1: remove everything the promotion touched
    for d in (clean_dirs or restore_dirs):
        if not _validate_dir_entry(d):
            continue  # LOT 1.3: skip invalid entries
        dst = os.path.join(target_dir, d)
        if not _is_under_dir(dst, target_dir) and os.path.realpath(dst) != os.path.realpath(target_dir):
            continue  # resolved path escapes target — skip
        if os.path.isdir(dst):
            shutil.rmtree(dst)

    # Phase 2: restore from backup only what existed before
    restored = []
    for d in restore_dirs:
        if not _validate_dir_entry(d):
            continue
        src = os.path.join(backup_path, d)
        dst = os.path.join(target_dir, d)
        if not _is_under_dir(dst, target_dir) and os.path.realpath(dst) != os.path.realpath(target_dir):
            continue
        if os.path.isdir(src):
            shutil.copytree(src, dst)
            restored.append(d)
    return restored


def get_promotion_status() -> Dict[str, Any]:
    """Return info about the last promotion (if any)."""
    pointer_path = os.path.join(PROMOTION_BACKUP_DIR, "last_promotion.json")
    if not os.path.isfile(pointer_path):
        return {"has_promotion": False}
    with open(pointer_path, "r", encoding="utf-8") as f:
        meta = json.load(f)
    meta["has_promotion"] = True
    return meta


def list_promotion_backups() -> List[Dict[str, Any]]:
    """List all promotion backups with their metadata."""
    if not os.path.isdir(PROMOTION_BACKUP_DIR):
        return []
    backups = []
    for name in sorted(os.listdir(PROMOTION_BACKUP_DIR), reverse=True):
        meta_file = os.path.join(PROMOTION_BACKUP_DIR, name, "_meta.json")
        if os.path.isfile(meta_file):
            with open(meta_file, "r", encoding="utf-8") as f:
                meta = json.load(f)
            meta["backup_id"] = name
            backups.append(meta)
    return backups



def main() -> None:
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
    ap = argparse.ArgumentParser(description="Queen evolution loop (DGM-like MVP)")
    ap.add_argument("--iterations", type=int, default=int(os.getenv("EVOLUTION_ITERS", "5")))
    ap.add_argument("--max-files", type=int, default=int(os.getenv("EVOLUTION_MAX_FILES", "2")))
    ap.add_argument("--exploration", type=float, default=float(os.getenv("EVOLUTION_EXPLORATION", "0.15")))
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument(
        "--instruction",
        type=str,
        default=os.getenv(
            "EVOLUTION_INSTRUCTION",
            "Improve reliability and bug-resilience without changing external behavior.",
        ),
    )
    ap.add_argument("--allowlist", type=str, default=os.getenv("EVOLUTION_ALLOWLIST", ""))
    ap.add_argument("--targets", type=str, default=os.getenv("EVOLUTION_TARGETS", ""))

    args = ap.parse_args()
    allowlist = _parse_list_arg(args.allowlist) or DEFAULT_ALLOWLIST
    targets = _parse_list_arg(args.targets) or None

    summary = run_evolution(
        iterations=args.iterations,
        instruction=args.instruction,
        targets=targets,
        allowlist=allowlist,
        max_files=args.max_files,
        exploration=args.exploration,
        dry_run=bool(args.dry_run),
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
