"""
bench_runner.py — Run functional benchmarks against a candidate variant.

LOT 2: This is what makes fitness differentiate variants beyond "compiles OK".

Each benchmark is a Python function that receives the candidate_src path and
returns a score between 0.0 and 1.0. The runner collects all benchmarks,
runs them with a timeout, and returns an aggregate score.

Benchmarks are discovered from:
  1. Built-in checks in this file (structural, behavioral)
  2. User benchmarks in benchmarks/ directory (any .py file with bench_* functions)

Design rules:
  - Benchmarks must be FAST (< 10s each). They run on every evolution iteration.
  - Benchmarks must be DETERMINISTIC. Same code → same score.
  - Benchmarks must be SAFE. They read files, they don't execute arbitrary code.
  - A benchmark that crashes scores 0.0 (not the whole run).
"""

from __future__ import annotations

import ast
import importlib.util
import logging
import os
import time
from typing import Any, Callable, Dict, List, Tuple

logger = logging.getLogger("queen.evolution.benchmark")

BenchmarkFn = Callable[[str], float]  # candidate_src → score 0.0-1.0

# Maximum time per individual benchmark
BENCH_TIMEOUT_S = 10


# ═══════════════════════════════════════════════════════════════════════
# Built-in benchmarks
# ═══════════════════════════════════════════════════════════════════════

def bench_no_dangerous_patterns(candidate_src: str) -> float:
    """Check that candidate code doesn't introduce dangerous patterns.
    Returns 1.0 if clean, degrades with each violation."""
    dangerous = [
        "os.system(", "subprocess.call(", "subprocess.Popen(",
        "eval(", "exec(", "__import__(", "rm -rf",
    ]
    # eval( is OK inside ast.literal_eval(
    violations = 0
    total_files = 0

    for root, _, files in os.walk(candidate_src):
        for fn in files:
            if not fn.endswith(".py"):
                continue
            total_files += 1
            try:
                with open(os.path.join(root, fn), "r", encoding="utf-8") as f:
                    content = f.read()
            except Exception:
                continue
            for pat in dangerous:
                if pat in content:
                    if pat == "eval(" and "ast.literal_eval(" in content:
                        cleaned = content.replace("ast.literal_eval(", "")
                        if "eval(" not in cleaned:
                            continue
                    violations += 1

    if total_files == 0:
        return 0.0
    return max(0.0, 1.0 - (violations * 0.15))


def bench_docstrings_present(candidate_src: str) -> float:
    """Check that public functions/classes have docstrings.
    Measures code quality — better documented code scores higher."""
    total_defs = 0
    with_doc = 0

    for root, _, files in os.walk(candidate_src):
        for fn in files:
            if not fn.endswith(".py"):
                continue
            path = os.path.join(root, fn)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    source = f.read()
                tree = ast.parse(source, filename=path)
            except Exception:
                continue

            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    # Skip private/dunder
                    if node.name.startswith("_") and not node.name.startswith("__"):
                        continue
                    total_defs += 1
                    if (ast.get_docstring(node)):
                        with_doc += 1

    if total_defs == 0:
        return 0.5  # no public defs = neutral
    return with_doc / total_defs


def bench_no_syntax_errors(candidate_src: str) -> float:
    """Parse ALL Python files with ast.parse — catches syntax errors that
    py_compile might miss in some edge cases. Returns ratio of parseable files."""
    total = 0
    ok = 0

    for root, _, files in os.walk(candidate_src):
        for fn in files:
            if not fn.endswith(".py"):
                continue
            total += 1
            path = os.path.join(root, fn)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    source = f.read()
                ast.parse(source, filename=path)
                ok += 1
            except Exception:
                logger.debug(f"Syntax error in {path}")

    return (ok / total) if total > 0 else 0.0


def bench_error_handling(candidate_src: str) -> float:
    """Reward code that has try/except blocks in functions that do I/O.
    This is a proxy for robustness — code that handles errors is more resilient."""
    io_functions = 0
    io_with_try = 0

    io_patterns = {"open(", "read(", "write(", "connect(", "execute(", "fetch("}

    for root, _, files in os.walk(candidate_src):
        for fn in files:
            if not fn.endswith(".py"):
                continue
            path = os.path.join(root, fn)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    source = f.read()
                tree = ast.parse(source, filename=path)
            except Exception:
                continue

            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    body_src = ast.get_source_segment(source, node) or ""
                    has_io = any(pat in body_src for pat in io_patterns)
                    if has_io:
                        io_functions += 1
                        has_try = any(isinstance(child, ast.Try) for child in ast.walk(node))
                        if has_try:
                            io_with_try += 1

    if io_functions == 0:
        return 0.5
    return io_with_try / io_functions


def bench_function_complexity(candidate_src: str) -> float:
    """Penalize overly complex functions (too many lines).
    Functions > 80 lines are penalized. Encourages small, focused code."""
    total_funcs = 0
    oversized = 0

    for root, _, files in os.walk(candidate_src):
        for fn in files:
            if not fn.endswith(".py"):
                continue
            path = os.path.join(root, fn)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    source = f.read()
                tree = ast.parse(source, filename=path)
            except Exception:
                continue

            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    total_funcs += 1
                    if hasattr(node, "end_lineno") and node.end_lineno:
                        length = node.end_lineno - node.lineno
                        if length > 80:
                            oversized += 1

    if total_funcs == 0:
        return 0.5
    return max(0.0, 1.0 - (oversized / total_funcs))


# ═══════════════════════════════════════════════════════════════════════
# User benchmark discovery
# ═══════════════════════════════════════════════════════════════════════

def _discover_user_benchmarks(benchmarks_dir: str) -> List[Tuple[str, BenchmarkFn]]:
    """Load bench_* functions from .py files in benchmarks_dir."""
    found: List[Tuple[str, BenchmarkFn]] = []
    if not os.path.isdir(benchmarks_dir):
        return found

    for fn in sorted(os.listdir(benchmarks_dir)):
        if not fn.endswith(".py") or fn.startswith("_"):
            continue
        path = os.path.join(benchmarks_dir, fn)
        try:
            spec = importlib.util.spec_from_file_location(f"bench_{fn[:-3]}", path)
            if not spec or not spec.loader:
                continue
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            for name in dir(mod):
                if name.startswith("bench_") and callable(getattr(mod, name)):
                    found.append((f"{fn}::{name}", getattr(mod, name)))
        except Exception as e:
            logger.warning(f"Failed to load benchmark file {fn}: {e}")

    return found


# ═══════════════════════════════════════════════════════════════════════
# Runner
# ═══════════════════════════════════════════════════════════════════════

BUILTIN_BENCHMARKS: List[Tuple[str, BenchmarkFn]] = [
    ("no_dangerous_patterns", bench_no_dangerous_patterns),
    ("docstrings_present", bench_docstrings_present),
    ("no_syntax_errors", bench_no_syntax_errors),
    ("error_handling", bench_error_handling),
    ("function_complexity", bench_function_complexity),
]


def run_benchmarks(
    candidate_src: str,
    benchmarks_dir: str = "",
) -> Dict[str, Any]:
    """
    Run all benchmarks (built-in + user) against a candidate.

    Returns:
        {
            "benchmark_score": float,      # aggregate 0.0 - 1.0
            "benchmark_count": int,
            "benchmark_results": {name: {"score": float, "time_s": float, "error": str|None}},
        }
    """
    all_benchmarks = list(BUILTIN_BENCHMARKS)

    if benchmarks_dir:
        all_benchmarks.extend(_discover_user_benchmarks(benchmarks_dir))

    results: Dict[str, Dict[str, Any]] = {}
    scores: List[float] = []

    for name, fn in all_benchmarks:
        t0 = time.time()
        try:
            score = fn(candidate_src)
            score = max(0.0, min(1.0, float(score)))
            elapsed = time.time() - t0
            results[name] = {"score": score, "time_s": round(elapsed, 3), "error": None}
            scores.append(score)
        except Exception as e:
            elapsed = time.time() - t0
            logger.warning(f"Benchmark {name} failed: {e}")
            results[name] = {"score": 0.0, "time_s": round(elapsed, 3), "error": str(e)}
            scores.append(0.0)

    aggregate = sum(scores) / len(scores) if scores else 0.0

    return {
        "benchmark_score": round(aggregate, 4),
        "benchmark_count": len(all_benchmarks),
        "benchmark_results": results,
    }
