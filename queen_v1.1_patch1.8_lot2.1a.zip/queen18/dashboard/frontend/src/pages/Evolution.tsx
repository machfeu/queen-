import { useEffect, useMemo, useState } from "react";
import {
  Alert,
  Badge,
  Button,
  Code,
  Divider,
  Group,
  Loader,
  NumberInput,
  Paper,
  Progress,
  Stack,
  Switch,
  Table,
  Text,
  Textarea,
  TextInput,
  Title,
} from "@mantine/core";
import { IconAtom2, IconPlayerPlay, IconPlayerStop, IconAlertCircle } from "@tabler/icons-react";
import {
  useEvolutionRanking,
  useEvolutionStatus,
  useEvolutionVariants,
  useStartEvolution,
  useStopEvolution,
} from "../api/hooks";
import { useEvents } from "../ws/useEvents";

export default function Evolution() {
  const { data: status, isLoading } = useEvolutionStatus();
  const { data: variants } = useEvolutionVariants(50);
  const { data: ranking } = useEvolutionRanking(10);
  const startMutation = useStartEvolution();
  const stopMutation = useStopEvolution();
  const { events } = useEvents();

  const [iterations, setIterations] = useState(5);
  const [maxFiles, setMaxFiles] = useState(2);
  const [exploration, setExploration] = useState(0.15);
  const [dryRun, setDryRun] = useState(false);
  const [instruction, setInstruction] = useState("");
  const [allowlist, setAllowlist] = useState("");
  const [targets, setTargets] = useState("");

  useEffect(() => {
    if (!status?.config) return;
    setIterations(status.config.iterations ?? 5);
    setMaxFiles(status.config.max_files ?? 2);
    setExploration(status.config.exploration ?? 0.15);
    setDryRun(Boolean(status.config.dry_run));
    setInstruction(status.config.instruction ?? "");
    setAllowlist(status.config.allowlist ?? "");
    setTargets(status.config.targets ?? "");
  }, [status?.config]);

  const liveEvolutionEvents = useMemo(
    () => events.filter((e) => e.type.startsWith("evolution_")).slice(0, 12),
    [events]
  );

  if (isLoading) return <Loader m="xl" />;

  const currentIteration = Number((status?.current?.iteration as number) ?? 0);
  const totalIterations = Number(status?.config?.iterations ?? iterations ?? 1);
  const progress = totalIterations > 0 ? Math.min(100, Math.round((currentIteration / totalIterations) * 100)) : 0;

  return (
    <Stack gap="lg">
      <Group justify="space-between">
        <div>
          <Title order={2}>Évolution darwinienne</Title>
          <Text c="dimmed" size="sm">
            Visualisation et pilotage du moteur DGM-like en temps réel.
          </Text>
        </div>
        <Badge color={status?.running ? "green" : "gray"} variant="dot" size="lg">
          {status?.running ? "en cours" : "à l'arrêt"}
        </Badge>
      </Group>

      <Alert color="yellow" icon={<IconAlertCircle size={16} />}>
        L’algorithme actuel est un moteur d’évolution guidée et sécurisé. Il archive, sélectionne et compare des variantes,
        mais ce n’est pas encore une boucle d’auto-amélioration “forte” avec benchmark métier complet et promotion automatique.
      </Alert>

      <Paper p="md" radius="md" withBorder>
        <Group justify="space-between" align="flex-start" mb="md">
          <div>
            <Text fw={600}>Cycle actuel</Text>
            <Text size="sm" c="dimmed">
              {status?.running ? "Une mutation est en cours de génération/évaluation." : "Aucun cycle actif."}
            </Text>
          </div>
          <Group>
            <Button
              leftSection={<IconPlayerPlay size={16} />}
              onClick={() =>
                startMutation.mutate({
                  iterations,
                  max_files: maxFiles,
                  exploration,
                  dry_run: dryRun,
                  instruction,
                  allowlist,
                  targets,
                })
              }
              loading={startMutation.isPending}
              disabled={Boolean(status?.running)}
            >
              Lancer
            </Button>
            <Button
              color="red"
              variant="light"
              leftSection={<IconPlayerStop size={16} />}
              onClick={() => stopMutation.mutate()}
              loading={stopMutation.isPending}
              disabled={!status?.running}
            >
              Stop
            </Button>
          </Group>
        </Group>

        <Progress value={progress} size="lg" radius="xl" mb="sm" />
        <Group gap="lg">
          <Text size="sm">Itération: <Code>{currentIteration || 0}</Code> / <Code>{totalIterations}</Code></Text>
          <Text size="sm">Total variantes: <Code>{status?.variants_total ?? variants?.length ?? 0}</Code></Text>
          <Text size="sm">Meilleure variante: <Code>{status?.best_variant_id ?? "—"}</Code></Text>
        </Group>
        {status?.last_error && (
          <Alert color="red" mt="md">{status.last_error}</Alert>
        )}
      </Paper>

      <Paper p="md" radius="md" withBorder>
        <Title order={4} mb="md">Paramètres</Title>
        <Stack>
          <Group grow align="flex-start">
            <NumberInput label="Itérations" min={1} max={200} value={iterations} onChange={(v) => setIterations(Number(v) || 5)} />
            <NumberInput label="Fichiers max mutés" min={1} max={10} value={maxFiles} onChange={(v) => setMaxFiles(Number(v) || 2)} />
            <NumberInput label="Exploration" min={0} max={1} step={0.05} decimalScale={2} value={exploration} onChange={(v) => setExploration(Number(v) || 0)} />
          </Group>
          <Switch checked={dryRun} onChange={(e) => setDryRun(e.currentTarget.checked)} label="Dry run (archive sans smoke réel)" />
          <Textarea label="Instruction d’évolution" minRows={3} value={instruction} onChange={(e) => setInstruction(e.currentTarget.value)} />
          <TextInput label="Allowlist" description="Liste CSV des fichiers autorisés" value={allowlist} onChange={(e) => setAllowlist(e.currentTarget.value)} />
          <TextInput label="Targets" description="Liste CSV des fichiers ciblés" value={targets} onChange={(e) => setTargets(e.currentTarget.value)} />
        </Stack>
      </Paper>

      <Group grow align="flex-start">
        <Paper p="md" radius="md" withBorder>
          <Group mb="sm">
            <IconAtom2 size={18} />
            <Text fw={600}>Top sélection</Text>
          </Group>
          {!ranking?.length ? (
            <Text size="sm" c="dimmed">Pas encore de variantes archivées.</Text>
          ) : (
            <Table highlightOnHover>
              <Table.Thead>
                <Table.Tr>
                  <Table.Th>Variant</Table.Th>
                  <Table.Th>Fitness</Table.Th>
                  <Table.Th>Score ajusté</Table.Th>
                  <Table.Th>Enfants</Table.Th>
                </Table.Tr>
              </Table.Thead>
              <Table.Tbody>
                {ranking.map((row) => (
                  <Table.Tr key={row.variant_id}>
                    <Table.Td><Code>{row.variant_id}</Code></Table.Td>
                    <Table.Td>{row.fitness.toFixed(3)}</Table.Td>
                    <Table.Td>{row.adjusted_score.toFixed(3)}</Table.Td>
                    <Table.Td>{row.children}</Table.Td>
                  </Table.Tr>
                ))}
              </Table.Tbody>
            </Table>
          )}
        </Paper>

        <Paper p="md" radius="md" withBorder>
          <Text fw={600} mb="sm">Événements live</Text>
          <Stack gap={6}>
            {(liveEvolutionEvents.length ? liveEvolutionEvents : (status?.history ?? []).slice(0, 12)).map((e: any, idx: number) => (
              <Text key={idx} size="xs" ff="monospace" c="dimmed">
                {e.type} {JSON.stringify(e.data ?? e).slice(0, 220)}
              </Text>
            ))}
          </Stack>
        </Paper>
      </Group>

      <Paper p="md" radius="md" withBorder>
        <Title order={4} mb="md">Archive récente</Title>
        {!variants?.length ? (
          <Text size="sm" c="dimmed">Aucune variante.</Text>
        ) : (
          <Table highlightOnHover>
            <Table.Thead>
              <Table.Tr>
                <Table.Th>Variant</Table.Th>
                <Table.Th>Parent</Table.Th>
                <Table.Th>Fitness</Table.Th>
                <Table.Th>Smoke</Table.Th>
                <Table.Th>Cibles</Table.Th>
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {variants.map((v) => (
                <Table.Tr key={v.variant_id}>
                  <Table.Td><Code>{v.variant_id}</Code></Table.Td>
                  <Table.Td><Code>{v.parent_id ?? "—"}</Code></Table.Td>
                  <Table.Td>{v.fitness.toFixed(3)}</Table.Td>
                  <Table.Td>
                    <Badge size="xs" color={v.tests_ok ? "green" : "red"}>{v.tests_ok ? "ok" : "fail"}</Badge>
                  </Table.Td>
                  <Table.Td><Text size="xs">{(v.targets || []).join(", ") || "—"}</Text></Table.Td>
                </Table.Tr>
              ))}
            </Table.Tbody>
          </Table>
        )}
      </Paper>

      <Divider />
      <Text size="sm" c="dimmed">
        Pour la configuration persistante, le lancement sans ligne de commande et les clés/API, utilise le lanceur desktop fourni dans le dossier source.
      </Text>
    </Stack>
  );
}
