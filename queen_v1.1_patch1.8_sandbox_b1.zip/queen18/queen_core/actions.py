"""
actions.py — Actions autonomes pour le dashboard.
Ne dépend PAS de orchestrator.py (qui tourne dans un autre container).
Utilise une instance Memory lazy + thread-safe.
"""

import json
import logging
import os
import threading
from datetime import datetime, timezone
from typing import Dict, Any, Optional

from queen_core.models import Goal, Run, Job, Patch, GoalStatus, JobStatus, RunStatus, PatchStatus
from queen_core.memory import Memory
from queen_core.policy import validate_goal_constraints
from queen_core import policy as policy_mod
from queen_core import redis_bus

logger = logging.getLogger("queen.actions")

# ─── Lazy singleton Memory ────────────────────────────────────────────────────

_memory: Optional[Memory] = None
_memory_lock = threading.Lock()


def get_memory() -> Memory:
    """Thread-safe lazy init of Memory singleton."""
    global _memory
    if _memory is None:
        with _memory_lock:
            if _memory is None:
                os.makedirs("/data", exist_ok=True)
                _memory = Memory("/data/queen.db")
                logger.info("Memory initialized (actions.py)")
    return _memory


# ─── Goal Ingestion ──────────────────────────────────────────────────────────

def ingest_goal(goal_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Crée un goal en DB et publie un event Redis.
    L'orchestrator (dans son container) écoute les events et lance le pipeline.
    """
    mem = get_memory()
    goal = Goal(
        title=goal_data.get("title", "Untitled"),
        description=goal_data.get("description", ""),
        constraints=validate_goal_constraints(goal_data.get("constraints", {})),
    )
    mem.create_goal(goal)
    logger.info(f"Goal ingested: {goal.id} — {goal.title}")

    # Notify orchestrator via Redis
    redis_bus.publish_event("goal_created", {
        "goal_id": goal.id,
        "title": goal.title,
    })
    redis_bus.publish_log("info", "dashboard", f"New goal: {goal.id} — {goal.title}")

    return {"goal_id": goal.id, "status": "pending"}


# ─── Goal Actions ────────────────────────────────────────────────────────────

def pause_goal(goal_id: str) -> Dict[str, Any]:
    mem = get_memory()
    mem.update_goal_status(goal_id, GoalStatus.PAUSED.value)
    redis_bus.publish_event("goal_paused", {"goal_id": goal_id})
    return {"status": "paused"}


def resume_goal(goal_id: str) -> Dict[str, Any]:
    mem = get_memory()
    mem.update_goal_status(goal_id, GoalStatus.RUNNING.value)
    redis_bus.publish_event("goal_resumed", {"goal_id": goal_id})
    return {"status": "running"}


# ─── Job Actions ─────────────────────────────────────────────────────────────

def retry_job(job_id: str) -> Dict[str, Any]:
    mem = get_memory()
    job = mem.get_job(job_id)
    if not job:
        return {"error": "Job not found"}
    mem.update_job(job_id, status=JobStatus.QUEUED.value, started_at="", finished_at="")
    redis_bus.enqueue_job(job)
    return {"status": "requeued"}


# ─── Patch Actions ───────────────────────────────────────────────────────────

def approve_patch(patch_id: str, actor: str = "user") -> Dict[str, Any]:
    mem = get_memory()
    patch = mem.get_patch(patch_id)
    if not patch:
        return {"error": "Patch not found"}
    mem.update_patch(patch_id, status=PatchStatus.APPROVED.value, approved_by=actor)
    mem.audit("approve_patch", "patch", patch_id, actor=actor)
    redis_bus.publish_event("patch_approved", {"patch_id": patch_id})
    return {"status": "approved"}


def apply_patch(patch_id: str, actor: str = "user") -> Dict[str, Any]:
    """Apply a patch with atomic DB updates + file-level compensation.

    Guarantees:
    1. If patcher fails → nothing changes (DB or files)
    2. If DB fails after file writes → files are restored from patcher backup
       + any NEW files created by the patch are deleted
    3. If file restoration fails → explicit error with details
    4. DB updates are in a single SQLite transaction (all-or-nothing)
    """
    from queen_core.patcher import apply_patch as do_apply, rollback as do_rollback

    mem = get_memory()
    patch = mem.get_patch(patch_id)
    if not patch:
        return {"error": "Patch not found"}

    workspace_path = os.path.join(policy_mod.WORKSPACE_BASE, patch['goal_id'])

    # Snapshot which files exist BEFORE the patch (to detect new files)
    pre_existing = set()
    if os.path.isdir(workspace_path):
        for root, _, files in os.walk(workspace_path):
            for fn in files:
                pre_existing.add(os.path.relpath(os.path.join(root, fn), workspace_path))

    # Phase 1: Apply patch to filesystem (patcher creates per-file backups)
    result = do_apply(patch["diff_content"], workspace_path)

    if result.get("failed") and not result.get("applied"):
        # Nothing was applied at all
        mem.update_patch(patch_id, status=PatchStatus.GATES_FAILED.value)
        return {"error": "All files failed to apply", "details": result}

    if result.get("failed"):
        # Partial apply — roll back what was applied
        logger.warning(f"Partial patch apply: {len(result['applied'])} ok, {len(result['failed'])} failed — rolling back")
        backup_dir = result.get("backup_dir", "")
        if backup_dir:
            do_rollback(backup_dir, workspace_path)
            _cleanup_new_files(workspace_path, pre_existing, result.get("applied", []))
        mem.update_patch(patch_id, status=PatchStatus.GATES_FAILED.value)
        return {"error": "Some files failed to apply — rolled back", "details": result}

    # Phase 2: Atomic DB update (single transaction)
    backup_dir = result.get("backup_dir", "")
    now = datetime.now(timezone.utc).isoformat()
    try:
        mem.apply_patch_atomic(
            patch_id=patch_id,
            run_id=patch["run_id"],
            goal_id=patch["goal_id"],
            now=now,
            actor=actor,
            details=result,
        )
    except Exception as db_err:
        # DB failed — rollback files
        logger.error(f"DB transaction failed after patch apply: {db_err}")
        rollback_ok = False
        rollback_detail = ""
        if backup_dir:
            try:
                do_rollback(backup_dir, workspace_path)
                _cleanup_new_files(workspace_path, pre_existing, result.get("applied", []))
                rollback_ok = True
            except Exception as rb_err:
                rollback_detail = str(rb_err)
                logger.error(f"File rollback ALSO failed: {rb_err}")

        if not rollback_ok:
            # Critical: files modified, DB inconsistent, rollback failed
            err_msg = (
                f"CRITICAL: Patch files written, DB transaction failed ({db_err}), "
                f"AND file rollback failed ({rollback_detail}). "
                f"Manual intervention required. Backup dir: {backup_dir}"
            )
            logger.critical(err_msg)
            return {"error": err_msg, "critical": True, "backup_dir": backup_dir}

        return {
            "error": f"DB transaction failed: {db_err}",
            "rolled_back_files": True,
            "files_restored": len(result.get("applied", [])),
        }

    # Phase 3: Non-critical notification
    try:
        redis_bus.publish_event("patch_applied", {
            "patch_id": patch_id, "goal_id": patch["goal_id"],
        })
    except Exception:
        pass

    return {"status": "applied", "details": result}


def _cleanup_new_files(workspace_path: str, pre_existing: set, applied: list) -> None:
    """Delete files that were CREATED by the patch (not just modified).
    These wouldn't be in the patcher's backup since they didn't exist before."""
    for entry in applied:
        rel_path = entry.get("path", "")
        if rel_path and rel_path not in pre_existing:
            full = os.path.join(workspace_path, rel_path)
            try:
                if os.path.isfile(full):
                    os.remove(full)
                    logger.debug(f"Cleaned up new file: {rel_path}")
            except Exception as e:
                logger.warning(f"Failed to clean up new file {rel_path}: {e}")


def reject_patch(patch_id: str, actor: str = "user", reason: str = "") -> Dict[str, Any]:
    mem = get_memory()
    patch = mem.get_patch(patch_id)
    if not patch:
        return {"error": "Patch not found"}
    mem.update_patch(patch_id, status=PatchStatus.REJECTED.value)
    mem.audit("reject_patch", "patch", patch_id, actor=actor, details={"reason": reason})
    redis_bus.publish_event("patch_rejected", {"patch_id": patch_id})
    return {"status": "rejected"}


def rollback_patch(patch_id: str, actor: str = "user") -> Dict[str, Any]:
    from queen_core.patcher import rollback

    mem = get_memory()
    patch = mem.get_patch(patch_id)
    if not patch:
        return {"error": "Patch not found"}

    backup_dir = "/workspace/.queen_backups"
    if os.path.exists(backup_dir):
        backups = sorted(os.listdir(backup_dir), reverse=True)
        if backups:
            result = rollback(
                os.path.join(backup_dir, backups[0]),
                f"/workspace/{patch['goal_id']}",
            )
            mem.update_patch(patch_id, status=PatchStatus.ROLLED_BACK.value)
            mem.update_run(patch["run_id"], status=RunStatus.ROLLED_BACK.value)
            mem.audit("rollback_patch", "patch", patch_id, actor=actor, details=result)
            return {"status": "rolled_back", "details": result}

    return {"error": "No backup found for rollback"}
