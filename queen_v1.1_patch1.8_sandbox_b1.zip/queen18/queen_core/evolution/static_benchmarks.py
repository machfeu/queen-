"""
static_benchmarks.py — Code-quality benchmarks that analyze source without executing it.

Extracted from bench_runner.py for clarity.
Each function: candidate_src → float [0.0, 1.0]
"""

from __future__ import annotations

import ast
import logging
import os
from typing import Any, Callable, Dict, List, Tuple

logger = logging.getLogger("queen.evolution.benchmark")

BenchmarkFn = Callable[[str], float]


def bench_no_dangerous_patterns(candidate_src: str) -> float:
    dangerous = [
        "os.system(", "subprocess.call(", "subprocess.Popen(",
        "eval(", "exec(", "__import__(", "rm -rf",
    ]
    # Files that legitimately reference dangerous patterns (security checks, tests, smoke)
    SKIP_BASENAMES = {"policy.py", "smoke.py", "bench_runner.py", "functional_benchmarks.py",
                      "static_benchmarks.py", "worker_base.py"}
    violations = 0
    total_files = 0
    for root, _, files in os.walk(candidate_src):
        for fn in files:
            if not fn.endswith(".py"):
                continue
            if fn in SKIP_BASENAMES or fn.startswith("test_"):
                continue
            total_files += 1
            try:
                with open(os.path.join(root, fn), "r", encoding="utf-8") as f:
                    content = f.read()
            except Exception:
                continue
            for pat in dangerous:
                if pat in content:
                    if pat == "eval(" and "ast.literal_eval(" in content:
                        cleaned = content.replace("ast.literal_eval(", "")
                        if "eval(" not in cleaned:
                            continue
                    violations += 1
    if total_files == 0:
        return 0.0
    return max(0.0, 1.0 - (violations * 0.15))


def bench_docstrings_present(candidate_src: str) -> float:
    total_defs = 0
    with_doc = 0
    for root, _, files in os.walk(candidate_src):
        for fn in files:
            if not fn.endswith(".py"):
                continue
            path = os.path.join(root, fn)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    source = f.read()
                tree = ast.parse(source, filename=path)
            except Exception:
                continue
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    if node.name.startswith("_") and not node.name.startswith("__"):
                        continue
                    total_defs += 1
                    if ast.get_docstring(node):
                        with_doc += 1
    if total_defs == 0:
        return 0.5
    return with_doc / total_defs


def bench_no_syntax_errors(candidate_src: str) -> float:
    total = 0
    ok = 0
    for root, _, files in os.walk(candidate_src):
        for fn in files:
            if not fn.endswith(".py"):
                continue
            total += 1
            path = os.path.join(root, fn)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    source = f.read()
                ast.parse(source, filename=path)
                ok += 1
            except Exception:
                logger.debug(f"Syntax error in {path}")
    return (ok / total) if total > 0 else 0.0


def bench_error_handling(candidate_src: str) -> float:
    io_functions = 0
    io_with_try = 0
    io_patterns = {"open(", "read(", "write(", "connect(", "execute(", "fetch("}
    for root, _, files in os.walk(candidate_src):
        for fn in files:
            if not fn.endswith(".py"):
                continue
            path = os.path.join(root, fn)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    source = f.read()
                tree = ast.parse(source, filename=path)
            except Exception:
                continue
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    body_src = ast.get_source_segment(source, node) or ""
                    has_io = any(pat in body_src for pat in io_patterns)
                    if has_io:
                        io_functions += 1
                        has_try = any(isinstance(child, ast.Try) for child in ast.walk(node))
                        if has_try:
                            io_with_try += 1
    if io_functions == 0:
        return 0.5
    return io_with_try / io_functions


def bench_function_complexity(candidate_src: str) -> float:
    total_funcs = 0
    oversized = 0
    for root, _, files in os.walk(candidate_src):
        for fn in files:
            if not fn.endswith(".py"):
                continue
            path = os.path.join(root, fn)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    source = f.read()
                tree = ast.parse(source, filename=path)
            except Exception:
                continue
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    total_funcs += 1
                    if hasattr(node, "end_lineno") and node.end_lineno:
                        length = node.end_lineno - node.lineno
                        if length > 80:
                            oversized += 1
    if total_funcs == 0:
        return 0.5
    return max(0.0, 1.0 - (oversized / total_funcs))


STATIC_BENCHMARKS: List[Tuple[str, BenchmarkFn]] = [
    ("static:no_dangerous_patterns", bench_no_dangerous_patterns),
    ("static:docstrings_present", bench_docstrings_present),
    ("static:no_syntax_errors", bench_no_syntax_errors),
    ("static:error_handling", bench_error_handling),
    ("static:function_complexity", bench_function_complexity),
]
