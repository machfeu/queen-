"""selector.py — Parent selection strategy (DGM-like).

We want two things:
- exploit: prefer high-fitness variants
- explore: avoid premature convergence by penalizing variants with many children

This is inspired by the selection heuristic used in DGM: favor variants with
good score but limit over-exploited branches.
"""

from __future__ import annotations

import logging
import random
from typing import Dict, List, Optional, Tuple

from .archive import EvolutionArchive, VariantRecord

logger = logging.getLogger("queen.evolution")


def rank_variants(
    archive: EvolutionArchive,
    child_penalty: float = 0.35,
    top_k: int = 30,
) -> List[Dict[str, object]]:
    """Return ranked candidates with adjusted scores for transparency/UI."""
    variants = archive.list_variants(limit=max(top_k, 50))
    ranked: List[Dict[str, object]] = []
    for v in variants[:top_k]:
        children = archive.child_count(v.variant_id)
        adjusted = float(v.fitness) / (1.0 + child_penalty * max(children, 0))
        ranked.append(
            {
                "variant_id": v.variant_id,
                "fitness": float(v.fitness),
                "children": int(children),
                "adjusted_score": float(adjusted),
                "tests_ok": bool(v.tests_ok),
                "created_at": v.created_at,
            }
        )
    ranked.sort(key=lambda x: (float(x["adjusted_score"]), float(x["fitness"])), reverse=True)
    return ranked


def select_parent(
    archive: EvolutionArchive,
    exploration: float = 0.15,
    child_penalty: float = 0.35,
    top_k: int = 30,
    return_meta: bool = False,
) -> Optional[VariantRecord] | Tuple[Optional[VariantRecord], Dict[str, object]]:
    variants = archive.list_variants(limit=max(top_k, 50))
    if not variants:
        return (None, {"reason": "empty_archive", "exploration": exploration}) if return_meta else None

    if random.random() < exploration:
        chosen = random.choice(variants)
        meta = {
            "reason": "exploration",
            "exploration": exploration,
            "selected_variant_id": chosen.variant_id,
        }
        return (chosen, meta) if return_meta else chosen

    ranked = rank_variants(archive, child_penalty=child_penalty, top_k=top_k)
    best_variant_id = ranked[0]["variant_id"] if ranked else None
    best = next((v for v in variants if v.variant_id == best_variant_id), None)
    meta = {
        "reason": "exploitation",
        "exploration": exploration,
        "selected_variant_id": best_variant_id,
        "ranked": ranked[:10],
    }
    return (best, meta) if return_meta else best
