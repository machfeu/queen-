"""
bench_runner.py — Orchestrates static, functional and user benchmarks.

User benchmarks run in sandboxed subprocesses with timeout — they cannot
crash, hang, or corrupt the main process.

Score computation:
  - static_score:     average of static benchmarks     (weight: 0.35)
  - functional_score: average of functional benchmarks  (weight: 0.65)
  - benchmark_score:  weighted combination
  - user benchmarks are folded into static_score
"""

from __future__ import annotations

import ast
import logging
import os
import subprocess
import sys
import time
from typing import Any, Callable, Dict, List, Tuple

from .static_benchmarks import STATIC_BENCHMARKS
from .functional_benchmarks import FUNCTIONAL_BENCHMARKS

logger = logging.getLogger("queen.evolution.benchmark")

BenchmarkFn = Callable[[str], float]

W_STATIC = 0.35
W_FUNCTIONAL = 0.65

USER_BENCH_TIMEOUT = 15  # seconds per user benchmark


# ═══════════════════════════════════════════════════════════════════════
# User benchmark sandbox
# ═══════════════════════════════════════════════════════════════════════

def _discover_user_benchmark_names(benchmarks_dir: str) -> List[Tuple[str, str, str]]:
    """Discover bench_* function names without executing any user code.

    Returns list of (display_name, file_path, function_name).
    Uses AST parsing — no import, no exec.
    """
    found: List[Tuple[str, str, str]] = []
    if not os.path.isdir(benchmarks_dir):
        return found
    for fn in sorted(os.listdir(benchmarks_dir)):
        if not fn.endswith(".py") or fn.startswith("_"):
            continue
        path = os.path.join(benchmarks_dir, fn)
        try:
            with open(path, "r", encoding="utf-8") as f:
                source = f.read()
            tree = ast.parse(source, filename=path)
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    if node.name.startswith("bench_"):
                        found.append((f"user:{fn}::{node.name}", path, node.name))
        except Exception as e:
            logger.warning(f"Failed to parse benchmark file {fn}: {e}")
    return found


def _run_user_benchmark_sandboxed(
    file_path: str,
    func_name: str,
    candidate_src: str,
    timeout: int = USER_BENCH_TIMEOUT,
) -> Dict[str, Any]:
    """Execute a single user benchmark function in an isolated subprocess.

    The subprocess:
    - imports the file
    - calls func_name(candidate_src)
    - prints the score as last line of stdout
    - is killed after timeout
    """
    # Build a minimal runner script — no eval, just importlib + call
    runner_code = f"""
import importlib.util, sys, os
spec = importlib.util.spec_from_file_location("_user_bench", {file_path!r})
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
fn = getattr(mod, {func_name!r})
score = fn({candidate_src!r})
print(float(score))
"""
    env = dict(os.environ)
    env["PYTHONPATH"] = candidate_src + (
        os.pathsep + env.get("PYTHONPATH", "") if env.get("PYTHONPATH") else ""
    )
    # Strip sensitive vars
    for k in ("REDIS_URL", "OPENAI_API_KEY", "QUEEN_API_KEY"):
        env.pop(k, None)

    t0 = time.time()
    try:
        proc = subprocess.run(
            [sys.executable, "-c", runner_code],
            env=env,
            cwd=os.path.dirname(file_path),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            text=True,
        )
        elapsed = time.time() - t0

        if proc.returncode != 0:
            err = proc.stderr.strip()[-500:] if proc.stderr else f"exit code {proc.returncode}"
            logger.debug(f"User benchmark {func_name} failed: {err}")
            return {"score": 0.0, "time_s": round(elapsed, 3), "error": err, "sandboxed": True}

        # Parse score from last line of stdout
        lines = proc.stdout.strip().splitlines()
        if lines:
            try:
                score = max(0.0, min(1.0, float(lines[-1])))
                return {"score": score, "time_s": round(elapsed, 3), "error": None, "sandboxed": True}
            except ValueError:
                # stdout exists but last line isn't a float → score 0
                logger.debug(f"User benchmark {func_name}: unparseable output: {lines[-1]!r}")
                return {"score": 0.0, "time_s": round(elapsed, 3),
                        "error": f"Unparseable score output: {lines[-1]!r}", "sandboxed": True}
        # Empty stdout with exit 0 → score 0 (no result is not a pass)
        return {"score": 0.0, "time_s": round(elapsed, 3),
                "error": "No score output on stdout", "sandboxed": True}

    except subprocess.TimeoutExpired:
        elapsed = time.time() - t0
        logger.warning(f"User benchmark {func_name} timed out after {timeout}s")
        return {"score": 0.0, "time_s": round(elapsed, 3), "error": f"Timeout after {timeout}s", "sandboxed": True}
    except Exception as e:
        elapsed = time.time() - t0
        return {"score": 0.0, "time_s": round(elapsed, 3), "error": str(e), "sandboxed": True}


# ═══════════════════════════════════════════════════════════════════════
# Internal benchmark runner (trusted code only)
# ═══════════════════════════════════════════════════════════════════════

def _run_one(name: str, fn: BenchmarkFn, candidate_src: str) -> Dict[str, Any]:
    """Run a single TRUSTED benchmark (static or functional) with timing."""
    t0 = time.time()
    try:
        score = fn(candidate_src)
        score = max(0.0, min(1.0, float(score)))
        elapsed = time.time() - t0
        return {"score": score, "time_s": round(elapsed, 3), "error": None}
    except Exception as e:
        elapsed = time.time() - t0
        logger.warning(f"Benchmark {name} failed: {e}")
        return {"score": 0.0, "time_s": round(elapsed, 3), "error": str(e)}


# ═══════════════════════════════════════════════════════════════════════
# Main orchestrator
# ═══════════════════════════════════════════════════════════════════════

def run_benchmarks(
    candidate_src: str,
    benchmarks_dir: str = "",
) -> Dict[str, Any]:
    """Run all benchmarks (static + functional + sandboxed user)."""

    # Static benchmarks (trusted, in-process)
    static_results: Dict[str, Dict[str, Any]] = {}
    static_scores: List[float] = []
    for name, fn in STATIC_BENCHMARKS:
        r = _run_one(name, fn, candidate_src)
        static_results[name] = r
        static_scores.append(r["score"])

    # Functional benchmarks (trusted, subprocess)
    functional_results: Dict[str, Dict[str, Any]] = {}
    functional_scores: List[float] = []
    for name, fn in FUNCTIONAL_BENCHMARKS:
        r = _run_one(name, fn, candidate_src)
        functional_results[name] = r
        functional_scores.append(r["score"])

    # User benchmarks (UNTRUSTED — sandboxed subprocess with timeout)
    user_results: Dict[str, Dict[str, Any]] = {}
    if benchmarks_dir:
        user_entries = _discover_user_benchmark_names(benchmarks_dir)
        for display_name, file_path, func_name in user_entries:
            r = _run_user_benchmark_sandboxed(file_path, func_name, candidate_src)
            user_results[display_name] = r
            # User benchmarks count toward static score
            static_scores.append(r["score"])

    # Compute aggregates
    static_avg = sum(static_scores) / len(static_scores) if static_scores else 0.0
    functional_avg = sum(functional_scores) / len(functional_scores) if functional_scores else 0.0

    if functional_scores and static_scores:
        benchmark_score = W_STATIC * static_avg + W_FUNCTIONAL * functional_avg
    elif functional_scores:
        benchmark_score = functional_avg
    elif static_scores:
        benchmark_score = static_avg
    else:
        benchmark_score = 0.0

    all_results = {**static_results, **functional_results, **user_results}

    return {
        "benchmark_score": round(benchmark_score, 4),
        "static_score": round(static_avg, 4),
        "functional_score": round(functional_avg, 4),
        "benchmark_count": len(all_results),
        "static_count": len(static_scores),
        "functional_count": len(functional_scores),
        "user_count": len(user_results),
        "benchmark_results": all_results,
    }
