"""
migrations.py — Minimal SQLite migration system for Queen.

Version 1B: No framework, no ORM. Just a list of SQL migration steps
executed in order, tracked via a schema_version table.

Usage (called from init_db):
    from queen_core.migrations import run_migrations
    run_migrations(conn)
"""

import logging
import sqlite3
from typing import List, Tuple

logger = logging.getLogger("queen.migrations")

# Each migration: (version_number, description, sql_statements)
# version_number must be strictly increasing.
# SQL is a list of statements (not executescript) so we can handle errors per statement.

MIGRATIONS: List[Tuple[int, str, List[str]]] = [
    (
        1,
        "Initial schema — baseline from patch 1.7",
        [
            # This migration is a no-op if tables already exist (CREATE IF NOT EXISTS).
            # It establishes version 1 as the baseline.
            """CREATE TABLE IF NOT EXISTS goals (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                description TEXT DEFAULT '',
                constraints TEXT DEFAULT '{}',
                status TEXT DEFAULT 'pending',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )""",
            """CREATE TABLE IF NOT EXISTS runs (
                id TEXT PRIMARY KEY,
                goal_id TEXT NOT NULL,
                status TEXT DEFAULT 'running',
                plan TEXT DEFAULT '[]',
                score REAL DEFAULT 0.0,
                score_justification TEXT DEFAULT '',
                patch_id TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                finished_at TEXT DEFAULT '',
                FOREIGN KEY (goal_id) REFERENCES goals(id)
            )""",
            """CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                goal_id TEXT NOT NULL,
                job_type TEXT NOT NULL,
                payload TEXT DEFAULT '{}',
                status TEXT DEFAULT 'queued',
                result TEXT DEFAULT '{}',
                logs TEXT DEFAULT '',
                worker_id TEXT DEFAULT '',
                timeout_seconds INTEGER DEFAULT 300,
                max_output_bytes INTEGER DEFAULT 10000000,
                created_at TEXT NOT NULL,
                started_at TEXT DEFAULT '',
                finished_at TEXT DEFAULT '',
                FOREIGN KEY (run_id) REFERENCES runs(id),
                FOREIGN KEY (goal_id) REFERENCES goals(id)
            )""",
            """CREATE TABLE IF NOT EXISTS patches (
                id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                goal_id TEXT NOT NULL,
                diff_content TEXT DEFAULT '',
                status TEXT DEFAULT 'generated',
                gate_results TEXT DEFAULT '{}',
                applied_at TEXT DEFAULT '',
                approved_by TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                FOREIGN KEY (run_id) REFERENCES runs(id),
                FOREIGN KEY (goal_id) REFERENCES goals(id)
            )""",
            """CREATE TABLE IF NOT EXISTS audit_log (
                id TEXT PRIMARY KEY,
                timestamp TEXT NOT NULL,
                action TEXT NOT NULL,
                entity_type TEXT DEFAULT '',
                entity_id TEXT DEFAULT '',
                actor TEXT DEFAULT 'system',
                details TEXT DEFAULT '{}'
            )""",
            "CREATE INDEX IF NOT EXISTS idx_jobs_run_id ON jobs(run_id)",
            "CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status)",
            "CREATE INDEX IF NOT EXISTS idx_runs_goal_id ON runs(goal_id)",
            "CREATE INDEX IF NOT EXISTS idx_patches_run_id ON patches(run_id)",
            "CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_log(entity_type, entity_id)",
        ],
    ),
    (
        2,
        "Version 1B — add schema_version tracking (self-referential bootstrap)",
        [
            # This is a no-op since we create the table before running migrations.
            # It exists to mark the transition to versioned schema.
        ],
    ),
    # ─── Future migrations go here ──────────────────────────
    # (3, "Add benchmark_score column to some table", ["ALTER TABLE ..."]),
]


def _ensure_version_table(conn: sqlite3.Connection) -> None:
    """Create the schema_version table if it doesn't exist."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS schema_version (
            version INTEGER PRIMARY KEY,
            description TEXT NOT NULL,
            applied_at TEXT NOT NULL
        )
    """)
    conn.commit()


def _get_current_version(conn: sqlite3.Connection) -> int:
    """Return the highest applied migration version, or 0 if none."""
    try:
        row = conn.execute("SELECT MAX(version) FROM schema_version").fetchone()
        return row[0] if row and row[0] is not None else 0
    except sqlite3.OperationalError:
        return 0


def run_migrations(conn: sqlite3.Connection) -> int:
    """
    Run all pending migrations.

    Returns the number of migrations applied.
    Safe to call multiple times (idempotent).
    """
    _ensure_version_table(conn)
    current = _get_current_version(conn)
    applied = 0

    for version, description, statements in MIGRATIONS:
        if version <= current:
            continue

        logger.info(f"Applying migration v{version}: {description}")
        try:
            for sql in statements:
                sql = sql.strip()
                if sql:
                    conn.execute(sql)

            # Record the migration
            from datetime import datetime, timezone
            now = datetime.now(timezone.utc).isoformat()
            conn.execute(
                "INSERT INTO schema_version (version, description, applied_at) VALUES (?, ?, ?)",
                (version, description, now),
            )
            conn.commit()
            applied += 1
            logger.info(f"Migration v{version} applied successfully")

        except Exception as e:
            logger.error(f"Migration v{version} failed: {e}")
            conn.rollback()
            raise RuntimeError(f"Migration v{version} failed: {e}") from e

    if applied:
        logger.info(f"Migrations complete: {applied} applied, now at v{_get_current_version(conn)}")
    return applied


def get_schema_info(conn: sqlite3.Connection) -> dict:
    """Return current schema version and migration history."""
    _ensure_version_table(conn)
    current = _get_current_version(conn)
    try:
        rows = conn.execute("SELECT version, description, applied_at FROM schema_version ORDER BY version").fetchall()
        history = [{"version": r[0], "description": r[1], "applied_at": r[2]} for r in rows]
    except Exception:
        history = []
    return {"current_version": current, "history": history, "latest_available": MIGRATIONS[-1][0] if MIGRATIONS else 0}
