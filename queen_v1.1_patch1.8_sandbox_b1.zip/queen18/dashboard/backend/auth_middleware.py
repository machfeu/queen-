"""
auth_middleware.py — Authentification unifiée pour Queen V1 Dashboard.
Patch 1.6.1 — Accepte X-API-Key ET Authorization: Bearer <key>.
Le frontend envoie Bearer, les appels API/curl envoient X-API-Key.
Les deux sont comparés au même QUEEN_API_KEY.
"""

import hmac
import logging
import os
import secrets
from typing import Optional

from fastapi import Request, HTTPException, Security
from fastapi.security import APIKeyHeader

logger = logging.getLogger("queen.auth")

API_KEY_HEADER = APIKeyHeader(name="X-API-Key", auto_error=False)
QUEEN_API_KEY = os.getenv("QUEEN_API_KEY", "")

PUBLIC_ENDPOINTS = frozenset({
    "/docs", "/openapi.json", "/redoc",
    "/health", "/api/health",
})

_SENSITIVE_WORDS = ("key", "secret", "password", "token", "credential")


def _constant_time_compare(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


def _extract_key_from_request(request: Request, api_key_header: Optional[str]) -> Optional[str]:
    """
    Extrait la clé depuis (priorité) :
      1. Header X-API-Key
      2. Header Authorization: Bearer <key>
      3. Query param ?token=<key>  (WebSocket handshake)
    """
    if api_key_header:
        return api_key_header

    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()

    token = request.query_params.get("token")
    if token:
        return token

    return None


async def verify_api_key(
    request: Request,
    api_key: Optional[str] = Security(API_KEY_HEADER),
) -> Optional[str]:
    """Dépendance FastAPI globale — REST + WebSocket passent ici."""
    if request.url.path in PUBLIC_ENDPOINTS:
        return None

    if not QUEEN_API_KEY:
        return None

    key = _extract_key_from_request(request, api_key)

    if not key:
        raise HTTPException(
            status_code=401,
            detail="Missing API key. Use X-API-Key header, Authorization: Bearer, or ?token= query param.",
        )

    if not _constant_time_compare(key, QUEEN_API_KEY):
        raise HTTPException(status_code=403, detail="Invalid API key.")

    return key


async def verify_ws_token(token: Optional[str]) -> bool:
    """Vérifie un token WebSocket. True si OK ou si auth désactivée."""
    if not QUEEN_API_KEY:
        return True
    if not token:
        return False
    return _constant_time_compare(token, QUEEN_API_KEY)


def filter_sensitive_settings(settings: dict) -> dict:
    """Masque les valeurs contenant des mots-clés sensibles."""
    filtered = {}
    for key, value in settings.items():
        lower_key = key.lower()
        if any(sw in lower_key for sw in _SENSITIVE_WORDS):
            filtered[key] = "***REDACTED***"
        else:
            filtered[key] = value
    return filtered


def generate_api_key() -> str:
    return secrets.token_hex(32)
