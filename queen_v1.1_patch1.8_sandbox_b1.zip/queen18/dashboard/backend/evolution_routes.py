"""evolution_routes.py — Endpoints API for the evolution archive and control.

Originally read-only. Extended here with a small control plane so the dashboard
can start/stop an evolution run and visualize it in real time.
"""

import json
from typing import Any, Dict, List

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from queen_core.evolution.archive import EvolutionArchive
from queen_core.evolution.selector import rank_variants
from dashboard.backend.evolution_manager import manager


evolution_router = APIRouter(prefix="/api/evolution", tags=["Evolution"])


class EvolutionStartRequest(BaseModel):
    iterations: int = Field(default=5, ge=1, le=200)
    max_files: int = Field(default=2, ge=1, le=10)
    exploration: float = Field(default=0.15, ge=0.0, le=1.0)
    dry_run: bool = False
    instruction: str = Field(default="Improve reliability and bug-resilience without changing external behavior.")
    allowlist: str = Field(default="")
    targets: str = Field(default="")



def _loads_list(s: str):
    try:
        return json.loads(s) if s else []
    except Exception:
        return []



def _serialize_variant(v) -> Dict[str, Any]:
    return {
        "variant_id": v.variant_id,
        "parent_id": v.parent_id,
        "created_at": v.created_at,
        "fitness": v.fitness,
        "tests_ok": bool(v.tests_ok),
        "targets": _loads_list(v.targets),
        "tags": _loads_list(v.tags),
        "patch_path": v.patch_path,
        "snapshot_path": v.snapshot_path,
    }


@evolution_router.get("/variants")
def list_variants(limit: int = 200):
    a = EvolutionArchive()
    vs = a.list_variants(limit=limit)
    return [_serialize_variant(v) for v in vs]


@evolution_router.get("/variants/{variant_id}")
def get_variant(variant_id: str):
    a = EvolutionArchive()
    v = a.get_variant(variant_id)
    if not v:
        raise HTTPException(status_code=404, detail="variant not found")
    data = _serialize_variant(v)
    data["metrics"] = v.metrics
    return data


@evolution_router.get("/lineage/{variant_id}")
def get_lineage(variant_id: str, max_depth: int = 50):
    a = EvolutionArchive()
    chain = a.lineage(variant_id, max_depth=max_depth)
    if not chain:
        raise HTTPException(status_code=404, detail="variant not found")
    return [
        {
            "variant_id": v.variant_id,
            "parent_id": v.parent_id,
            "created_at": v.created_at,
            "fitness": v.fitness,
            "tests_ok": bool(v.tests_ok),
        }
        for v in chain
    ]


@evolution_router.get("/ranking")
def get_ranking(top_k: int = 20):
    a = EvolutionArchive()
    return rank_variants(a, top_k=top_k)


@evolution_router.get("/status")
def get_status():
    return manager.status()


@evolution_router.post("/start")
def start_evolution(payload: EvolutionStartRequest):
    result = manager.start(payload.model_dump())
    if not result.get("ok"):
        raise HTTPException(status_code=409, detail=result.get("detail", "unable to start evolution"))
    return result


@evolution_router.post("/stop")
def stop_evolution():
    result = manager.stop()
    if not result.get("ok"):
        raise HTTPException(status_code=409, detail=result.get("detail", "unable to stop evolution"))
    return result


# ═══════════════════════════════════════════════════════════════
# LOT 1 (patch 1.8) — Promotion + Rollback
# ═══════════════════════════════════════════════════════════════

from queen_core.evolution.evolver import promote_variant, rollback_promotion, get_promotion_status, list_promotion_backups


@evolution_router.post("/promote/{variant_id}")
def promote(variant_id: str):
    """Promote a variant into the live workspace (target is always WORKSPACE_BASE)."""
    result = promote_variant(variant_id)
    if not result.get("ok"):
        raise HTTPException(status_code=400, detail=result.get("error", "promotion failed"))
    return result


class RollbackRequest(BaseModel):
    backup_id: str = Field(default="", description="Specific backup ID (empty = rollback last)")


@evolution_router.post("/rollback")
def rollback(payload: RollbackRequest = RollbackRequest()):
    """Rollback the last (or specified) promotion."""
    result = rollback_promotion(backup_id=payload.backup_id or None)
    if not result.get("ok"):
        raise HTTPException(status_code=400, detail=result.get("error", "rollback failed"))
    return result


@evolution_router.get("/promotion")
def promotion_status():
    """Get info about the last promotion."""
    return get_promotion_status()


@evolution_router.get("/promotion/backups")
def promotion_backups():
    """List all promotion backups."""
    return list_promotion_backups()
