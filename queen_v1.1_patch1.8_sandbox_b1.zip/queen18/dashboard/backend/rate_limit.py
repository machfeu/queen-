"""
rate_limit.py — Simple in-memory rate limiter for Queen Dashboard API.
Version 1B — no external dependency, per-IP sliding window.
"""

import time
import threading
from collections import defaultdict
from typing import Dict, List, Tuple


class RateLimiter:
    """Thread-safe in-memory rate limiter. Sliding window per key."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._buckets: Dict[str, List[float]] = defaultdict(list)

    def check(self, key: str, max_calls: int, window_seconds: float) -> Tuple[bool, int]:
        """Check if key is within limits. Returns (allowed, remaining)."""
        now = time.monotonic()
        cutoff = now - window_seconds

        with self._lock:
            bucket = self._buckets[key]
            self._buckets[key] = bucket = [t for t in bucket if t > cutoff]

            if len(bucket) >= max_calls:
                return False, 0

            bucket.append(now)
            return True, max_calls - len(bucket)

    def cleanup(self, max_age: float = 300.0) -> int:
        """Remove stale buckets."""
        now = time.monotonic()
        removed = 0
        with self._lock:
            stale = [k for k, v in self._buckets.items() if not v or v[-1] < now - max_age]
            for k in stale:
                del self._buckets[k]
                removed += 1
        return removed


# Singleton
_limiter = RateLimiter()


def get_limiter() -> RateLimiter:
    return _limiter


def rate_limit_dependency(max_calls: int = 10, window_seconds: float = 60.0):
    """FastAPI dependency factory. Import FastAPI only at call time."""
    async def _check(request):
        from fastapi import HTTPException
        client_ip = request.client.host if request.client else "unknown"
        key = f"{client_ip}:{request.url.path}"
        allowed, remaining = _limiter.check(key, max_calls, window_seconds)
        if not allowed:
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded: max {max_calls} requests per {window_seconds}s. Try again later.",
                headers={"Retry-After": str(int(window_seconds))},
            )
    return _check
