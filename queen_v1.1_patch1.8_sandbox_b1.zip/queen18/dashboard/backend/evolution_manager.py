"""evolution_manager.py — Background control plane for evolution runs.

Allows the dashboard to trigger, stop and inspect the DGM-like evolution loop
without using the command line.
"""

from __future__ import annotations

import copy
import os
import threading
import time
from typing import Any, Dict, List, Optional

from queen_core.evolution.evolver import DEFAULT_ALLOWLIST, run_evolution
from queen_core.evolution.selector import rank_variants
from queen_core.evolution.archive import EvolutionArchive


class EvolutionManager:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._stop_event: Optional[threading.Event] = None
        self._history: List[Dict[str, Any]] = []
        self._status: Dict[str, Any] = {
            "running": False,
            "started_at": None,
            "finished_at": None,
            "last_error": None,
            "last_summary": None,
            "config": self.default_config(),
            "current": None,
        }

    def default_config(self) -> Dict[str, Any]:
        return {
            "iterations": int(os.getenv("EVOLUTION_ITERS", "5")),
            "max_files": int(os.getenv("EVOLUTION_MAX_FILES", "2")),
            "exploration": float(os.getenv("EVOLUTION_EXPLORATION", "0.15")),
            "dry_run": False,
            "instruction": os.getenv(
                "EVOLUTION_INSTRUCTION",
                "Improve reliability and bug-resilience without changing external behavior.",
            ),
            "allowlist": os.getenv("EVOLUTION_ALLOWLIST", "") or ",".join(DEFAULT_ALLOWLIST),
            "targets": os.getenv("EVOLUTION_TARGETS", "") or ",".join(DEFAULT_ALLOWLIST[:2]),
        }

    def _parse_csv(self, value: str) -> List[str]:
        return [x.strip() for x in (value or "").split(",") if x.strip()]

    def _push_history(self, event: Dict[str, Any]) -> None:
        with self._lock:
            self._history.insert(0, event)
            del self._history[200:]
            self._status["current"] = event
            if event.get("type") in {"evolution_completed", "evolution_stopped", "evolution_error"}:
                self._status["finished_at"] = time.time()

    def _on_progress(self, event: Dict[str, Any]) -> None:
        event.setdefault("ts", time.time())
        self._push_history(event)

    def start(self, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        with self._lock:
            if self._thread and self._thread.is_alive():
                return {"ok": False, "detail": "Evolution already running"}

            config = self.default_config()
            if payload:
                config.update({k: v for k, v in payload.items() if v is not None})
            self._status.update(
                {
                    "running": True,
                    "started_at": time.time(),
                    "finished_at": None,
                    "last_error": None,
                    "last_summary": None,
                    "config": copy.deepcopy(config),
                    "current": None,
                }
            )
            self._history = []
            self._stop_event = threading.Event()

            def worker() -> None:
                try:
                    summary = run_evolution(
                        iterations=int(config.get("iterations", 5)),
                        instruction=str(config.get("instruction", "")),
                        targets=self._parse_csv(str(config.get("targets", ""))) or None,
                        allowlist=self._parse_csv(str(config.get("allowlist", ""))) or DEFAULT_ALLOWLIST,
                        max_files=int(config.get("max_files", 2)),
                        exploration=float(config.get("exploration", 0.15)),
                        dry_run=bool(config.get("dry_run", False)),
                        stop_event=self._stop_event,
                        on_progress=self._on_progress,
                    )
                    with self._lock:
                        self._status["last_summary"] = summary
                except Exception as e:
                    with self._lock:
                        self._status["last_error"] = str(e)
                    self._push_history({"type": "evolution_error", "error": str(e)})
                finally:
                    with self._lock:
                        self._status["running"] = False
                        self._status["finished_at"] = time.time()

            self._thread = threading.Thread(target=worker, name="queen-evolution-manager", daemon=True)
            self._thread.start()
            return {"ok": True, "status": self.status()}

    def stop(self) -> Dict[str, Any]:
        with self._lock:
            if not self._thread or not self._thread.is_alive() or not self._stop_event:
                return {"ok": False, "detail": "Evolution not running"}
            self._stop_event.set()
            return {"ok": True}

    def status(self) -> Dict[str, Any]:
        with self._lock:
            out = copy.deepcopy(self._status)
            out["history"] = copy.deepcopy(self._history[:50])
        try:
            archive = EvolutionArchive()
            ranked = rank_variants(archive, top_k=20)
            out["top_variants"] = ranked[:10]
            variants = archive.list_variants(limit=1)
            out["best_variant_id"] = variants[0].variant_id if variants else None
            out["variants_total"] = len(archive.list_variants(limit=500))
        except Exception as e:
            out["archive_error"] = str(e)
            out.setdefault("top_variants", [])
        return out


manager = EvolutionManager()
