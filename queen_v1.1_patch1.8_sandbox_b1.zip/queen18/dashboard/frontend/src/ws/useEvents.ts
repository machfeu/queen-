/**
 * useEvents.ts — Hook WebSocket pour les événements temps réel.
 * Patch 1.6.1 LOT 2: Envoie le token en query param ?token=<key>
 * pour que le backend puisse authentifier la connexion WS.
 */

import { createContext, useContext, useEffect, useRef, useState, useCallback } from "react";
import type { ReactNode } from "react";
import React from "react";
import { getApiKey } from "../api/client";

export interface WsEvent {
  type: string;
  data: Record<string, unknown>;
  timestamp: number;
}

interface EventsCtx {
  events: WsEvent[];
  connected: boolean;
}

const Ctx = createContext<EventsCtx>({ events: [], connected: false });

const MAX_EVENTS = 50;
const RECONNECT_MS = 3_000;

export function EventsProvider({ children }: { children: ReactNode }) {
  const [events, setEvents] = useState<WsEvent[]>([]);
  const [connected, setConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectRef = useRef<ReturnType<typeof setTimeout>>();

  const connect = useCallback(() => {
    try {
      const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
      let url = `${proto}//${window.location.host}/ws/events`;

      // LOT 2: Ajouter le token en query param pour auth WS
      const key = getApiKey();
      if (key) {
        url += `?token=${encodeURIComponent(key)}`;
      }

      const ws = new WebSocket(url);

      ws.onopen = () => setConnected(true);

      ws.onmessage = (msg) => {
        try {
          const evt: WsEvent = JSON.parse(msg.data);
          setEvents((prev) => [evt, ...prev].slice(0, MAX_EVENTS));
        } catch { /* ignore malformed */ }
      };

      ws.onclose = () => {
        setConnected(false);
        reconnectRef.current = setTimeout(connect, RECONNECT_MS);
      };

      ws.onerror = () => ws.close();

      wsRef.current = ws;
    } catch {
      reconnectRef.current = setTimeout(connect, RECONNECT_MS);
    }
  }, []);

  useEffect(() => {
    connect();
    return () => {
      wsRef.current?.close();
      if (reconnectRef.current) clearTimeout(reconnectRef.current);
    };
  }, [connect]);

  return React.createElement(Ctx.Provider, { value: { events, connected } }, children);
}

export function useEvents() {
  return useContext(Ctx);
}
