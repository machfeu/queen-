"""
test_version_1b.py — Tests for the 4 stabilization fixes.

Run: python3 test_version_1b.py
"""

import os
import shutil
import sqlite3
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


# ═══════════════════════════════════════════════════════════════
# Correctif 1 — Rate Limiter
# ═══════════════════════════════════════════════════════════════

def test_rate_limiter_allows_within_limit():
    from dashboard.backend.rate_limit import RateLimiter
    rl = RateLimiter()
    for i in range(5):
        allowed, remaining = rl.check("test-ip:/api/goals", max_calls=5, window_seconds=60)
        assert allowed, f"Should be allowed at call {i+1}"
    print("PASS: test_rate_limiter_allows_within_limit")


def test_rate_limiter_blocks_over_limit():
    from dashboard.backend.rate_limit import RateLimiter
    rl = RateLimiter()
    for i in range(3):
        rl.check("test-block:/api/goals", max_calls=3, window_seconds=60)
    allowed, remaining = rl.check("test-block:/api/goals", max_calls=3, window_seconds=60)
    assert not allowed, "Should be blocked at call 4"
    assert remaining == 0
    print("PASS: test_rate_limiter_blocks_over_limit")


def test_rate_limiter_window_expires():
    from dashboard.backend.rate_limit import RateLimiter
    rl = RateLimiter()
    # Use a tiny window
    for i in range(2):
        rl.check("test-expire:/x", max_calls=2, window_seconds=0.1)
    allowed, _ = rl.check("test-expire:/x", max_calls=2, window_seconds=0.1)
    assert not allowed, "Should be blocked"
    time.sleep(0.15)
    allowed, _ = rl.check("test-expire:/x", max_calls=2, window_seconds=0.1)
    assert allowed, "Should be allowed after window expires"
    print("PASS: test_rate_limiter_window_expires")


def test_rate_limiter_separate_keys():
    from dashboard.backend.rate_limit import RateLimiter
    rl = RateLimiter()
    for i in range(3):
        rl.check("ip-a:/api/goals", max_calls=3, window_seconds=60)
    # ip-a exhausted
    allowed, _ = rl.check("ip-a:/api/goals", max_calls=3, window_seconds=60)
    assert not allowed
    # ip-b should still work
    allowed, _ = rl.check("ip-b:/api/goals", max_calls=3, window_seconds=60)
    assert allowed
    print("PASS: test_rate_limiter_separate_keys")


# ═══════════════════════════════════════════════════════════════
# Correctif 2 — Workspace path validation
# ═══════════════════════════════════════════════════════════════

def test_workspace_normal_path_allowed():
    """Normal subpath should pass validation."""
    base = os.path.realpath("/workspace") if os.path.isdir("/workspace") else os.path.realpath("/tmp")
    target = os.path.realpath(os.path.join(base, "subdir"))
    try:
        common = os.path.commonpath([base, target])
        assert common == base, f"commonpath should be base, got {common}"
    except ValueError:
        pass  # different drives, skip
    print("PASS: test_workspace_normal_path_allowed")


def test_workspace_dotdot_rejected():
    """Path with .. should be caught."""
    path = "../../../etc/passwd"
    parts = path.split("/")
    assert ".." in parts, "Test setup error"
    print("PASS: test_workspace_dotdot_rejected")


def test_workspace_prefix_attack_rejected():
    """Path like /workspaceevil should NOT be under /workspace."""
    base = "/workspace"
    evil = "/workspaceevil/foo"
    base_r = os.path.realpath(base) if os.path.isdir(base) else "/workspace"
    evil_r = evil  # can't realpath nonexistent, but the logic is the same
    # Simulate the check
    try:
        common = os.path.commonpath([base_r, evil_r])
        assert common != base_r, f"Evil path should not share commonpath with base"
    except ValueError:
        pass  # different drives = also rejected
    print("PASS: test_workspace_prefix_attack_rejected")


# ═══════════════════════════════════════════════════════════════
# Correctif 3 — Patch apply DB consistency
# ═══════════════════════════════════════════════════════════════

def test_apply_patch_rollback_on_db_failure():
    """If DB update fails after file write, files should be restored via patcher's backup."""
    tmpdir = tempfile.mkdtemp()
    try:
        workspace = os.path.join(tmpdir, "workspace")
        os.makedirs(workspace)
        original_content = "# original content\nprint(1)\n"
        with open(os.path.join(workspace, "test.py"), "w") as f:
            f.write(original_content)

        from queen_core.patcher import generate_diff, apply_patch as do_apply, rollback as do_rollback
        import queen_core.patcher as patcher_mod
        import queen_core.policy as policy_mod

        # Temporarily override workspace base for validation
        old_base = patcher_mod.WORKSPACE_BASE
        old_policy_base = policy_mod.WORKSPACE_BASE
        patcher_mod.WORKSPACE_BASE = workspace
        policy_mod.WORKSPACE_BASE = workspace

        try:
            # Generate a proper diff
            diff = generate_diff(
                os.path.join(workspace, "test.py"),
                "# PATCHED content\nprint(42)\n",
                filename="test.py",
            )
            assert diff, "Diff should not be empty"

            # Apply the patch
            result = do_apply(diff, workspace)
            backup_dir = result.get("backup_dir", "")
            assert result.get("applied"), f"Apply should have worked: {result}"

            # Verify file was changed
            with open(os.path.join(workspace, "test.py")) as f:
                content = f.read()
            assert "PATCHED" in content, f"File should be patched, got: {content}"

            # Simulate DB failure → rollback from backup
            assert backup_dir and os.path.isdir(backup_dir), f"Backup dir should exist: {backup_dir}"
            do_rollback(backup_dir, workspace)

            # Verify file is restored
            with open(os.path.join(workspace, "test.py")) as f:
                content = f.read()
            assert "original" in content, f"File should be restored, got: {content}"

            print("PASS: test_apply_patch_rollback_on_db_failure")
        finally:
            patcher_mod.WORKSPACE_BASE = old_base
            policy_mod.WORKSPACE_BASE = old_policy_base
    finally:
        shutil.rmtree(tmpdir)


# ═══════════════════════════════════════════════════════════════
# Correctif 4 — Migrations SQLite
# ═══════════════════════════════════════════════════════════════

def test_migrations_empty_db():
    """Migrations should create all tables on empty DB."""
    tmpdir = tempfile.mkdtemp()
    try:
        db_path = os.path.join(tmpdir, "test.db")
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row

        from queen_core.migrations import run_migrations, get_schema_info
        applied = run_migrations(conn)
        assert applied >= 2, f"Expected at least 2 migrations, got {applied}"

        # Verify tables exist
        tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
        for t in ("goals", "runs", "jobs", "patches", "audit_log", "schema_version"):
            assert t in tables, f"Table {t} missing"

        info = get_schema_info(conn)
        assert info["current_version"] >= 2
        print(f"PASS: test_migrations_empty_db (v{info['current_version']}, {applied} applied)")
        conn.close()
    finally:
        shutil.rmtree(tmpdir)


def test_migrations_existing_db():
    """Migrations should be idempotent on already-initialized DB."""
    tmpdir = tempfile.mkdtemp()
    try:
        db_path = os.path.join(tmpdir, "test.db")
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row

        from queen_core.migrations import run_migrations, get_schema_info

        # Run once
        run_migrations(conn)
        v1 = get_schema_info(conn)["current_version"]

        # Run again — should be no-op
        applied = run_migrations(conn)
        v2 = get_schema_info(conn)["current_version"]
        assert applied == 0, f"Second run should apply 0, got {applied}"
        assert v1 == v2

        # Verify data integrity — insert and read
        conn.execute("INSERT INTO goals (id, title, created_at, updated_at) VALUES ('g1', 'test', '2025', '2025')")
        conn.commit()
        row = conn.execute("SELECT title FROM goals WHERE id='g1'").fetchone()
        assert row[0] == "test"

        print(f"PASS: test_migrations_existing_db (v{v2}, 0 re-applied)")
        conn.close()
    finally:
        shutil.rmtree(tmpdir)


def test_migrations_init_db_integration():
    """init_db should use migrations and produce a working DB."""
    tmpdir = tempfile.mkdtemp()
    try:
        db_path = os.path.join(tmpdir, "queen.db")
        from queen_core.models import init_db
        conn = init_db(db_path)

        # Should have all tables
        tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
        for t in ("goals", "runs", "jobs", "patches", "schema_version"):
            assert t in tables, f"Table {t} missing after init_db"

        # Should be able to re-init without error
        conn2 = init_db(db_path)
        conn2.close()

        print("PASS: test_migrations_init_db_integration")
        conn.close()
    finally:
        shutil.rmtree(tmpdir)


# ═══════════════════════════════════════════════════════════════
# Runner
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    tests = [
        # Correctif 1
        test_rate_limiter_allows_within_limit,
        test_rate_limiter_blocks_over_limit,
        test_rate_limiter_window_expires,
        test_rate_limiter_separate_keys,
        # Correctif 2
        test_workspace_normal_path_allowed,
        test_workspace_dotdot_rejected,
        test_workspace_prefix_attack_rejected,
        # Correctif 3
        test_apply_patch_rollback_on_db_failure,
        # Correctif 4
        test_migrations_empty_db,
        test_migrations_existing_db,
        test_migrations_init_db_integration,
    ]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"FAIL: {t.__name__} — {e}")
            import traceback; traceback.print_exc()
            failed += 1
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    if failed:
        sys.exit(1)
    print("ALL TESTS PASSED")
