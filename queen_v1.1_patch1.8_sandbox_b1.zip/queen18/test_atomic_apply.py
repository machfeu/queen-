"""
test_atomic_apply.py — Tests for atomic apply_patch (filesystem + DB).

Scenarios:
1. patch OK + DB OK → coherent state
2. patch OK + DB KO → file rollback correct
3. patch KO before DB → nothing changes
4. rollback KO simulated → explicit critical error
5. multi-file patch → compensatory rollback correct
6. new file created by patch + rollback → new file deleted

Run: python3 test_atomic_apply.py
"""

import json
import os
import shutil
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone
from unittest.mock import patch as mock_patch, MagicMock

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Mock redis_bus before importing actions (redis not available in test env)
import types
mock_redis_bus = types.ModuleType("queen_core.redis_bus")
mock_redis_bus.publish_event = lambda *a, **kw: None
mock_redis_bus.publish_log = lambda *a, **kw: None
mock_redis_bus.REDIS_URL = ""
sys.modules.setdefault("redis", types.ModuleType("redis"))
sys.modules["queen_core.redis_bus"] = mock_redis_bus

import queen_core.patcher as patcher_mod
import queen_core.policy as policy_mod
from queen_core.models import Goal, Run, Patch, PatchStatus, RunStatus, GoalStatus, init_db
from queen_core.memory import Memory


def _setup(tmpdir, files=None):
    """Create a workspace + DB + Memory with a goal, run, and patch ready to apply."""
    ws = os.path.join(tmpdir, "workspace", "goal_test")
    os.makedirs(ws)
    db_path = os.path.join(tmpdir, "test.db")

    # Write initial files
    for rel, content in (files or {"test.py": "# original\nprint(1)\n"}).items():
        p = os.path.join(ws, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w") as f:
            f.write(content)

    # Init DB + create goal/run/patch
    mem = Memory(db_path)
    g = Goal(id="goal_test", title="test goal")
    mem.create_goal(g)
    r = Run(id="run_test", goal_id="goal_test")
    mem.create_run(r)

    # Generate a real diff
    from queen_core.patcher import generate_diff
    diff_parts = []
    for rel in (files or {"test.py": ""}).keys():
        orig_path = os.path.join(ws, rel)
        new_content = f"# PATCHED {rel}\nprint(42)\n"
        d = generate_diff(orig_path, new_content, filename=rel)
        if d:
            diff_parts.append(d)
    diff_content = "\n".join(diff_parts)

    p = Patch(id="patch_test", run_id="run_test", goal_id="goal_test",
              diff_content=diff_content, status=PatchStatus.APPROVED.value)
    mem.create_patch(p)

    return ws, mem, db_path, diff_content


def _override_workspace(ws):
    """Temporarily override WORKSPACE_BASE. ws is the goal subdir like /tmp/.../workspace/goal_test.
    WORKSPACE_BASE should be the parent /tmp/.../workspace so validate_file_path passes."""
    old_p = patcher_mod.WORKSPACE_BASE
    old_q = policy_mod.WORKSPACE_BASE
    old_b = patcher_mod.BACKUP_DIR
    parent = os.path.dirname(ws)  # /tmp/.../workspace
    patcher_mod.WORKSPACE_BASE = parent
    policy_mod.WORKSPACE_BASE = parent
    patcher_mod.BACKUP_DIR = os.path.join(parent, ".queen_backups")
    return old_p, old_q, old_b


def _restore_workspace(old_p, old_q, old_b):
    patcher_mod.WORKSPACE_BASE = old_p
    policy_mod.WORKSPACE_BASE = old_q
    patcher_mod.BACKUP_DIR = old_b


# ── Test 1: patch OK + DB OK → coherent ─────────────────────────

def test_patch_ok_db_ok():
    tmpdir = tempfile.mkdtemp()
    try:
        ws, mem, db_path, diff = _setup(tmpdir)
        old_p, old_q, old_b = _override_workspace(ws)

        try:
            import queen_core.actions as act
            act._memory = mem  # inject our test memory
            orig_get_memory = act.get_memory
            act.get_memory = lambda: mem

            result = act.apply_patch("patch_test", actor="test")
            assert result.get("status") == "applied", f"Expected applied, got: {result}"

            # DB coherent
            p = mem.get_patch("patch_test")
            assert p["status"] == PatchStatus.APPLIED.value
            r = mem.get_run("run_test")
            assert r["status"] == RunStatus.APPLIED.value
            g = mem.get_goal("goal_test")
            assert g["status"] == GoalStatus.COMPLETED.value

            # File modified
            with open(os.path.join(ws, "test.py")) as f:
                assert "PATCHED" in f.read()

            act.get_memory = orig_get_memory
            print("PASS: test_patch_ok_db_ok")
        finally:
            _restore_workspace(old_p, old_q, old_b)
    finally:
        shutil.rmtree(tmpdir)


# ── Test 2: patch OK + DB KO → file rollback ────────────────────

def test_patch_ok_db_ko_rollback():
    tmpdir = tempfile.mkdtemp()
    try:
        ws, mem, db_path, diff = _setup(tmpdir)
        old_p, old_q, old_b = _override_workspace(ws)

        try:
            import queen_core.actions as act
            act.get_memory = lambda: mem

            # Make apply_patch_atomic raise
            original_atomic = mem.apply_patch_atomic
            def fake_atomic(**kwargs):
                raise RuntimeError("Simulated DB failure")
            mem.apply_patch_atomic = fake_atomic

            result = act.apply_patch("patch_test")
            assert "error" in result
            assert result.get("rolled_back_files") is True

            # File should be restored to original
            with open(os.path.join(ws, "test.py")) as f:
                content = f.read()
            assert "original" in content, f"File should be restored, got: {content}"

            # DB should NOT have been updated
            p = mem.get_patch("patch_test")
            assert p["status"] == PatchStatus.APPROVED.value  # unchanged

            mem.apply_patch_atomic = original_atomic
            print("PASS: test_patch_ok_db_ko_rollback")
        finally:
            _restore_workspace(old_p, old_q, old_b)
    finally:
        shutil.rmtree(tmpdir)


# ── Test 3: patch KO → nothing changes ──────────────────────────

def test_patch_ko_nothing_changes():
    tmpdir = tempfile.mkdtemp()
    try:
        ws, mem, db_path, _ = _setup(tmpdir)
        old_p, old_q, old_b = _override_workspace(ws)

        try:
            import queen_core.actions as act
            act.get_memory = lambda: mem

            # Overwrite patch with invalid diff
            mem.update_patch("patch_test", status=PatchStatus.APPROVED.value)
            mem._execute(
                "UPDATE patches SET diff_content = ? WHERE id = ?",
                ("garbage not a diff", "patch_test"),
            )

            result = act.apply_patch("patch_test")
            assert "error" in result

            # File unchanged
            with open(os.path.join(ws, "test.py")) as f:
                assert "original" in f.read()

            print("PASS: test_patch_ko_nothing_changes")
        finally:
            _restore_workspace(old_p, old_q, old_b)
    finally:
        shutil.rmtree(tmpdir)


# ── Test 4: rollback KO → explicit critical error ───────────────

def test_rollback_ko_critical_error():
    tmpdir = tempfile.mkdtemp()
    try:
        ws, mem, db_path, diff = _setup(tmpdir)
        old_p, old_q, old_b = _override_workspace(ws)

        try:
            import queen_core.actions as act
            import queen_core.patcher as pmod
            act.get_memory = lambda: mem

            # Make DB fail
            original_atomic = mem.apply_patch_atomic
            def fake_atomic(**kwargs):
                raise RuntimeError("DB down")
            mem.apply_patch_atomic = fake_atomic

            # Make rollback also fail
            original_rollback = pmod.rollback
            def fake_rollback(backup_dir, ws_path=""):
                raise RuntimeError("Disk full")
            pmod.rollback = fake_rollback

            result = act.apply_patch("patch_test")
            assert result.get("critical") is True, f"Expected critical error, got: {result}"
            assert "CRITICAL" in result.get("error", "")
            assert "Manual intervention" in result.get("error", "")

            pmod.rollback = original_rollback
            mem.apply_patch_atomic = original_atomic
            print("PASS: test_rollback_ko_critical_error")
        finally:
            _restore_workspace(old_p, old_q, old_b)
    finally:
        shutil.rmtree(tmpdir)


# ── Test 5: multi-file patch → compensatory rollback ────────────

def test_multi_file_rollback():
    tmpdir = tempfile.mkdtemp()
    try:
        files = {
            "module_a.py": "# original A\n",
            "module_b.py": "# original B\n",
            "sub/module_c.py": "# original C\n",
        }
        ws, mem, db_path, diff = _setup(tmpdir, files)
        old_p, old_q, old_b = _override_workspace(ws)

        try:
            import queen_core.actions as act
            act.get_memory = lambda: mem

            # Make DB fail to trigger rollback
            original_atomic = mem.apply_patch_atomic
            mem.apply_patch_atomic = lambda **kw: (_ for _ in ()).throw(RuntimeError("DB fail"))

            result = act.apply_patch("patch_test")
            assert result.get("rolled_back_files") is True

            # ALL files should be restored
            for rel, orig_content in files.items():
                with open(os.path.join(ws, rel)) as f:
                    content = f.read()
                assert "original" in content, f"{rel} not restored: {content}"

            mem.apply_patch_atomic = original_atomic
            print("PASS: test_multi_file_rollback")
        finally:
            _restore_workspace(old_p, old_q, old_b)
    finally:
        shutil.rmtree(tmpdir)


# ── Test 6: new file created + rollback → file deleted ──────────

def test_new_file_cleanup_on_rollback():
    tmpdir = tempfile.mkdtemp()
    try:
        ws = os.path.join(tmpdir, "workspace", "goal_test")
        os.makedirs(ws)
        db_path = os.path.join(tmpdir, "test.db")
        mem = Memory(db_path)

        g = Goal(id="goal_test", title="test")
        mem.create_goal(g)
        r = Run(id="run_test", goal_id="goal_test")
        mem.create_run(r)

        # Diff that creates a NEW file (no original exists)
        from queen_core.patcher import generate_diff
        diff = generate_diff("/nonexistent", "# brand new file\nprint('hello')\n", filename="new_module.py")

        p = Patch(id="patch_test", run_id="run_test", goal_id="goal_test",
                  diff_content=diff, status=PatchStatus.APPROVED.value)
        mem.create_patch(p)

        old_p, old_q, old_b = _override_workspace(ws)

        try:
            import queen_core.actions as act
            act.get_memory = lambda: mem

            # Make DB fail
            original_atomic = mem.apply_patch_atomic
            mem.apply_patch_atomic = lambda **kw: (_ for _ in ()).throw(RuntimeError("DB fail"))

            # The new file should NOT exist before
            assert not os.path.exists(os.path.join(ws, "new_module.py"))

            result = act.apply_patch("patch_test")
            assert result.get("rolled_back_files") is True

            # The new file should be DELETED by cleanup
            assert not os.path.exists(os.path.join(ws, "new_module.py")), \
                "New file should have been cleaned up on rollback"

            mem.apply_patch_atomic = original_atomic
            print("PASS: test_new_file_cleanup_on_rollback")
        finally:
            _restore_workspace(old_p, old_q, old_b)
    finally:
        shutil.rmtree(tmpdir)


# ── Runner ───────────────────────────────────────────────────────

if __name__ == "__main__":
    tests = [
        test_patch_ok_db_ok,
        test_patch_ok_db_ko_rollback,
        test_patch_ko_nothing_changes,
        test_rollback_ko_critical_error,
        test_multi_file_rollback,
        test_new_file_cleanup_on_rollback,
    ]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"FAIL: {t.__name__} — {e}")
            import traceback; traceback.print_exc()
            failed += 1
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    if failed:
        sys.exit(1)
    print("ALL TESTS PASSED")
