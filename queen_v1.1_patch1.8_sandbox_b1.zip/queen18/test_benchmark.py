"""
test_benchmark.py — Tests for benchmark v2 (static + functional).

Run: python3 test_benchmark.py
"""

import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from queen_core.evolution.static_benchmarks import (
    bench_no_dangerous_patterns,
    bench_docstrings_present,
    bench_no_syntax_errors,
)
from queen_core.evolution.bench_runner import run_benchmarks
from queen_core.evolution.fitness import compute_fitness


def _make_candidate(tmpdir, files):
    src = os.path.join(tmpdir, "candidate")
    for rel, content in files.items():
        p = os.path.join(src, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w") as f:
            f.write(content)
    return src


# ── Static benchmark tests ──────────────────────────────────────

def test_clean_code_scores_high():
    tmpdir = tempfile.mkdtemp()
    try:
        src = _make_candidate(tmpdir, {
            "queen_core/good.py": '"""Good."""\ndef greet():\n    """Say hi."""\n    try:\n        with open("x") as f: return f.read()\n    except Exception: return ""\n',
        })
        assert bench_no_dangerous_patterns(src) == 1.0
        assert bench_docstrings_present(src) >= 0.8
        assert bench_no_syntax_errors(src) == 1.0
        print("PASS: test_clean_code_scores_high")
    finally:
        shutil.rmtree(tmpdir)


def test_dangerous_code_penalized():
    tmpdir = tempfile.mkdtemp()
    try:
        src = _make_candidate(tmpdir, {
            "queen_core/bad.py": 'import os\ndef x():\n    os.system("rm -rf /")\n    eval("x")\n',
        })
        score = bench_no_dangerous_patterns(src)
        assert score < 0.7, f"Expected < 0.7, got {score}"
        print("PASS: test_dangerous_code_penalized")
    finally:
        shutil.rmtree(tmpdir)


def test_syntax_error_detected():
    tmpdir = tempfile.mkdtemp()
    try:
        src = _make_candidate(tmpdir, {
            "queen_core/ok.py": "x = 1\n",
            "queen_core/broken.py": "def f(\n",
        })
        score = bench_no_syntax_errors(src)
        assert score == 0.5, f"Expected 0.5, got {score}"
        print("PASS: test_syntax_error_detected")
    finally:
        shutil.rmtree(tmpdir)


# ── Functional benchmark tests ───────────────────────────────────

def test_functional_benchmarks_on_queen():
    """Run functional benchmarks against Queen's own code."""
    queen_root = os.path.dirname(os.path.abspath(__file__))
    result = run_benchmarks(queen_root)
    func_score = result["functional_score"]
    assert func_score >= 0.8, f"Functional score should be >= 0.8 on Queen itself, got {func_score}"
    assert result["functional_count"] == 5, f"Expected 5 functional benchmarks, got {result['functional_count']}"
    # Check each functional benchmark passed
    for name, r in result["benchmark_results"].items():
        if name.startswith("functional:"):
            assert r["score"] >= 0.5, f"{name} scored {r['score']}"
            assert r["time_s"] < 20, f"{name} took {r['time_s']}s (too slow)"
    print(f"PASS: test_functional_benchmarks_on_queen (score={func_score:.3f})")


def test_memory_crud_scenario():
    """The memory_crud benchmark specifically must pass on Queen."""
    queen_root = os.path.dirname(os.path.abspath(__file__))
    result = run_benchmarks(queen_root)
    crud = result["benchmark_results"].get("functional:memory_crud", {})
    assert crud.get("score", 0) >= 0.8, f"memory_crud scored {crud.get('score')}"
    print(f"PASS: test_memory_crud_scenario (score={crud['score']:.3f})")


def test_migration_scenario():
    """The migration_idempotence benchmark specifically must pass."""
    queen_root = os.path.dirname(os.path.abspath(__file__))
    result = run_benchmarks(queen_root)
    mig = result["benchmark_results"].get("functional:migration_idempotence", {})
    assert mig.get("score", 0) >= 0.8, f"migration scored {mig.get('score')}"
    print(f"PASS: test_migration_scenario (score={mig['score']:.3f})")


def test_run_benchmarks_structure():
    """run_benchmarks returns all required keys with correct types."""
    queen_root = os.path.dirname(os.path.abspath(__file__))
    result = run_benchmarks(queen_root)
    required_keys = ["benchmark_score", "static_score", "functional_score",
                     "benchmark_count", "static_count", "functional_count", "benchmark_results"]
    for k in required_keys:
        assert k in result, f"Missing key: {k}"
    assert 0.0 <= result["benchmark_score"] <= 1.0
    assert 0.0 <= result["static_score"] <= 1.0
    assert 0.0 <= result["functional_score"] <= 1.0
    assert result["functional_count"] >= 5
    assert result["static_count"] >= 5
    print(f"PASS: test_run_benchmarks_structure (total={result['benchmark_count']})")


def test_benchmark_weights():
    """Functional benchmarks should weigh more than static."""
    queen_root = os.path.dirname(os.path.abspath(__file__))
    result = run_benchmarks(queen_root)
    # With functional=1.0 and static~0.7, score should be pulled up by functional
    assert result["benchmark_score"] > result["static_score"], \
        f"Weighted score ({result['benchmark_score']}) should be > static alone ({result['static_score']})"
    print(f"PASS: test_benchmark_weights (weighted={result['benchmark_score']:.3f} static={result['static_score']:.3f})")


# ── Fitness integration ──────────────────────────────────────────

def test_fitness_differentiates():
    """Two variants with different functional scores must get different fitness."""
    metrics_a = {
        "smoke_ok": True, "compile_ok": True, "import_ok": True,
        "runtime_seconds": 5, "applied": [{"path": "x.py"}], "failed": [],
        "artifact_count": 1, "patch_non_empty": True,
        "static_score": 0.7, "functional_score": 1.0,
        "benchmark_score": 0.9,
    }
    metrics_b = {
        "smoke_ok": True, "compile_ok": True, "import_ok": True,
        "runtime_seconds": 5, "applied": [{"path": "x.py"}], "failed": [],
        "artifact_count": 1, "patch_non_empty": True,
        "static_score": 0.7, "functional_score": 0.3,
        "benchmark_score": 0.4,
    }
    sa = compute_fitness(metrics_a)
    sb = compute_fitness(metrics_b)
    diff = sa - sb
    assert diff > 0.15, f"A={sa:.3f} B={sb:.3f} diff={diff:.3f}"
    print(f"PASS: test_fitness_differentiates (A={sa:.3f} B={sb:.3f} diff={diff:.3f})")


def test_fitness_smoke_kills():
    metrics = {
        "smoke_ok": False, "compile_ok": False, "import_ok": False,
        "static_score": 1.0, "functional_score": 1.0,
        "benchmark_score": 1.0,
        "applied": [{"path": "x.py"}], "failed": [],
        "artifact_count": 1, "patch_non_empty": True,
    }
    score = compute_fitness(metrics)
    assert score <= 0.15, f"Expected <= 0.15, got {score}"
    print(f"PASS: test_fitness_smoke_kills (score={score:.3f})")


def test_fitness_functional_veto():
    """Code that compiles but fails functional benchmarks should be capped."""
    metrics = {
        "smoke_ok": True, "compile_ok": True, "import_ok": True,
        "runtime_seconds": 5, "applied": [{"path": "x.py"}], "failed": [],
        "artifact_count": 1, "patch_non_empty": True,
        "static_score": 0.9, "functional_score": 0.2,
        "benchmark_score": 0.5,
    }
    score = compute_fitness(metrics)
    assert score <= 0.50, f"Expected <= 0.50 (functional veto), got {score}"
    print(f"PASS: test_fitness_functional_veto (score={score:.3f})")


# ── Runner ───────────────────────────────────────────────────────

if __name__ == "__main__":
    tests = [
        test_clean_code_scores_high,
        test_dangerous_code_penalized,
        test_syntax_error_detected,
        test_functional_benchmarks_on_queen,
        test_memory_crud_scenario,
        test_migration_scenario,
        test_run_benchmarks_structure,
        test_benchmark_weights,
        test_fitness_differentiates,
        test_fitness_smoke_kills,
        test_fitness_functional_veto,
    ]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"FAIL: {t.__name__} — {e}")
            import traceback; traceback.print_exc()
            failed += 1
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    if failed:
        sys.exit(1)
    print("ALL TESTS PASSED")
