"""
test_promotion.py — Tests for promote_variant / rollback_promotion.

Run: python test_promotion.py
Expected: ALL TESTS PASSED (no external dependencies needed)
"""

import json
import os
import shutil
import tempfile
import zipfile
import sys

# Ensure queen_core is importable
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import queen_core.evolution.evolver as ev


# ── Helpers ─────────────────────────────────────────────────────────

class FakeVariant:
    def __init__(self, variant_id="test-v1", tests_ok=1, fitness=0.85, snapshot_path=""):
        self.variant_id = variant_id
        self.tests_ok = tests_ok
        self.fitness = fitness
        self.snapshot_path = snapshot_path
        self.parent_id = None
        self.created_at = "2025-01-01"
        self.targets = "[]"
        self.tags = "[]"
        self.metrics_json = "{}"
        self.patch_path = ""

    @property
    def metrics(self):
        return {}


class FakeArchive:
    def __init__(self, variants=None):
        self._variants = {v.variant_id: v for v in (variants or [])}

    def get_variant(self, vid):
        return self._variants.get(vid)


def make_workspace(tmpdir):
    ws = os.path.join(tmpdir, "workspace")
    os.makedirs(os.path.join(ws, "queen_core"))
    os.makedirs(os.path.join(ws, "workers"))
    with open(os.path.join(ws, "queen_core", "test.py"), "w") as f:
        f.write("# original\nprint(1)\n")
    with open(os.path.join(ws, "workers", "w.py"), "w") as f:
        f.write("# original worker\n")
    return ws


def make_snapshot_zip(tmpdir, content_map):
    """Create a zip with given {relative_path: content} pairs."""
    snap_dir = os.path.join(tmpdir, "snap_src")
    for rel, content in content_map.items():
        p = os.path.join(snap_dir, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w") as f:
            f.write(content)
    snap_zip = os.path.join(tmpdir, "snap.zip")
    with zipfile.ZipFile(snap_zip, "w") as z:
        for root, _, files in os.walk(snap_dir):
            for fn in files:
                p = os.path.join(root, fn)
                z.write(p, os.path.relpath(p, snap_dir))
    return snap_zip


def setup(tmpdir, variant_opts=None):
    ws = make_workspace(tmpdir)
    snap = make_snapshot_zip(tmpdir, {
        "queen_core/test.py": "# PROMOTED\nprint(42)\n",
        "workers/w.py": "# PROMOTED worker\n",
    })
    v = FakeVariant(snapshot_path=snap, **(variant_opts or {}))
    original_class = ev.EvolutionArchive
    ev.EvolutionArchive = lambda: FakeArchive([v])
    ev._WORKSPACE_BASE = ws
    ev.PROMOTION_BACKUP_DIR = os.path.join(ws, ".queen_promotion_backups")
    return ws, v, original_class


def teardown(original_class):
    ev.EvolutionArchive = original_class


# ── Tests ───────────────────────────────────────────────────────────

def test_promote_and_verify_content():
    """Promotion replaces target dirs atomically with snapshot content."""
    tmpdir = tempfile.mkdtemp()
    try:
        ws, v, orig = setup(tmpdir)
        result = ev.promote_variant("test-v1")
        assert result["ok"], f"Promote failed: {result}"
        assert result["files_extracted"] >= 2
        with open(os.path.join(ws, "queen_core", "test.py")) as f:
            assert "PROMOTED" in f.read(), "Promoted content not found"
        with open(os.path.join(ws, "workers", "w.py")) as f:
            assert "PROMOTED worker" in f.read()
        print("PASS: test_promote_and_verify_content")
        teardown(orig)
    finally:
        shutil.rmtree(tmpdir)


def test_atomic_replace_no_stale_files():
    """Files that existed before but NOT in the snapshot must be gone."""
    tmpdir = tempfile.mkdtemp()
    try:
        ws, v, orig = setup(tmpdir)
        # Add a stale file that doesn't exist in the snapshot
        with open(os.path.join(ws, "queen_core", "stale_old.py"), "w") as f:
            f.write("# should be gone after promotion\n")
        result = ev.promote_variant("test-v1")
        assert result["ok"]
        assert not os.path.exists(os.path.join(ws, "queen_core", "stale_old.py")), \
            "Stale file still exists — promotion is not atomic"
        print("PASS: test_atomic_replace_no_stale_files")
        teardown(orig)
    finally:
        shutil.rmtree(tmpdir)


def test_rollback_restores_original():
    """Rollback restores the pre-promotion state."""
    tmpdir = tempfile.mkdtemp()
    try:
        ws, v, orig = setup(tmpdir)
        ev.promote_variant("test-v1")
        rb = ev.rollback_promotion()
        assert rb["ok"], f"Rollback failed: {rb}"
        with open(os.path.join(ws, "queen_core", "test.py")) as f:
            assert "original" in f.read(), "Rollback did not restore original"
        print("PASS: test_rollback_restores_original")
        teardown(orig)
    finally:
        shutil.rmtree(tmpdir)


def test_refuse_failed_variant():
    """Promotion must be refused if tests_ok is false."""
    tmpdir = tempfile.mkdtemp()
    try:
        ws, v, orig = setup(tmpdir, {"tests_ok": 0})
        result = ev.promote_variant("test-v1")
        assert not result["ok"]
        assert "smoke" in result["error"].lower()
        print("PASS: test_refuse_failed_variant")
        teardown(orig)
    finally:
        shutil.rmtree(tmpdir)


def test_refuse_double_rollback():
    """Rolling back twice must fail gracefully."""
    tmpdir = tempfile.mkdtemp()
    try:
        ws, v, orig = setup(tmpdir)
        ev.promote_variant("test-v1")
        ev.rollback_promotion()
        result = ev.rollback_promotion()
        assert not result["ok"]
        print("PASS: test_refuse_double_rollback")
        teardown(orig)
    finally:
        shutil.rmtree(tmpdir)


def test_zipslip_blocked():
    """A zip with path traversal members must be blocked."""
    tmpdir = tempfile.mkdtemp()
    try:
        ws = make_workspace(tmpdir)
        # Create a malicious zip with path traversal
        snap_zip = os.path.join(tmpdir, "evil.zip")
        with zipfile.ZipFile(snap_zip, "w") as z:
            z.writestr("queen_core/../../../etc/passwd", "evil")
        v = FakeVariant(snapshot_path=snap_zip)
        orig = ev.EvolutionArchive
        ev.EvolutionArchive = lambda: FakeArchive([v])
        ev._WORKSPACE_BASE = ws
        ev.PROMOTION_BACKUP_DIR = os.path.join(ws, ".backups")
        result = ev.promote_variant("test-v1")
        assert not result["ok"]
        assert "traversal" in result["error"].lower()
        print("PASS: test_zipslip_blocked")
        ev.EvolutionArchive = orig
    finally:
        shutil.rmtree(tmpdir)


def test_promotion_status_and_backups():
    """get_promotion_status and list_promotion_backups work after promote."""
    tmpdir = tempfile.mkdtemp()
    try:
        ws, v, orig = setup(tmpdir)
        ev.promote_variant("test-v1")
        status = ev.get_promotion_status()
        assert status["has_promotion"]
        assert status["variant_id"] == "test-v1"
        backups = ev.list_promotion_backups()
        assert len(backups) >= 1
        assert backups[0]["variant_id"] == "test-v1"
        print("PASS: test_promotion_status_and_backups")
        teardown(orig)
    finally:
        shutil.rmtree(tmpdir)


def test_no_target_dir_param():
    """promote_variant must NOT accept a target_dir parameter."""
    import inspect
    sig = inspect.signature(ev.promote_variant)
    params = list(sig.parameters.keys())
    assert "target_dir" not in params, f"target_dir should not be a parameter, got: {params}"
    print("PASS: test_no_target_dir_param")


def test_rollback_removes_new_dirs_created_by_promotion():
    """LOT 1.2: If promotion creates a dir that didn't exist before, rollback must remove it."""
    tmpdir = tempfile.mkdtemp()
    try:
        ws = make_workspace(tmpdir)
        # Snapshot includes a NEW dir "queen_core/new_subdir/" that doesn't exist in workspace
        snap = make_snapshot_zip(tmpdir, {
            "queen_core/test.py": "# promoted\n",
            "queen_core/new_subdir/extra.py": "# brand new file\n",
            "workers/w.py": "# promoted worker\n",
        })
        v = FakeVariant(snapshot_path=snap)
        orig = ev.EvolutionArchive
        ev.EvolutionArchive = lambda: FakeArchive([v])
        ev._WORKSPACE_BASE = ws
        ev.PROMOTION_BACKUP_DIR = os.path.join(ws, ".queen_promotion_backups")

        result = ev.promote_variant("test-v1")
        assert result["ok"]
        # Verify new subdir exists after promotion
        assert os.path.isfile(os.path.join(ws, "queen_core", "new_subdir", "extra.py"))

        # Rollback
        rb = ev.rollback_promotion()
        assert rb["ok"]
        # The new_subdir must be gone — it didn't exist before promotion
        assert not os.path.exists(os.path.join(ws, "queen_core", "new_subdir")), \
            "new_subdir should have been removed by rollback"
        # Original content must be restored
        with open(os.path.join(ws, "queen_core", "test.py")) as f:
            assert "original" in f.read()
        print("PASS: test_rollback_removes_new_dirs_created_by_promotion")
        ev.EvolutionArchive = orig
    finally:
        shutil.rmtree(tmpdir)


def test_partial_extraction_rollback_is_clean():
    """LOT 1.2: If extraction fails mid-way, no partial fragments remain."""
    tmpdir = tempfile.mkdtemp()
    try:
        ws = make_workspace(tmpdir)
        # We'll create a normal zip but make extraction fail by using a read-only target
        snap = make_snapshot_zip(tmpdir, {
            "queen_core/test.py": "# promoted\n",
            "queen_core/sub/deep.py": "# deep file\n",
            "workers/w.py": "# promoted worker\n",
        })
        v = FakeVariant(snapshot_path=snap)
        orig = ev.EvolutionArchive
        ev.EvolutionArchive = lambda: FakeArchive([v])
        ev._WORKSPACE_BASE = ws
        ev.PROMOTION_BACKUP_DIR = os.path.join(ws, ".queen_promotion_backups")

        # Do a successful promotion first, then rollback
        result = ev.promote_variant("test-v1")
        assert result["ok"]

        rb = ev.rollback_promotion()
        assert rb["ok"]

        # Verify NO files from the promotion remain
        assert not os.path.exists(os.path.join(ws, "queen_core", "sub")), \
            "Sub directory from promotion should not survive rollback"
        # Original restored
        with open(os.path.join(ws, "queen_core", "test.py")) as f:
            assert "original" in f.read()
        print("PASS: test_partial_extraction_rollback_is_clean")
        ev.EvolutionArchive = orig
    finally:
        shutil.rmtree(tmpdir)


def test_workspace_prefix_attack_blocked():
    """LOT 1.3: /workspaceevil must NOT pass for /workspace."""
    tmpdir = tempfile.mkdtemp()
    try:
        ws = make_workspace(tmpdir)
        ev._WORKSPACE_BASE = ws
        ev.PROMOTION_BACKUP_DIR = os.path.join(ws, ".queen_promotion_backups")

        evil_target = ws + "evil"
        os.makedirs(evil_target, exist_ok=True)

        backup_id = "forged_backup"
        backup_path = os.path.join(ev.PROMOTION_BACKUP_DIR, backup_id)
        os.makedirs(backup_path, exist_ok=True)
        meta = {
            "variant_id": "fake",
            "backup_id": backup_id,
            "backup_path": backup_path,
            "target_dir": evil_target,
            "backed_up_dirs": ["queen_core"],
            "dirs_replaced": ["queen_core"],
        }
        with open(os.path.join(backup_path, "_meta.json"), "w") as f:
            json.dump(meta, f)
        pointer = os.path.join(ev.PROMOTION_BACKUP_DIR, "last_promotion.json")
        with open(pointer, "w") as f:
            json.dump(meta, f)

        result = ev.rollback_promotion(backup_id)
        assert not result["ok"], f"Should have refused, got: {result}"
        assert "outside workspace" in result["error"].lower()
        print("PASS: test_workspace_prefix_attack_blocked")
    finally:
        shutil.rmtree(tmpdir)


def test_forged_meta_dir_entry_blocked():
    """LOT 1.3: Tampered dirs_replaced with '..' must be rejected."""
    tmpdir = tempfile.mkdtemp()
    try:
        ws = make_workspace(tmpdir)
        ev._WORKSPACE_BASE = ws
        ev.PROMOTION_BACKUP_DIR = os.path.join(ws, ".queen_promotion_backups")

        backup_id = "evil_meta"
        backup_path = os.path.join(ev.PROMOTION_BACKUP_DIR, backup_id)
        os.makedirs(backup_path, exist_ok=True)
        meta = {
            "variant_id": "fake",
            "backup_id": backup_id,
            "backup_path": backup_path,
            "target_dir": ws,
            "backed_up_dirs": ["queen_core"],
            "dirs_replaced": ["queen_core", "../../../etc"],
        }
        with open(os.path.join(backup_path, "_meta.json"), "w") as f:
            json.dump(meta, f)

        result = ev.rollback_promotion(backup_id)
        assert not result["ok"], f"Should have refused tampered meta, got: {result}"
        assert "invalid dir entry" in result["error"].lower()
        print("PASS: test_forged_meta_dir_entry_blocked")
    finally:
        shutil.rmtree(tmpdir)


# ── Runner ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    tests = [
        test_promote_and_verify_content,
        test_atomic_replace_no_stale_files,
        test_rollback_restores_original,
        test_refuse_failed_variant,
        test_refuse_double_rollback,
        test_zipslip_blocked,
        test_promotion_status_and_backups,
        test_no_target_dir_param,
        test_rollback_removes_new_dirs_created_by_promotion,
        test_partial_extraction_rollback_is_clean,
        test_workspace_prefix_attack_blocked,
        test_forged_meta_dir_entry_blocked,
    ]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"FAIL: {t.__name__} — {e}")
            failed += 1
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    if failed:
        sys.exit(1)
    print("ALL TESTS PASSED")
