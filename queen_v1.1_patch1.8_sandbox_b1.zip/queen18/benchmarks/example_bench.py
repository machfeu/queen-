"""
Example user benchmark — place .py files in this directory.
Any function named bench_* will be auto-discovered and run.

Each function receives candidate_src (str) and must return a float 0.0-1.0.
"""
import os


def bench_has_readme(candidate_src: str) -> float:
    """Check if there's a README at the project root. Simple quality signal."""
    for name in ("README.md", "README.txt", "README.rst", "README"):
        if os.path.isfile(os.path.join(candidate_src, name)):
            return 1.0
    # Check parent (candidate_src is usually inside the project)
    parent = os.path.dirname(candidate_src)
    for name in ("README.md", "README.txt", "README.rst", "README"):
        if os.path.isfile(os.path.join(parent, name)):
            return 0.8
    return 0.0
