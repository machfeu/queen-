@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  py -3 queen_launcher.py
  goto :eof
)
where python >nul 2>&1
if %errorlevel%==0 (
  python queen_launcher.py
  goto :eof
)
echo Python est introuvable. Installe Python 3 puis relance ce fichier.
pause
