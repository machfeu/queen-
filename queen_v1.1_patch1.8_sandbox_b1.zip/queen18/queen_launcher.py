"""Queen Launcher — desktop control panel for the local source checkout.

Goals:
- no command line required for normal usage
- edit .env from a small GUI
- start/stop/restart docker compose with optional overlays/profiles
- open the dashboard in a browser

Windows-friendly, but also works on Linux/macOS with Python + Tkinter.
"""

from __future__ import annotations

import os
import queue
import shutil
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path
from typing import Dict, List

import tkinter as tk
from tkinter import messagebox, ttk

PROJECT_ROOT = Path(__file__).resolve().parent
ENV_PATH = PROJECT_ROOT / ".env"
ENV_EXAMPLE_PATH = PROJECT_ROOT / ".env.example"
COMPOSE_FILE = PROJECT_ROOT / "docker-compose.yml"
REDIS_OVERLAY = PROJECT_ROOT / "docker-compose.redis-auth.yml"
DASHBOARD_URL = "http://127.0.0.1:8080"

ENV_ORDER = [
    "QUEEN_API_KEY",
    "REDIS_PASSWORD",
    "LLM_PROVIDER",
    "OLLAMA_BASE_URL",
    "OLLAMA_MODEL",
    "OPENAI_BASE_URL",
    "OPENAI_MODEL",
    "OPENAI_API_KEY",
    "POLICY_JOB_TIMEOUT",
    "POLICY_MAX_JOB_TIMEOUT",
    "POLICY_MAX_OUTPUT_BYTES",
    "POLICY_MAX_JOBS_PER_RUN",
    "POLICY_MAX_CONCURRENT_JOBS",
    "EVOLUTION_ITERS",
    "EVOLUTION_MAX_FILES",
    "EVOLUTION_EXPLORATION",
    "EVOLUTION_INSTRUCTION",
    "EVOLUTION_ALLOWLIST",
    "EVOLUTION_TARGETS",
]

DEFAULTS = {
    "QUEEN_API_KEY": "",
    "REDIS_PASSWORD": "",
    "LLM_PROVIDER": "ollama",
    "OLLAMA_BASE_URL": "http://ollama:11434",
    "OLLAMA_MODEL": "llama3.1:8b",
    "OPENAI_BASE_URL": "https://api.openai.com/v1",
    "OPENAI_MODEL": "gpt-4o-mini",
    "OPENAI_API_KEY": "",
    "POLICY_JOB_TIMEOUT": "300",
    "POLICY_MAX_JOB_TIMEOUT": "1800",
    "POLICY_MAX_OUTPUT_BYTES": "10000000",
    "POLICY_MAX_JOBS_PER_RUN": "20",
    "POLICY_MAX_CONCURRENT_JOBS": "5",
    "EVOLUTION_ITERS": "5",
    "EVOLUTION_MAX_FILES": "2",
    "EVOLUTION_EXPLORATION": "0.15",
    "EVOLUTION_INSTRUCTION": "Improve reliability and bug-resilience without changing external behavior.",
    "EVOLUTION_ALLOWLIST": "queen_core/redis_bus.py,queen_core/orchestrator.py,workers/worker_unified.py",
    "EVOLUTION_TARGETS": "queen_core/redis_bus.py,queen_core/orchestrator.py",
}


class LauncherApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Queen Launcher")
        self.root.geometry("980x760")
        self.root.minsize(900, 700)
        self.log_queue: "queue.Queue[str]" = queue.Queue()
        self.current_process: subprocess.Popen[str] | None = None

        self.env_values = self.load_env()
        self.build_ui()
        self.poll_log_queue()
        self.log("Launcher prêt.")

    def load_env(self) -> Dict[str, str]:
        data = dict(DEFAULTS)
        source = ENV_PATH if ENV_PATH.exists() else ENV_EXAMPLE_PATH
        if source.exists():
            for line in source.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                data[k.strip()] = v.strip()
        return data

    def save_env(self) -> None:
        data = {k: self.vars[k].get().strip() for k in ENV_ORDER}
        content = [
            "# Queen launcher generated .env",
            "# Tu peux encore l'éditer à la main si besoin.",
            "",
        ]
        for key in ENV_ORDER:
            value = data.get(key, "")
            content.append(f"{key}={value}")
        ENV_PATH.write_text("\n".join(content) + "\n", encoding="utf-8")
        self.log(f"Configuration enregistrée dans {ENV_PATH.name}")
        messagebox.showinfo("Queen Launcher", ".env mis à jour.")

    def compose_cmd(self, action: str) -> List[str]:
        cmd = ["docker", "compose", "-f", str(COMPOSE_FILE)]
        if self.vars["REDIS_PASSWORD"].get().strip() and REDIS_OVERLAY.exists():
            cmd += ["-f", str(REDIS_OVERLAY)]
        profiles = []
        if self.profile_ollama.get():
            profiles += ["--profile", "ollama"]
        if self.profile_scale.get():
            profiles += ["--profile", "scale"]
        cmd += profiles
        if action == "up":
            cmd += ["up", "-d", "--build"]
        elif action == "down":
            cmd += ["down"]
        elif action == "restart":
            cmd += ["up", "-d", "--build", "--force-recreate"]
        else:
            raise ValueError(action)
        return cmd

    def run_compose(self, action: str) -> None:
        self.save_env_silent()
        cmd = self.compose_cmd(action)
        self.log("$ " + " ".join(cmd))

        def worker() -> None:
            try:
                proc = subprocess.Popen(
                    cmd,
                    cwd=str(PROJECT_ROOT),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                )
                self.current_process = proc
                assert proc.stdout is not None
                for line in proc.stdout:
                    self.log(line.rstrip())
                code = proc.wait()
                self.log(f"Commande terminée avec code {code}")
            except FileNotFoundError:
                self.log("Docker ou docker compose introuvable. Vérifie Docker Desktop.")
                messagebox.showerror("Queen Launcher", "Docker ou docker compose introuvable.")
            except Exception as e:
                self.log(f"Erreur: {e}")
                messagebox.showerror("Queen Launcher", str(e))
            finally:
                self.current_process = None

        threading.Thread(target=worker, daemon=True).start()

    def save_env_silent(self) -> None:
        data = {k: self.vars[k].get().strip() for k in ENV_ORDER}
        content = ["# Queen launcher generated .env", ""]
        for key in ENV_ORDER:
            content.append(f"{key}={data.get(key, '')}")
        ENV_PATH.write_text("\n".join(content) + "\n", encoding="utf-8")

    def open_dashboard(self) -> None:
        webbrowser.open(DASHBOARD_URL)
        self.log(f"Ouverture du dashboard: {DASHBOARD_URL}")

    def open_project_folder(self) -> None:
        path = str(PROJECT_ROOT)
        if sys.platform.startswith("win"):
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])

    def detect_tools(self) -> None:
        docker = shutil.which("docker")
        python_bin = sys.executable
        lines = [f"Python: {python_bin}", f"Docker: {docker or 'non trouvé'}"]
        if docker:
            try:
                result = subprocess.run(["docker", "--version"], capture_output=True, text=True, timeout=5)
                lines.append(result.stdout.strip() or result.stderr.strip())
            except Exception as e:
                lines.append(f"docker --version a échoué: {e}")
        messagebox.showinfo("Outils détectés", "\n".join(lines))

    def log(self, msg: str) -> None:
        self.log_queue.put(f"[{time.strftime('%H:%M:%S')}] {msg}")

    def poll_log_queue(self) -> None:
        try:
            while True:
                line = self.log_queue.get_nowait()
                self.log_text.configure(state="normal")
                self.log_text.insert("end", line + "\n")
                self.log_text.see("end")
                self.log_text.configure(state="disabled")
        except queue.Empty:
            pass
        self.root.after(250, self.poll_log_queue)

    def build_ui(self) -> None:
        self.vars: Dict[str, tk.StringVar] = {k: tk.StringVar(value=self.env_values.get(k, DEFAULTS.get(k, ""))) for k in ENV_ORDER}
        self.profile_ollama = tk.BooleanVar(value=self.vars["LLM_PROVIDER"].get().strip().lower() == "ollama")
        self.profile_scale = tk.BooleanVar(value=False)

        notebook = ttk.Notebook(self.root)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)

        tab_launch = ttk.Frame(notebook)
        tab_llm = ttk.Frame(notebook)
        tab_security = ttk.Frame(notebook)
        tab_evo = ttk.Frame(notebook)
        tab_logs = ttk.Frame(notebook)
        notebook.add(tab_launch, text="Lancement")
        notebook.add(tab_llm, text="LLM")
        notebook.add(tab_security, text="Sécurité")
        notebook.add(tab_evo, text="Évolution")
        notebook.add(tab_logs, text="Logs")

        self.build_launch_tab(tab_launch)
        self.build_llm_tab(tab_llm)
        self.build_security_tab(tab_security)
        self.build_evolution_tab(tab_evo)
        self.build_logs_tab(tab_logs)

    def build_launch_tab(self, parent: ttk.Frame) -> None:
        frame = ttk.Frame(parent, padding=16)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="Lancer Queen sans ligne de commande", font=("Segoe UI", 16, "bold")).pack(anchor="w", pady=(0, 12))
        ttk.Label(frame, text="1) Enregistre la configuration. 2) Lance Docker. 3) Ouvre le dashboard.").pack(anchor="w", pady=(0, 12))

        box = ttk.LabelFrame(frame, text="Profils et actions", padding=12)
        box.pack(fill="x", pady=(0, 12))
        ttk.Checkbutton(box, text="Activer le profil Ollama", variable=self.profile_ollama).grid(row=0, column=0, sticky="w", padx=4, pady=4)
        ttk.Checkbutton(box, text="Activer un second worker (profil scale)", variable=self.profile_scale).grid(row=0, column=1, sticky="w", padx=4, pady=4)

        btns = ttk.Frame(box)
        btns.grid(row=1, column=0, columnspan=2, sticky="w", pady=(12, 4))
        ttk.Button(btns, text="Enregistrer .env", command=self.save_env).pack(side="left", padx=4)
        ttk.Button(btns, text="Démarrer / mettre à jour", command=lambda: self.run_compose("up")).pack(side="left", padx=4)
        ttk.Button(btns, text="Redémarrer", command=lambda: self.run_compose("restart")).pack(side="left", padx=4)
        ttk.Button(btns, text="Arrêter", command=lambda: self.run_compose("down")).pack(side="left", padx=4)
        ttk.Button(btns, text="Ouvrir dashboard", command=self.open_dashboard).pack(side="left", padx=4)
        ttk.Button(btns, text="Ouvrir dossier source", command=self.open_project_folder).pack(side="left", padx=4)
        ttk.Button(btns, text="Vérifier Docker", command=self.detect_tools).pack(side="left", padx=4)

        help_box = ttk.LabelFrame(frame, text="Conseils", padding=12)
        help_box.pack(fill="x", pady=(0, 12))
        ttk.Label(help_box, text="• Si tu utilises OpenAI, remplis OPENAI_API_KEY puis mets LLM_PROVIDER=openai.").pack(anchor="w")
        ttk.Label(help_box, text="• Si REDIS_PASSWORD est renseigné, le lanceur active automatiquement l’overlay Redis AUTH.").pack(anchor="w")
        ttk.Label(help_box, text="• Le dashboard s’ouvre sur http://127.0.0.1:8080 .").pack(anchor="w")

    def build_llm_tab(self, parent: ttk.Frame) -> None:
        frame = ttk.Frame(parent, padding=16)
        frame.pack(fill="both", expand=True)
        self.add_entry(frame, 0, "Provider", "LLM_PROVIDER")
        self.add_entry(frame, 1, "Ollama URL", "OLLAMA_BASE_URL")
        self.add_entry(frame, 2, "Ollama Model", "OLLAMA_MODEL")
        self.add_entry(frame, 3, "OpenAI URL", "OPENAI_BASE_URL")
        self.add_entry(frame, 4, "OpenAI Model", "OPENAI_MODEL")
        self.add_entry(frame, 5, "OpenAI API Key", "OPENAI_API_KEY", show="*")
        policy = ttk.LabelFrame(frame, text="Politique", padding=12)
        policy.grid(row=6, column=0, columnspan=2, sticky="ew", pady=16)
        self.add_entry(policy, 0, "Timeout job", "POLICY_JOB_TIMEOUT")
        self.add_entry(policy, 1, "Timeout max", "POLICY_MAX_JOB_TIMEOUT")
        self.add_entry(policy, 2, "Output max bytes", "POLICY_MAX_OUTPUT_BYTES")
        self.add_entry(policy, 3, "Jobs max / run", "POLICY_MAX_JOBS_PER_RUN")
        self.add_entry(policy, 4, "Jobs concurrents", "POLICY_MAX_CONCURRENT_JOBS")

    def build_security_tab(self, parent: ttk.Frame) -> None:
        frame = ttk.Frame(parent, padding=16)
        frame.pack(fill="both", expand=True)
        self.add_entry(frame, 0, "Dashboard API Key", "QUEEN_API_KEY", show="*")
        self.add_entry(frame, 1, "Redis password", "REDIS_PASSWORD", show="*")
        ttk.Label(frame, text="Laisse vide pour un mode local ouvert. Remplis-les pour durcir l’accès.", foreground="#555").grid(row=2, column=0, columnspan=2, sticky="w", pady=(8, 0))

    def build_evolution_tab(self, parent: ttk.Frame) -> None:
        frame = ttk.Frame(parent, padding=16)
        frame.pack(fill="both", expand=True)
        self.add_entry(frame, 0, "Iterations", "EVOLUTION_ITERS")
        self.add_entry(frame, 1, "Max files", "EVOLUTION_MAX_FILES")
        self.add_entry(frame, 2, "Exploration", "EVOLUTION_EXPLORATION")
        self.add_text(frame, 3, "Instruction", "EVOLUTION_INSTRUCTION", height=4)
        self.add_text(frame, 4, "Allowlist CSV", "EVOLUTION_ALLOWLIST", height=4)
        self.add_text(frame, 5, "Targets CSV", "EVOLUTION_TARGETS", height=4)
        ttk.Label(frame, text="Ensuite lance l’évolution depuis l’onglet Evolution du dashboard.", foreground="#555").grid(row=6, column=0, columnspan=2, sticky="w", pady=(8, 0))

    def build_logs_tab(self, parent: ttk.Frame) -> None:
        frame = ttk.Frame(parent, padding=16)
        frame.pack(fill="both", expand=True)
        self.log_text = tk.Text(frame, wrap="word", state="disabled", height=30)
        self.log_text.pack(fill="both", expand=True)

    def add_entry(self, parent: ttk.Widget, row: int, label: str, key: str, show: str | None = None) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=6, padx=(0, 12))
        entry = ttk.Entry(parent, textvariable=self.vars[key], width=70, show=show)
        entry.grid(row=row, column=1, sticky="ew", pady=6)
        try:
            parent.grid_columnconfigure(1, weight=1)
        except Exception:
            pass

    def add_text(self, parent: ttk.Widget, row: int, label: str, key: str, height: int = 3) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="nw", pady=6, padx=(0, 12))
        widget = tk.Text(parent, height=height, width=70)
        widget.insert("1.0", self.vars[key].get())
        widget.grid(row=row, column=1, sticky="ew", pady=6)

        def sync_var(event=None) -> None:
            self.vars[key].set(widget.get("1.0", "end").strip())

        widget.bind("<KeyRelease>", sync_var)
        try:
            parent.grid_columnconfigure(1, weight=1)
        except Exception:
            pass


def main() -> None:
    root = tk.Tk()
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass
    app = LauncherApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
