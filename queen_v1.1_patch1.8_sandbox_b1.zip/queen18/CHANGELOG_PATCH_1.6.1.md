# CHANGELOG — Queen V1.1 Patch 1.6.1 (Correctif)

Basé sur l'audit de la 1.6 qui identifie 2 régressions et 5 correctifs
incomplets. Ce patch reprend uniquement ce qui était cassé ou insuffisant.

Les ~70% de corrections valides de la 1.6 sont conservés intacts.

---

## LOT 1 — Auth unifiée backend (régression 1.6 corrigée)

**Problème 1.6** : Le backend exigeait `X-API-Key`, mais le frontend
envoyait `Authorization: Bearer`. Résultat : dashboard cassé dès qu'on
active `QUEEN_API_KEY`.

**Correction** : `auth_middleware.py` accepte maintenant les trois modes :
- Header `X-API-Key: <key>` (curl, scripts)
- Header `Authorization: Bearer <key>` (frontend)
- Query param `?token=<key>` (WebSocket handshake)

Les trois sont comparés au même `QUEEN_API_KEY`.

**Fichier** : `dashboard/backend/auth_middleware.py`

---

## LOT 2 — Frontend + WebSocket alignés sur l'auth

**Problème 1.6** : `client.ts` et `useEvents.ts` n'avaient pas été
adaptés au nouveau modèle d'auth. Le WebSocket était explicitement
exempté d'authentification.

**Corrections** :
- `client.ts` : envoie `Authorization: Bearer <key>` lu depuis
  `localStorage("queen_token")` (déjà en place) ou `window.__QUEEN_API_KEY`
- `useEvents.ts` : ajoute `?token=<key>` en query param à la connexion WS
- `api.py` : le endpoint `/ws/events` vérifie le token avant `accept()`

**Fichiers** : `dashboard/frontend/src/api/client.ts`,
`dashboard/frontend/src/ws/useEvents.ts`, `dashboard/backend/api.py`

---

## LOT 3 — Redis AUTH bout en bout (régression 1.6 corrigée)

**Problème 1.6** : `docker-compose.yml` ajoutait `--requirepass ${REDIS_PASSWORD:-}`
mais : (a) si vide, protection vide ; (b) healthcheck cassé ; (c) les
services gardaient `REDIS_URL` sans password.

**Correction** : Redis AUTH retiré du compose principal. Un overlay
dédié `docker-compose.redis-auth.yml` est fourni :
```bash
docker compose -f docker-compose.yml -f docker-compose.redis-auth.yml up
```
L'overlay ajuste : command, healthcheck, et REDIS_URL de chaque service.
Pas de fausse sécurité si on ne l'active pas.

**Fichiers** : `docker-compose.yml` (nettoyé), `docker-compose.redis-auth.yml` (nouveau)

---

## LOT 4 — Orchestrator double lecture (bug hérité non corrigé en 1.6)

**Problème** : `_wait_for_jobs()` appelait `memory.get_run()` + `memory.get_goal()`
deux fois par itération de boucle (budget check + budget warning), créant
une race condition et du gaspillage I/O.

**Correction** : Les contraintes goal sont lues une seule fois avant la
boucle (elles ne changent pas pendant le run). Le budget check et le
budget warning partagent un seul appel `tracker`.

**Fichier** : `queen_core/orchestrator.py`

---

## LOT 5 — Worker : vrai kill au lieu de thread.daemon

**Problème 1.6** : `thread.daemon = True` ne tue pas le thread — il
continue à consommer CPU/mémoire. Seul l'exit du process est débloqué.

**Correction** : Remplacement par `multiprocessing.Process`. Sur timeout :
`terminate()` (SIGTERM) puis `kill()` (SIGKILL) après 5s de grâce.
Le job est réellement stoppé.

**Fichier** : `workers/worker_base.py`

---

## LOT 6 — Patcher : edge cases diff

**Problème 1.6** : Le parseur diff amélioré gérait mieux les `\n` parasites
mais un diff de suppression pure produisait `new_content = "\n"` au lieu
d'un fichier vide.

**Correction** : Le parseur distingue maintenant :
- Fichier modifié (has `+` lines) → `new_content` normal
- Fichier supprimé (que des `-` lines) → `new_content = ""`, `action = "delete"`
- Trailing `\n\n` → nettoyé proprement

**Fichier** : `queen_core/patcher.py`

---

## LOT 7 — Evolver : dry_run cohérent

**Problème 1.6** : En `dry_run=True`, le patch n'est pas appliqué au
disque mais le smoke test tourne quand même sur les fichiers non modifiés,
donnant des résultats trompeurs.

**Correction** : Si `dry_run`, les smoke checks sont sautés et les
métriques sont marquées `None` avec une note explicative.

**Fichier** : `queen_core/evolution/evolver.py`

---

## LOT 8 — Worker : path traversal renforcé

**Problème 1.6** : `startswith(abs_ws + os.sep)` est contournable dans
certains cas (symlinks, encodage).

**Correction** : Utilisation de `os.path.realpath()` pour résoudre les
symlinks + `os.path.commonpath()` pour la comparaison.

**Fichier** : `workers/worker_unified.py`

---

## LOT 9 — Configuration alignée

- `.env.example` : ajout des sections `QUEEN_API_KEY` et `REDIS_PASSWORD`
  avec documentation inline

**Fichier** : `.env.example`

---

## LOT 10 — Ce changelog

---

## Résumé

| Catégorie | Action |
|-----------|--------|
| Régressions 1.6 corrigées | Auth dashboard (LOT 1-2), Redis auth (LOT 3) |
| Bugs hérités corrigés | Double lecture orchestrator (LOT 4), thread zombie (LOT 5) |
| Correctifs insuffisants repris | Patcher diff (LOT 6), dry_run evolution (LOT 7) |
| Renforcements | Path traversal (LOT 8), config (LOT 9) |

### Ce qui n'est PAS dans ce patch
- Tests d'intégration
- Migration automatique des tokens frontend existants
- Rate limiting API
- Audit des routes non-REST (WebSocket events content)
