"""
test_sandbox.py — Tests for sandboxed user benchmark execution.

Run: python3 test_sandbox.py
"""

import os
import shutil
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from queen_core.evolution.bench_runner import (
    _discover_user_benchmark_names,
    _run_user_benchmark_sandboxed,
    run_benchmarks,
)


def _make_bench_dir(tmpdir, files):
    """Create a benchmarks directory with given {filename: content}."""
    d = os.path.join(tmpdir, "benchmarks")
    os.makedirs(d, exist_ok=True)
    for fn, content in files.items():
        with open(os.path.join(d, fn), "w") as f:
            f.write(content)
    return d


# ── Test 1: Normal user benchmark runs in subprocess ─────────────

def test_normal_benchmark_sandboxed():
    tmpdir = tempfile.mkdtemp()
    try:
        bd = _make_bench_dir(tmpdir, {
            "good.py": "def bench_ok(candidate_src):\n    return 0.75\n",
        })
        entries = _discover_user_benchmark_names(bd)
        assert len(entries) == 1
        name, path, func = entries[0]
        assert func == "bench_ok"

        r = _run_user_benchmark_sandboxed(path, func, tmpdir)
        assert r["sandboxed"] is True
        assert r["score"] == 0.75
        assert r["error"] is None
        print(f"PASS: test_normal_benchmark_sandboxed (score={r['score']})")
    finally:
        shutil.rmtree(tmpdir)


# ── Test 2: Crashing benchmark scores 0 without killing main ────

def test_crashing_benchmark():
    tmpdir = tempfile.mkdtemp()
    try:
        bd = _make_bench_dir(tmpdir, {
            "crash.py": "def bench_boom(candidate_src):\n    raise RuntimeError('deliberate crash')\n",
        })
        entries = _discover_user_benchmark_names(bd)
        _, path, func = entries[0]

        r = _run_user_benchmark_sandboxed(path, func, tmpdir)
        assert r["score"] == 0.0
        assert r["error"] is not None
        assert "deliberate crash" in r["error"] or r["error"]  # some error reported
        print(f"PASS: test_crashing_benchmark (error={r['error'][:60]})")
    finally:
        shutil.rmtree(tmpdir)


# ── Test 3: Infinite loop benchmark killed by timeout ────────────

def test_timeout_benchmark():
    tmpdir = tempfile.mkdtemp()
    try:
        bd = _make_bench_dir(tmpdir, {
            "hang.py": "import time\ndef bench_infinite(candidate_src):\n    time.sleep(999)\n    return 1.0\n",
        })
        entries = _discover_user_benchmark_names(bd)
        _, path, func = entries[0]

        t0 = time.time()
        r = _run_user_benchmark_sandboxed(path, func, tmpdir, timeout=2)
        elapsed = time.time() - t0

        assert r["score"] == 0.0
        assert "Timeout" in (r["error"] or "")
        assert elapsed < 5, f"Should have timed out in ~2s, took {elapsed:.1f}s"
        print(f"PASS: test_timeout_benchmark (killed in {elapsed:.1f}s)")
    finally:
        shutil.rmtree(tmpdir)


# ── Test 4: Syntax error in user benchmark → score 0 ────────────

def test_syntax_error_benchmark():
    tmpdir = tempfile.mkdtemp()
    try:
        bd = _make_bench_dir(tmpdir, {
            "broken.py": "def bench_broken(candidate_src)\n    return 1.0\n",  # missing colon
        })
        # AST parse should fail → no benchmarks discovered
        entries = _discover_user_benchmark_names(bd)
        assert len(entries) == 0, f"Broken file should not yield benchmarks, got {entries}"
        print("PASS: test_syntax_error_benchmark (not discovered)")
    finally:
        shutil.rmtree(tmpdir)


# ── Test 5: Benchmark returning invalid value → clamped ──────────

def test_invalid_return_clamped():
    tmpdir = tempfile.mkdtemp()
    try:
        bd = _make_bench_dir(tmpdir, {
            "bad_val.py": "def bench_too_high(candidate_src):\n    return 999.0\n",
        })
        entries = _discover_user_benchmark_names(bd)
        _, path, func = entries[0]
        r = _run_user_benchmark_sandboxed(path, func, tmpdir)
        assert r["score"] == 1.0, f"Should be clamped to 1.0, got {r['score']}"
        print("PASS: test_invalid_return_clamped")
    finally:
        shutil.rmtree(tmpdir)


# ── Test 6: Discovery uses AST, not import ───────────────────────

def test_discovery_is_ast_not_import():
    """Discovery should use AST parsing, not importlib. A file with
    side effects in module scope should NOT execute during discovery."""
    tmpdir = tempfile.mkdtemp()
    try:
        marker = os.path.join(tmpdir, "IMPORTED_FLAG")
        bd = _make_bench_dir(tmpdir, {
            "sideeffect.py": f"""
import os
# This should NOT run during discovery
os.makedirs({marker!r}, exist_ok=True)

def bench_sneaky(candidate_src):
    return 0.5
""",
        })
        entries = _discover_user_benchmark_names(bd)
        assert len(entries) == 1
        assert not os.path.exists(marker), "Module was imported during discovery — should only use AST"
        print("PASS: test_discovery_is_ast_not_import")
    finally:
        shutil.rmtree(tmpdir)


# ── Test 7: Sandboxed benchmarks integrated into run_benchmarks ──

def test_integration_with_run_benchmarks():
    tmpdir = tempfile.mkdtemp()
    try:
        # Create a mini candidate src
        src = os.path.join(tmpdir, "candidate")
        os.makedirs(os.path.join(src, "queen_core"))
        with open(os.path.join(src, "queen_core", "x.py"), "w") as f:
            f.write("x = 1\n")

        bd = _make_bench_dir(tmpdir, {
            "custom.py": "def bench_always_one(candidate_src):\n    return 1.0\n",
        })
        r = run_benchmarks(src, benchmarks_dir=bd)
        assert r["user_count"] == 1
        user_r = r["benchmark_results"].get("user:custom.py::bench_always_one", {})
        assert user_r.get("sandboxed") is True
        assert user_r["score"] == 1.0
        print(f"PASS: test_integration_with_run_benchmarks (user_count={r['user_count']})")
    finally:
        shutil.rmtree(tmpdir)


# ── Test 8: Sensitive env vars stripped ───────────────────────────

def test_env_vars_stripped():
    """Benchmark subprocess should NOT see QUEEN_API_KEY etc."""
    tmpdir = tempfile.mkdtemp()
    try:
        bd = _make_bench_dir(tmpdir, {
            "env_check.py": """
import os
def bench_check_env(candidate_src):
    # Should NOT have access to sensitive vars
    if os.environ.get("QUEEN_API_KEY"):
        return 0.0  # fail: leaked
    if os.environ.get("OPENAI_API_KEY"):
        return 0.0
    return 1.0
""",
        })
        # Set sensitive env vars in current process
        old_key = os.environ.get("QUEEN_API_KEY")
        os.environ["QUEEN_API_KEY"] = "test-secret-key"
        try:
            entries = _discover_user_benchmark_names(bd)
            _, path, func = entries[0]
            r = _run_user_benchmark_sandboxed(path, func, tmpdir)
            assert r["score"] == 1.0, f"Env vars leaked to subprocess: {r}"
            print("PASS: test_env_vars_stripped")
        finally:
            if old_key is None:
                os.environ.pop("QUEEN_API_KEY", None)
            else:
                os.environ["QUEEN_API_KEY"] = old_key
    finally:
        shutil.rmtree(tmpdir)


# ── Runner ───────────────────────────────────────────────────────

if __name__ == "__main__":
    tests = [
        test_normal_benchmark_sandboxed,
        test_crashing_benchmark,
        test_timeout_benchmark,
        test_syntax_error_benchmark,
        test_invalid_return_clamped,
        test_discovery_is_ast_not_import,
        test_integration_with_run_benchmarks,
        test_env_vars_stripped,
    ]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"FAIL: {t.__name__} — {e}")
            import traceback; traceback.print_exc()
            failed += 1
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    if failed:
        sys.exit(1)
    print("ALL TESTS PASSED")
