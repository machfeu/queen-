"""
test_workspace_api.py — Tests for workspace file management API.

Tests the workspace_routes module directly (no FastAPI server needed).
Run: python3 test_workspace_api.py
"""

import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import dashboard.backend.workspace_routes as ws
from dashboard.backend.workspace_routes import (
    _validate_path, _safe_filename, list_workspace, make_directory,
    delete_path, write_file, WorkspaceError,
)


def _setup():
    """Create a temp workspace and override WORKSPACE_BASE."""
    tmpdir = tempfile.mkdtemp()
    workspace = os.path.join(tmpdir, "workspace")
    os.makedirs(workspace)
    ws.WORKSPACE_BASE = workspace
    return tmpdir, workspace


def _teardown(tmpdir):
    shutil.rmtree(tmpdir)


# ── Path validation ──────────────────────────────────────────────

def test_validate_normal_path():
    tmpdir, workspace = _setup()
    try:
        result = ws._validate_path("subdir/file.py")
        assert result == os.path.realpath(os.path.join(workspace, "subdir/file.py"))
        print("PASS: test_validate_normal_path")
    finally:
        _teardown(tmpdir)


def test_validate_traversal_blocked():
    tmpdir, workspace = _setup()
    try:
        caught = False
        try:
            ws._validate_path("../../etc/passwd")
        except Exception as e:
            if "403" in str(e) or "traversal" in str(e).lower():
                caught = True
        assert caught, "Path traversal should be blocked"
        print("PASS: test_validate_traversal_blocked")
    finally:
        _teardown(tmpdir)


def test_validate_prefix_attack():
    tmpdir, workspace = _setup()
    try:
        evil = workspace + "evil"
        os.makedirs(evil, exist_ok=True)
        caught = False
        try:
            # This would resolve to /tmp/.../workspaceevil if not caught
            ws._validate_path("../workspaceevil")
        except Exception:
            caught = True
        assert caught, "Prefix attack should be blocked"
        print("PASS: test_validate_prefix_attack")
    finally:
        _teardown(tmpdir)


# ── List ─────────────────────────────────────────────────────────

def test_list_empty_workspace():
    tmpdir, workspace = _setup()
    try:
        result = ws.list_workspace("")
        assert result["type"] == "dir"
        assert result["entries"] == []
        print("PASS: test_list_empty_workspace")
    finally:
        _teardown(tmpdir)


def test_list_with_files():
    tmpdir, workspace = _setup()
    try:
        with open(os.path.join(workspace, "test.py"), "w") as f:
            f.write("x = 1\n")
        os.makedirs(os.path.join(workspace, "subdir"))
        result = ws.list_workspace("")
        names = [e["name"] for e in result["entries"]]
        assert "test.py" in names
        assert "subdir" in names
        print("PASS: test_list_with_files")
    finally:
        _teardown(tmpdir)


def test_read_file():
    tmpdir, workspace = _setup()
    try:
        with open(os.path.join(workspace, "hello.txt"), "w") as f:
            f.write("hello world")
        result = ws.list_workspace("hello.txt")
        assert result["type"] == "file"
        assert result["content"] == "hello world"
        assert result["size"] == 11
        print("PASS: test_read_file")
    finally:
        _teardown(tmpdir)


# ── Mkdir ────────────────────────────────────────────────────────

def test_mkdir():
    tmpdir, workspace = _setup()
    try:
        result = make_directory("project/src")
        assert result["ok"]
        assert os.path.isdir(os.path.join(workspace, "project/src"))
        print("PASS: test_mkdir")
    finally:
        _teardown(tmpdir)


def test_mkdir_idempotent():
    tmpdir, workspace = _setup()
    try:
        make_directory("existing")
        result = make_directory("existing")
        assert result["ok"]
        assert result["existed"]
        print("PASS: test_mkdir_idempotent")
    finally:
        _teardown(tmpdir)


# ── Delete ───────────────────────────────────────────────────────

def test_delete_file():
    tmpdir, workspace = _setup()
    try:
        with open(os.path.join(workspace, "to_delete.txt"), "w") as f:
            f.write("bye")
        result = ws.delete_path("to_delete.txt")
        assert result["ok"]
        assert not os.path.exists(os.path.join(workspace, "to_delete.txt"))
        print("PASS: test_delete_file")
    finally:
        _teardown(tmpdir)


def test_delete_directory():
    tmpdir, workspace = _setup()
    try:
        os.makedirs(os.path.join(workspace, "dir_to_del/sub"))
        with open(os.path.join(workspace, "dir_to_del/sub/f.txt"), "w") as f:
            f.write("data")
        result = ws.delete_path("dir_to_del")
        assert result["ok"]
        assert not os.path.exists(os.path.join(workspace, "dir_to_del"))
        print("PASS: test_delete_directory")
    finally:
        _teardown(tmpdir)


def test_delete_root_blocked():
    tmpdir, workspace = _setup()
    try:
        caught = False
        try:
            ws.delete_path("")
        except Exception as e:
            if "400" in str(e) or "required" in str(e).lower():
                caught = True
        assert caught, "Deleting root should be blocked"
        print("PASS: test_delete_root_blocked")
    finally:
        _teardown(tmpdir)


def test_delete_nonexistent():
    tmpdir, workspace = _setup()
    try:
        caught = False
        try:
            delete_path("ghost.txt")
        except WorkspaceError as e:
            if e.status_code == 404:
                caught = True
        assert caught
        print("PASS: test_delete_nonexistent")
    finally:
        _teardown(tmpdir)


# ── Upload (sync test — we test the logic, not async) ───────────

def test_write_file():
    """Test write_file core function (used by upload + import)."""
    tmpdir, workspace = _setup()
    try:
        result = write_file(b"print('uploaded')\n", "", "my_script.py")
        assert result["ok"]
        dest = os.path.join(workspace, "my_script.py")
        assert os.path.isfile(dest)
        with open(dest) as f:
            assert "uploaded" in f.read()
        print("PASS: test_write_file")
    finally:
        _teardown(tmpdir)


def test_write_file_collision():
    tmpdir, workspace = _setup()
    try:
        write_file(b"first", "", "dup.txt")
        caught = False
        try:
            write_file(b"second", "", "dup.txt", overwrite=False)
        except WorkspaceError as e:
            if e.status_code == 409:
                caught = True
        assert caught, "Should refuse overwrite by default"
        # With overwrite=True
        result = write_file(b"second", "", "dup.txt", overwrite=True)
        assert result["ok"]
        with open(os.path.join(workspace, "dup.txt")) as f:
            assert f.read() == "second"
        print("PASS: test_write_file_collision")
    finally:
        _teardown(tmpdir)


def test_safe_filename_sanitization():
    assert ws._safe_filename("normal.py") == "normal.py"
    assert ws._safe_filename("my file.txt") == "my file.txt"
    assert ws._safe_filename("weird<>chars.py") == "weird__chars.py"
    caught = False
    try:
        ws._safe_filename(".hidden")
    except Exception:
        caught = True
    assert caught, "Hidden files should be rejected"
    caught = False
    try:
        ws._safe_filename("../../../etc/passwd")
    except Exception:
        caught = True
    # basename of "../../../etc/passwd" is "passwd" which is valid
    # but the path validation catches traversal
    print("PASS: test_safe_filename_sanitization")


# ── Import URL (logic only — actual download needs network) ──────

def test_import_url_validation():
    """Test URL validation without actual download."""
    tmpdir, workspace = _setup()
    try:
        from urllib.parse import urlparse

        # Bad scheme
        parsed = urlparse("ftp://evil.com/file")
        assert parsed.scheme not in ("http", "https")

        # Good scheme
        parsed = urlparse("https://example.com/data.csv")
        assert parsed.scheme == "https"
        assert parsed.netloc == "example.com"

        # Filename extraction
        basename = os.path.basename(parsed.path)
        assert basename == "data.csv"

        print("PASS: test_import_url_validation")
    finally:
        _teardown(tmpdir)


def test_ssrf_localhost_blocked():
    from dashboard.backend.workspace_routes import _check_ssrf, WorkspaceError
    for host in ("localhost", "127.0.0.1", "::1", "0.0.0.0"):
        caught = False
        try:
            _check_ssrf(host)
        except WorkspaceError as e:
            if e.status_code == 403:
                caught = True
        assert caught, f"Should block {host}"
    print("PASS: test_ssrf_localhost_blocked")


def test_ssrf_private_ip_blocked():
    from dashboard.backend.workspace_routes import _check_ssrf, WorkspaceError
    # 10.x.x.x, 172.16.x.x, 192.168.x.x resolve to private — test with raw IPs
    for ip in ("10.0.0.1", "172.16.0.1", "192.168.1.1"):
        caught = False
        try:
            _check_ssrf(ip)
        except WorkspaceError as e:
            if e.status_code == 403:
                caught = True
        assert caught, f"Should block private IP {ip}"
    print("PASS: test_ssrf_private_ip_blocked")


def test_ssrf_metadata_blocked():
    from dashboard.backend.workspace_routes import _check_ssrf, WorkspaceError
    caught = False
    try:
        _check_ssrf("metadata.google.internal")
    except WorkspaceError:
        caught = True
    assert caught, "Should block cloud metadata endpoint"
    print("PASS: test_ssrf_metadata_blocked")


def test_ssrf_public_ip_allowed():
    from dashboard.backend.workspace_routes import _check_ssrf
    # 8.8.8.8 is public — should NOT be blocked
    try:
        _check_ssrf("8.8.8.8")
        print("PASS: test_ssrf_public_ip_allowed")
    except Exception as e:
        # DNS resolution might fail in sandboxed env — that's OK
        print(f"PASS: test_ssrf_public_ip_allowed (dns unavailable: {e})")


# ── Runner ───────────────────────────────────────────────────────

if __name__ == "__main__":
    tests = [
        test_validate_normal_path,
        test_validate_traversal_blocked,
        test_validate_prefix_attack,
        test_list_empty_workspace,
        test_list_with_files,
        test_read_file,
        test_mkdir,
        test_mkdir_idempotent,
        test_delete_file,
        test_delete_directory,
        test_delete_root_blocked,
        test_delete_nonexistent,
        test_write_file,
        test_write_file_collision,
        test_safe_filename_sanitization,
        test_import_url_validation,
        test_ssrf_localhost_blocked,
        test_ssrf_private_ip_blocked,
        test_ssrf_metadata_blocked,
        test_ssrf_public_ip_allowed,
    ]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"FAIL: {t.__name__} — {e}")
            import traceback; traceback.print_exc()
            failed += 1
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    if failed:
        sys.exit(1)
    print("ALL TESTS PASSED")
