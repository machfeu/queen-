"""
test_env_check.py — Tests for environment detection module.

Run: python3 test_env_check.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from env_check import (
    check_docker_installed,
    check_docker_running,
    check_ollama_installed,
    check_ollama_running,
    check_model_available,
    full_check,
)


def test_docker_installed_returns_dict():
    """check_docker_installed must return a dict with 'installed' key."""
    result = check_docker_installed()
    assert isinstance(result, dict)
    assert "installed" in result
    assert isinstance(result["installed"], bool)
    if result["installed"]:
        assert result["path"] is not None
    print(f"PASS: test_docker_installed_returns_dict (installed={result['installed']})")


def test_docker_running_returns_dict():
    """check_docker_running must return a dict with 'running' key."""
    result = check_docker_running()
    assert isinstance(result, dict)
    assert "running" in result
    assert isinstance(result["running"], bool)
    print(f"PASS: test_docker_running_returns_dict (running={result['running']})")


def test_ollama_installed_returns_dict():
    result = check_ollama_installed()
    assert isinstance(result, dict)
    assert "installed" in result
    print(f"PASS: test_ollama_installed_returns_dict (installed={result['installed']})")


def test_ollama_running_unreachable():
    """Calling check_ollama_running on a port that doesn't exist should return running=False."""
    result = check_ollama_running("http://127.0.0.1:19999")
    assert result["running"] is False
    assert "error" in result
    print("PASS: test_ollama_running_unreachable")


def test_model_available_when_ollama_down():
    """Model check on unreachable Ollama should return available=False."""
    result = check_model_available("test-model", "http://127.0.0.1:19999")
    assert result["available"] is False
    assert result["ollama_running"] is False
    print("PASS: test_model_available_when_ollama_down")


def test_full_check_structure():
    """full_check must return all expected keys."""
    result = full_check(ollama_url="http://127.0.0.1:19999", model_name="test-model")
    assert "docker" in result
    assert "ollama" in result
    assert "model" in result
    assert "ready" in result
    assert isinstance(result["ready"], bool)
    # With unreachable Ollama, ready should be False
    assert result["ready"] is False
    print(f"PASS: test_full_check_structure (ready={result['ready']})")


def test_full_check_no_model():
    """full_check with empty model_name should not fail."""
    result = full_check(ollama_url="http://127.0.0.1:19999", model_name="")
    assert "docker" in result
    assert "model" in result
    print("PASS: test_full_check_no_model")


def test_check_docker_installed_consistency():
    """If docker is installed, version should be a string."""
    result = check_docker_installed()
    if result["installed"]:
        assert result["version"] is None or isinstance(result["version"], str)
    print("PASS: test_check_docker_installed_consistency")


def test_guidance_when_nothing_installed():
    """With unreachable services, guidance should have critical messages."""
    result = full_check(ollama_url="http://127.0.0.1:19999", model_name="test-model")
    guidance = result.get("guidance", [])
    assert len(guidance) >= 1, "Should have at least one guidance message"
    levels = [g.get("level") for g in guidance]
    # At minimum, docker or ollama should generate a message
    assert "critical" in levels or "warning" in levels, f"Expected critical/warning, got {levels}"
    print(f"PASS: test_guidance_when_nothing_installed ({len(guidance)} messages)")


def test_guidance_has_urls():
    """Install guidance should include download URLs."""
    from env_check import _build_guidance, DOCKER_DOWNLOAD_URL, OLLAMA_DOWNLOAD_URL
    # Simulate nothing installed
    guidance = _build_guidance(
        {"installed": False}, {"running": False},
        {"installed": False}, {"running": False},
        {"available": False}, "test-model",
    )
    urls = [g.get("url") for g in guidance if g.get("url")]
    assert DOCKER_DOWNLOAD_URL in urls, f"Docker URL missing from {urls}"
    assert OLLAMA_DOWNLOAD_URL in urls, f"Ollama URL missing from {urls}"
    print("PASS: test_guidance_has_urls")


def test_guidance_has_steps():
    """Install guidance should include step-by-step instructions."""
    from env_check import _build_guidance
    guidance = _build_guidance(
        {"installed": False}, {"running": False},
        {"installed": False}, {"running": False},
        {"available": False}, "",
    )
    for g in guidance:
        if g.get("action") in ("install_docker", "install_ollama"):
            assert len(g.get("steps", [])) >= 2, f"Guidance {g['title']} has too few steps"
    print("PASS: test_guidance_has_steps")


def test_guidance_ok_when_ready():
    """When everything is ready, guidance should say OK."""
    from env_check import _build_guidance
    guidance = _build_guidance(
        {"installed": True}, {"running": True},
        {"installed": True}, {"running": True},
        {"available": True}, "model",
    )
    assert len(guidance) == 1
    assert guidance[0]["level"] == "ok"
    print("PASS: test_guidance_ok_when_ready")


def test_wsl_check_returns_dict():
    from env_check import check_wsl_available
    result = check_wsl_available()
    assert isinstance(result, dict)
    assert "relevant" in result
    print(f"PASS: test_wsl_check_returns_dict (relevant={result['relevant']})")


# ── Runner ───────────────────────────────────────────────────────

if __name__ == "__main__":
    tests = [
        test_docker_installed_returns_dict,
        test_docker_running_returns_dict,
        test_ollama_installed_returns_dict,
        test_ollama_running_unreachable,
        test_model_available_when_ollama_down,
        test_full_check_structure,
        test_full_check_no_model,
        test_check_docker_installed_consistency,
        test_guidance_when_nothing_installed,
        test_guidance_has_urls,
        test_guidance_has_steps,
        test_guidance_ok_when_ready,
        test_wsl_check_returns_dict,
    ]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"FAIL: {t.__name__} — {e}")
            import traceback; traceback.print_exc()
            failed += 1
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    if failed:
        sys.exit(1)
    print("ALL TESTS PASSED")
