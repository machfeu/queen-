import { useCallback, useEffect, useRef, useState } from "react";
import {
  ActionIcon,
  Alert,
  Badge,
  Breadcrumbs,
  Button,
  Code,
  Group,
  Loader,
  Modal,
  Paper,
  Stack,
  Table,
  Text,
  TextInput,
  Title,
  Tooltip,
} from "@mantine/core";
import {
  IconAlertCircle,
  IconArrowLeft,
  IconFile,
  IconFolder,
  IconFolderPlus,
  IconRefresh,
  IconTrash,
  IconUpload,
  IconWorldDownload,
} from "@tabler/icons-react";
import { workspace, WorkspaceEntry, WorkspaceListResult } from "../api/client";

export default function Workspace() {
  const [currentPath, setCurrentPath] = useState("");
  const [data, setData] = useState<WorkspaceListResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Modals
  const [mkdirOpen, setMkdirOpen] = useState(false);
  const [mkdirName, setMkdirName] = useState("");
  const [urlOpen, setUrlOpen] = useState(false);
  const [importUrl, setImportUrl] = useState("");
  const [importFilename, setImportFilename] = useState("");

  const fileInputRef = useRef<HTMLInputElement>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const result = await workspace.list(currentPath);
      setData(result);
    } catch (e: any) {
      setError(e.message || "Failed to load workspace");
    } finally {
      setLoading(false);
    }
  }, [currentPath]);

  useEffect(() => { refresh(); }, [refresh]);

  const navigate = (entry: WorkspaceEntry) => {
    setCurrentPath(currentPath ? `${currentPath}/${entry.name}` : entry.name);
  };

  const goUp = () => {
    const parts = currentPath.split("/").filter(Boolean);
    parts.pop();
    setCurrentPath(parts.join("/"));
  };

  const breadcrumbs = [
    { label: "/workspace", path: "" },
    ...currentPath.split("/").filter(Boolean).map((part, i, arr) => ({
      label: part,
      path: arr.slice(0, i + 1).join("/"),
    })),
  ];

  // ── Upload ─────────────────────────────────────────────────────
  const handleUpload = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setError("");
    setSuccess("");
    try {
      for (const file of Array.from(files)) {
        await workspace.upload(file, currentPath, false);
      }
      setSuccess(`${files.length} file(s) uploaded`);
      refresh();
    } catch (e: any) {
      setError(e.message || "Upload failed");
    }
  };

  // ── Import URL ────────────────────────────────────────────────
  const handleImportUrl = async () => {
    if (!importUrl) return;
    setError("");
    setSuccess("");
    setUrlOpen(false);
    try {
      const result = await workspace.importUrl(
        importUrl, currentPath, importFilename || undefined, false
      );
      setSuccess(`Imported ${result.path} (${formatSize(result.size)})`);
      setImportUrl("");
      setImportFilename("");
      refresh();
    } catch (e: any) {
      setError(e.message || "Import failed");
    }
  };

  // ── Mkdir ──────────────────────────────────────────────────────
  const handleMkdir = async () => {
    if (!mkdirName) return;
    setMkdirOpen(false);
    setError("");
    try {
      const fullPath = currentPath ? `${currentPath}/${mkdirName}` : mkdirName;
      await workspace.mkdir(fullPath);
      setSuccess(`Created folder: ${mkdirName}`);
      setMkdirName("");
      refresh();
    } catch (e: any) {
      setError(e.message || "Failed to create folder");
    }
  };

  // ── Delete ─────────────────────────────────────────────────────
  const handleDelete = async (entry: WorkspaceEntry) => {
    const fullPath = currentPath ? `${currentPath}/${entry.name}` : entry.name;
    if (!confirm(`Delete ${entry.type === "dir" ? "folder" : "file"} "${entry.name}"?`)) return;
    setError("");
    try {
      await workspace.remove(fullPath);
      setSuccess(`Deleted: ${entry.name}`);
      refresh();
    } catch (e: any) {
      setError(e.message || "Delete failed");
    }
  };

  // ── File view ─────────────────────────────────────────────────
  if (data?.type === "file") {
    return (
      <Stack>
        <Group>
          <Button variant="subtle" leftSection={<IconArrowLeft size={16} />} onClick={goUp}>
            Back
          </Button>
          <Title order={3}>{currentPath.split("/").pop()}</Title>
          <Badge size="sm">{formatSize(data.size ?? 0)}</Badge>
        </Group>
        <Code style={{ fontSize: 13 }}>{data.full_path}</Code>
        <Paper p="md" radius="md" withBorder style={{ maxHeight: 600, overflow: "auto" }}>
          <pre style={{ margin: 0, whiteSpace: "pre-wrap", fontSize: 13 }}>{data.content}</pre>
        </Paper>
      </Stack>
    );
  }

  return (
    <Stack>
      <Group justify="space-between">
        <Title order={2}>Workspace</Title>
        <Group gap="xs">
          <Tooltip label="Upload file">
            <ActionIcon variant="light" color="blue" size="lg"
              onClick={() => fileInputRef.current?.click()}>
              <IconUpload size={18} />
            </ActionIcon>
          </Tooltip>
          <Tooltip label="Import from URL">
            <ActionIcon variant="light" color="cyan" size="lg" onClick={() => setUrlOpen(true)}>
              <IconWorldDownload size={18} />
            </ActionIcon>
          </Tooltip>
          <Tooltip label="New folder">
            <ActionIcon variant="light" color="green" size="lg" onClick={() => setMkdirOpen(true)}>
              <IconFolderPlus size={18} />
            </ActionIcon>
          </Tooltip>
          <Tooltip label="Refresh">
            <ActionIcon variant="light" size="lg" onClick={refresh} loading={loading}>
              <IconRefresh size={18} />
            </ActionIcon>
          </Tooltip>
        </Group>
      </Group>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        style={{ display: "none" }}
        onChange={(e) => handleUpload(e.target.files)}
      />

      {/* Breadcrumbs */}
      <Breadcrumbs>
        {breadcrumbs.map((bc) => (
          <Text
            key={bc.path}
            size="sm"
            style={{ cursor: "pointer" }}
            fw={bc.path === currentPath ? 700 : 400}
            onClick={() => setCurrentPath(bc.path)}
          >
            {bc.label}
          </Text>
        ))}
      </Breadcrumbs>

      {error && <Alert color="red" icon={<IconAlertCircle size={16} />} withCloseButton onClose={() => setError("")}>{error}</Alert>}
      {success && <Alert color="green" withCloseButton onClose={() => setSuccess("")}>{success}</Alert>}

      {loading && !data ? (
        <Loader m="xl" />
      ) : (
        <Paper p="md" radius="md" withBorder>
          {!data?.entries?.length ? (
            <Text size="sm" c="dimmed" ta="center" py="xl">
              This folder is empty. Upload a file or create a subfolder.
            </Text>
          ) : (
            <Table highlightOnHover>
              <Table.Thead>
                <Table.Tr>
                  <Table.Th>Name</Table.Th>
                  <Table.Th>Type</Table.Th>
                  <Table.Th>Size</Table.Th>
                  <Table.Th w={50}></Table.Th>
                </Table.Tr>
              </Table.Thead>
              <Table.Tbody>
                {currentPath && (
                  <Table.Tr style={{ cursor: "pointer" }} onClick={goUp}>
                    <Table.Td>
                      <Group gap={8}>
                        <IconArrowLeft size={16} color="gray" />
                        <Text size="sm" c="dimmed">..</Text>
                      </Group>
                    </Table.Td>
                    <Table.Td></Table.Td>
                    <Table.Td></Table.Td>
                    <Table.Td></Table.Td>
                  </Table.Tr>
                )}
                {data?.entries?.map((entry) => (
                  <Table.Tr
                    key={entry.name}
                    style={{ cursor: "pointer" }}
                    onClick={() => navigate(entry)}
                  >
                    <Table.Td>
                      <Group gap={8}>
                        {entry.type === "dir" ? (
                          <IconFolder size={16} color="var(--mantine-color-blue-5)" />
                        ) : (
                          <IconFile size={16} color="var(--mantine-color-gray-5)" />
                        )}
                        <Text size="sm">{entry.name}</Text>
                      </Group>
                    </Table.Td>
                    <Table.Td>
                      <Badge size="xs" variant="light" color={entry.type === "dir" ? "blue" : "gray"}>
                        {entry.type}
                      </Badge>
                    </Table.Td>
                    <Table.Td>
                      <Text size="xs" c="dimmed">{entry.type === "file" ? formatSize(entry.size) : ""}</Text>
                    </Table.Td>
                    <Table.Td>
                      <ActionIcon
                        variant="subtle" color="red" size="sm"
                        onClick={(e) => { e.stopPropagation(); handleDelete(entry); }}
                      >
                        <IconTrash size={14} />
                      </ActionIcon>
                    </Table.Td>
                  </Table.Tr>
                ))}
              </Table.Tbody>
            </Table>
          )}
          {data?.total && data.total > (data?.entries?.length ?? 0) && (
            <Text size="xs" c="dimmed" ta="center" mt="sm">
              Showing {data.entries?.length} of {data.total} items
            </Text>
          )}
        </Paper>
      )}

      {/* Mkdir modal */}
      <Modal opened={mkdirOpen} onClose={() => setMkdirOpen(false)} title="Create folder" size="sm">
        <Stack>
          <TextInput
            label="Folder name"
            placeholder="my-project"
            value={mkdirName}
            onChange={(e) => setMkdirName(e.currentTarget.value)}
            onKeyDown={(e) => e.key === "Enter" && handleMkdir()}
          />
          <Button onClick={handleMkdir} disabled={!mkdirName}>Create</Button>
        </Stack>
      </Modal>

      {/* Import URL modal */}
      <Modal opened={urlOpen} onClose={() => setUrlOpen(false)} title="Import from URL" size="md">
        <Stack>
          <TextInput
            label="URL"
            placeholder="https://example.com/data.csv"
            value={importUrl}
            onChange={(e) => setImportUrl(e.currentTarget.value)}
          />
          <TextInput
            label="Save as (optional)"
            placeholder="Auto-detect from URL"
            value={importFilename}
            onChange={(e) => setImportFilename(e.currentTarget.value)}
          />
          <Button onClick={handleImportUrl} disabled={!importUrl}>Import</Button>
        </Stack>
      </Modal>
    </Stack>
  );
}

function formatSize(bytes: number): string {
  if (bytes === 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0)} ${units[i]}`;
}
