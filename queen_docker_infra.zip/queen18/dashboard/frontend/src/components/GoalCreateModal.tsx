/**
 * GoalCreateModal.tsx — Modal de création d'objectif.
 * Champs: titre, description, risque, timeout, critères de succès.
 * + Sélection de fichiers workspace / upload inline.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Modal, TextInput, Textarea, Select, NumberInput, Button,
  Stack, Group, Text, Switch, Paper, Badge, ActionIcon, Divider,
  Code, Loader,
} from "@mantine/core";
import { notifications } from "@mantine/notifications";
import {
  IconFile, IconFolder, IconArrowLeft, IconUpload, IconTrash,
} from "@tabler/icons-react";
import { useCreateGoal, useRoles } from "../api/hooks";
import { workspace, WorkspaceEntry } from "../api/client";

interface Props {
  opened: boolean;
  onClose: () => void;
}

export default function GoalCreateModal({ opened, onClose }: Props) {
  const createMut = useCreateGoal();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const rolesQ = useRoles();

  const [role, setRole] = useState<string>("");
  const [riskLevel, setRiskLevel] = useState<string>("medium");
  const [timeout, setTimeout] = useState<number>(300);
  const [successCriteria, setSuccessCriteria] = useState("");
  const [manualApproval, setManualApproval] = useState(true);

  // File picker state
  const [targetFiles, setTargetFiles] = useState<string[]>([]);
  const [pickerOpen, setPickerOpen] = useState(false);

  const reset = () => {
    setTitle("");
    setDescription("");
    setRole("");
    setRiskLevel("medium");
    setTimeout(300);
    setSuccessCriteria("");
    setManualApproval(true);
    setTargetFiles([]);
  };

  const addFile = (path: string) => {
    if (path && !targetFiles.includes(path)) {
      setTargetFiles([...targetFiles, path]);
    }
  };

  const removeFile = (path: string) => {
    setTargetFiles(targetFiles.filter((f) => f !== path));
  };

  const handleSubmit = () => {
    if (!title.trim()) {
      notifications.show({ title: "Erreur", message: "Le titre est requis", color: "red" });
      return;
    }

    const constraints: Record<string, unknown> = {
      risk_level: riskLevel,
      timeout,
      success_criteria: successCriteria.trim(),
      require_manual_approval: manualApproval,
      ...(role ? { role } : {}),
    };
    if (targetFiles.length > 0) {
      constraints.target_files = targetFiles;
    }

    createMut.mutate(
      { title: title.trim(), description: description.trim(), constraints },
      {
        onSuccess: (data: any) => {
          notifications.show({
            title: "Objectif créé",
            message: `${data.goal_id} — pipeline démarré`,
            color: "green",
          });
          reset();
          onClose();
        },
        onError: (e: any) => {
          notifications.show({ title: "Erreur", message: e.message, color: "red" });
        },
      }
    );
  };

  const roleOptions = (rolesQ.data ?? []).map((r: any) => ({
    value: r.name,
    label: `${r.icon ?? "🐝"} ${r.name} — ${r.description}`,
  }));

  const onRoleChange = (v: string | null) => {
    const roleName = v ?? "";
    setRole(roleName);
    const selected = (rolesQ.data ?? []).find((r: any) => r.name === roleName);
    const dc: any = selected?.default_constraints ?? {};
    if (selected) {
      if (typeof dc.risk_level === "string") setRiskLevel(dc.risk_level);
      if (typeof dc.timeout === "number") setTimeout(dc.timeout);
      if (typeof dc.require_manual_approval === "boolean") setManualApproval(dc.require_manual_approval);
    }
  };

  return (
    <>
      <Modal opened={opened} onClose={onClose} title="Nouvel objectif" size="lg" centered>
        <Stack gap="sm">
          <TextInput
            label="Titre"
            placeholder="Ex: Optimiser le module de scoring"
            value={title}
            onChange={(e: any) => setTitle(e.currentTarget.value)}
            required
          />

          <Textarea
            label="Description"
            placeholder="Décrivez l'objectif en détail..."
            rows={4}
            value={description}
            onChange={(e: any) => setDescription(e.currentTarget.value)}
          />

          {/* ── Fichiers cibles ──────────────────────────────────── */}
          <div>
            <Text size="sm" fw={500} mb={4}>Fichiers cibles</Text>
            <Text size="xs" c="dimmed" mb={8}>
              Sélectionnez les fichiers du workspace sur lesquels Queen doit travailler.
            </Text>

            {targetFiles.length > 0 && (
              <Stack gap={4} mb={8}>
                {targetFiles.map((f: string) => (
                  <Group key={f} gap={6}>
                    <IconFile size={14} color="var(--mantine-color-blue-5)" />
                    <Code style={{ flex: 1, fontSize: 12 }}>{f}</Code>
                    <ActionIcon size="xs" variant="subtle" color="red" onClick={() => removeFile(f)}>
                      <IconTrash size={12} />
                    </ActionIcon>
                  </Group>
                ))}
              </Stack>
            )}

            <Group gap={8}>
              <Button
                size="xs"
                variant="light"
                leftSection={<IconFolder size={14} />}
                onClick={() => setPickerOpen(true)}
              >
                Choisir dans Workspace
              </Button>
              <UploadButton onUploaded={addFile} />
            </Group>
          </div>

          <Divider />

          <Select
            label="Rôle"
            placeholder="Optionnel : pré-configure prompts, outils et defaults"
            data={[{ value: "", label: "— Aucun —" }, ...roleOptions]}
            value={role}
            onChange={onRoleChange}
            searchable
            nothingFoundMessage="Aucun rôle"
          />

          <Group grow>
            <Select
              label="Niveau de risque"
              data={[
                { value: "low", label: "🟢 Low — budget large" },
                { value: "medium", label: "🟡 Medium — défaut" },
                { value: "high", label: "🟠 High — budget restreint" },
                { value: "critical", label: "🔴 Critical — très limité" },
              ]}
              value={riskLevel}
              onChange={(v: any) => v && setRiskLevel(v)}
            />

            <NumberInput
              label="Timeout par job (s)"
              min={30}
              max={1800}
              step={30}
              value={timeout}
              onChange={(v: any) => typeof v === "number" && setTimeout(v)}
            />
          </Group>

          <Textarea
            label="Critères de succès"
            placeholder="Comment savoir que l'objectif est atteint ?"
            rows={2}
            value={successCriteria}
            onChange={(e: any) => setSuccessCriteria(e.currentTarget.value)}
          />

          <Switch
            label="Approbation manuelle requise avant application du patch"
            checked={manualApproval}
            onChange={(e: any) => setManualApproval(e.currentTarget.checked)}
          />

          <Text size="xs" c="dimmed">
            Le pipeline sera lancé automatiquement : planning → jobs → scoring → patch → gates.
          </Text>

          <Group justify="flex-end" mt="sm">
            <Button variant="subtle" onClick={onClose}>Annuler</Button>
            <Button onClick={handleSubmit} loading={createMut.isPending}>
              Créer et lancer
            </Button>
          </Group>
        </Stack>
      </Modal>

      {/* ── Workspace file picker (nested modal) ────────────── */}
      <WorkspacePicker
        opened={pickerOpen}
        onClose={() => setPickerOpen(false)}
        onSelect={(path: string) => { addFile(path); setPickerOpen(false); }}
        alreadySelected={targetFiles}
      />
    </>
  );
}


// ═══════════════════════════════════════════════════════════════════════
// Upload button — uploads to workspace root, returns the path
// ═══════════════════════════════════════════════════════════════════════

function UploadButton({ onUploaded }: { onUploaded: (path: string) => void }) {
  const ref = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const handleFiles = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    try {
      for (const file of Array.from(files)) {
        const result = await workspace.upload(file, "", false);
        onUploaded(result.path);
        notifications.show({
          title: "Fichier uploadé",
          message: `${result.path} (${formatSize(result.size)})`,
          color: "green",
        });
      }
    } catch (e: any) {
      notifications.show({ title: "Upload échoué", message: e.message, color: "red" });
    } finally {
      setUploading(false);
      if (ref.current) ref.current.value = "";
    }
  };

  return (
    <>
      <input ref={ref} type="file" multiple style={{ display: "none" }}
        onChange={(e: any) => handleFiles(e.target.files)} />
      <Button size="xs" variant="light" color="cyan"
        leftSection={<IconUpload size={14} />}
        onClick={() => ref.current?.click()}
        loading={uploading}>
        Uploader un fichier
      </Button>
    </>
  );
}


// ═══════════════════════════════════════════════════════════════════════
// Workspace picker — browse workspace and select a file
// ═══════════════════════════════════════════════════════════════════════

function WorkspacePicker({
  opened, onClose, onSelect, alreadySelected,
}: {
  opened: boolean;
  onClose: () => void;
  onSelect: (path: string) => void;
  alreadySelected: string[];
}) {
  const [currentPath, setCurrentPath] = useState("");
  const [entries, setEntries] = useState<WorkspaceEntry[]>([]);
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const result = await workspace.list(currentPath);
      setEntries(result.entries ?? []);
    } catch {
      setEntries([]);
    } finally {
      setLoading(false);
    }
  }, [currentPath]);

  useEffect(() => {
    if (opened) refresh();
  }, [opened, refresh]);

  const goUp = () => {
    const parts = currentPath.split("/").filter(Boolean);
    parts.pop();
    setCurrentPath(parts.join("/"));
  };

  const navigate = (entry: WorkspaceEntry) => {
    if (entry.type === "dir") {
      setCurrentPath(currentPath ? `${currentPath}/${entry.name}` : entry.name);
    } else {
      const fullPath = currentPath ? `${currentPath}/${entry.name}` : entry.name;
      onSelect(fullPath);
    }
  };

  return (
    <Modal opened={opened} onClose={onClose} title="Choisir un fichier" size="md" centered>
      <Stack gap="sm">
        <Group gap={8}>
          {currentPath && (
            <ActionIcon variant="subtle" onClick={goUp}><IconArrowLeft size={16} /></ActionIcon>
          )}
          <Code style={{ flex: 1 }}>/workspace/{currentPath || ""}</Code>
        </Group>

        {loading ? <Loader size="sm" /> : (
          <Paper p="xs" radius="sm" withBorder style={{ maxHeight: 350, overflow: "auto" }}>
            {entries.length === 0 ? (
              <Text size="sm" c="dimmed" ta="center" py="md">Dossier vide</Text>
            ) : (
              <Stack gap={2}>
                {entries.map((entry: WorkspaceEntry) => {
                  const fullPath = currentPath ? `${currentPath}/${entry.name}` : entry.name;
                  const selected = alreadySelected.includes(fullPath);
                  return (
                    <Group
                      key={entry.name}
                      gap={8}
                      py={4}
                      px={8}
                      style={{
                        cursor: "pointer",
                        borderRadius: 4,
                        backgroundColor: selected ? "var(--mantine-color-blue-0)" : undefined,
                      }}
                      onClick={() => navigate(entry)}
                    >
                      {entry.type === "dir" ? (
                        <IconFolder size={16} color="var(--mantine-color-blue-5)" />
                      ) : (
                        <IconFile size={16} color="var(--mantine-color-gray-5)" />
                      )}
                      <Text size="sm" style={{ flex: 1 }}>{entry.name}</Text>
                      {entry.type === "file" && (
                        <Text size="xs" c="dimmed">{formatSize(entry.size)}</Text>
                      )}
                      {selected && <Badge size="xs" color="blue">sélectionné</Badge>}
                    </Group>
                  );
                })}
              </Stack>
            )}
          </Paper>
        )}

        <Text size="xs" c="dimmed">
          Cliquez sur un fichier pour le sélectionner. Naviguez dans les dossiers.
        </Text>
      </Stack>
    </Modal>
  );
}


function formatSize(bytes: number): string {
  if (bytes === 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(i > 0 ? 1 : 0)} ${units[i]}`;
}
