"""
workspace_routes.py — Workspace file management API for Queen Dashboard.

Core functions (_validate_path, _safe_filename, etc.) are testable without FastAPI.
The router + endpoints use FastAPI but are only created when the module is used in the server.
"""

import logging
import os
import re
import shutil
from typing import Optional
from urllib.parse import urlparse

logger = logging.getLogger("queen.workspace")

WORKSPACE_BASE = os.environ.get("WORKSPACE_BASE", "/workspace")
MAX_UPLOAD_BYTES = 50 * 1024 * 1024  # 50 MB
MAX_URL_DOWNLOAD_BYTES = 50 * 1024 * 1024
URL_TIMEOUT = 30
SAFE_FILENAME_RE = re.compile(r"^[a-zA-Z0-9_\-][a-zA-Z0-9_\-. ]*$")


# ═══════════════════════════════════════════════════════════════════════
# Core logic (no FastAPI dependency)
# ═══════════════════════════════════════════════════════════════════════

class WorkspaceError(Exception):
    """Raised for workspace validation/operation errors."""
    def __init__(self, message: str, status_code: int = 400):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


def _validate_path(path: str) -> str:
    """Validate and resolve a workspace-relative path. Raises WorkspaceError."""
    base = os.path.realpath(WORKSPACE_BASE)
    if not path:
        return base
    target = os.path.realpath(os.path.join(base, path))
    try:
        common = os.path.commonpath([base, target])
        if common != base:
            raise WorkspaceError("Path traversal denied", 403)
    except ValueError:
        raise WorkspaceError("Path traversal denied", 403)
    if ".." in path.split("/") or ".." in path.split(os.sep):
        raise WorkspaceError("Path traversal denied", 403)
    return target


def _safe_filename(name: str) -> str:
    """Sanitize a filename. Raises WorkspaceError for dangerous names."""
    name = os.path.basename(name).strip()
    if not name or name.startswith("."):
        raise WorkspaceError(f"Invalid filename: {name!r}", 400)
    name = re.sub(r"[^\w\-. ]", "_", name)
    if not name:
        raise WorkspaceError("Filename empty after sanitization", 400)
    return name


def list_workspace(path: str = "", offset: int = 0, limit: int = 50) -> dict:
    """List directory or read file. Pure logic, no HTTP."""
    limit = max(1, min(int(limit), 100))
    offset = max(0, int(offset))
    target = _validate_path(path)

    if not os.path.exists(target):
        return {"path": path, "type": "dir", "entries": [], "total": 0}

    if os.path.isfile(target):
        size = os.path.getsize(target)
        content = "[binary]"
        try:
            if size <= 102400:
                with open(target, "r", encoding="utf-8") as f:
                    content = f.read(102400)
        except Exception:
            pass
        return {"path": path, "type": "file", "size": size, "content": content, "full_path": target}

    try:
        all_names = sorted(os.listdir(target))
    except PermissionError:
        raise WorkspaceError("Permission denied", 403)

    paged = all_names[offset:offset + limit]
    entries = []
    for name in paged:
        full = os.path.join(target, name)
        entries.append({
            "name": name,
            "type": "dir" if os.path.isdir(full) else "file",
            "size": os.path.getsize(full) if os.path.isfile(full) else 0,
        })
    return {"path": path, "type": "dir", "entries": entries, "total": len(all_names),
            "offset": offset, "limit": limit, "full_path": target}


def make_directory(path: str) -> dict:
    if not path or not path.strip():
        raise WorkspaceError("Path is required", 400)
    target = _validate_path(path)
    if os.path.exists(target):
        if os.path.isdir(target):
            return {"ok": True, "path": path, "existed": True, "full_path": target}
        raise WorkspaceError(f"A file exists at this path: {path}", 409)
    os.makedirs(target, exist_ok=True)
    logger.info(f"Directory created: {target}")
    return {"ok": True, "path": path, "existed": False, "full_path": target}


def delete_path(path: str) -> dict:
    if not path or not path.strip():
        raise WorkspaceError("Path is required", 400)
    target = _validate_path(path)
    base = os.path.realpath(WORKSPACE_BASE)
    if target == base:
        raise WorkspaceError("Cannot delete workspace root", 403)
    if not os.path.exists(target):
        raise WorkspaceError(f"Not found: {path}", 404)
    if os.path.isfile(target):
        os.remove(target)
    elif os.path.isdir(target):
        shutil.rmtree(target)
    logger.info(f"Deleted: {target}")
    return {"ok": True, "path": path, "deleted": True}


def write_file(content: bytes, target_dir: str, filename: str, overwrite: bool = False) -> dict:
    """Write bytes to workspace. Used by upload + import-url."""
    dir_path = _validate_path(target_dir)
    os.makedirs(dir_path, exist_ok=True)
    filename = _safe_filename(filename)
    dest = os.path.join(dir_path, filename)
    _validate_path(os.path.join(target_dir, filename))
    if os.path.exists(dest) and not overwrite:
        rel = os.path.join(target_dir, filename) if target_dir else filename
        raise WorkspaceError(f"File already exists: {rel}. Set overwrite=true to replace.", 409)
    if len(content) > MAX_UPLOAD_BYTES:
        raise WorkspaceError(f"File too large: {len(content)} bytes (max {MAX_UPLOAD_BYTES})", 413)
    with open(dest, "wb") as f:
        f.write(content)
    rel = os.path.join(target_dir, filename) if target_dir else filename
    logger.info(f"File written: {dest} ({len(content)} bytes)")
    return {"ok": True, "path": rel, "size": len(content), "full_path": dest}


def _check_ssrf(hostname: str) -> None:
    """Block requests to localhost, loopback, and RFC1918 private addresses."""
    import ipaddress
    import socket

    BLOCKED_HOSTS = {"localhost", "localhost.", "127.0.0.1", "::1", "0.0.0.0",
                     "[::1]", "metadata.google.internal", "169.254.169.254"}

    lower = hostname.lower().strip("[]")
    if lower in BLOCKED_HOSTS:
        raise WorkspaceError(f"Blocked host: {hostname}", 403)

    # Resolve hostname and check if it's a private IP
    try:
        infos = socket.getaddrinfo(hostname, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
        for family, _, _, _, sockaddr in infos:
            ip_str = sockaddr[0]
            addr = ipaddress.ip_address(ip_str)
            if addr.is_private or addr.is_loopback or addr.is_reserved or addr.is_link_local:
                raise WorkspaceError(
                    f"URL resolves to private/local address ({ip_str}) — blocked for security", 403
                )
    except WorkspaceError:
        raise
    except Exception:
        pass  # DNS resolution failure is OK — urllib will handle it


def import_url(url: str, target_dir: str = "", filename: Optional[str] = None,
               overwrite: bool = False) -> dict:
    """Download from URL and write to workspace."""
    import ipaddress
    import socket
    import urllib.request
    import urllib.error

    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise WorkspaceError("Only http/https URLs are allowed", 400)
    if not parsed.netloc:
        raise WorkspaceError("Invalid URL", 400)

    # SSRF protection: block local/private hosts
    hostname = parsed.hostname or ""
    _check_ssrf(hostname)

    if filename:
        fname = _safe_filename(filename)
    else:
        url_path = parsed.path.rstrip("/")
        basename = os.path.basename(url_path) if url_path else ""
        fname = _safe_filename(basename if basename else "download")

    try:
        request = urllib.request.Request(url, headers={"User-Agent": "Queen/1.0"})
        with urllib.request.urlopen(request, timeout=URL_TIMEOUT) as resp:
            data = resp.read(MAX_URL_DOWNLOAD_BYTES + 1)
            if len(data) > MAX_URL_DOWNLOAD_BYTES:
                raise WorkspaceError(f"Downloaded file too large (>{MAX_URL_DOWNLOAD_BYTES} bytes)", 413)
    except WorkspaceError:
        raise
    except Exception as e:
        raise WorkspaceError(f"Download failed: {e}", 502)

    result = write_file(data, target_dir, fname, overwrite)
    result["source_url"] = url
    return result


# ═══════════════════════════════════════════════════════════════════════
# FastAPI router (deferred — only constructed when imported by the server)
# ═══════════════════════════════════════════════════════════════════════

def _make_router():
    from fastapi import APIRouter, HTTPException, UploadFile, File, Form, Depends, Query
    from pydantic import BaseModel
    from dashboard.backend.rate_limit import rate_limit_dependency

    rtr = APIRouter(prefix="/api/workspace", tags=["Workspace"])

    def _to_http(fn, *args, **kwargs):
        """Call a core function and convert WorkspaceError to HTTPException."""
        try:
            return fn(*args, **kwargs)
        except WorkspaceError as e:
            raise HTTPException(status_code=e.status_code, detail=e.message)

    @rtr.get("")
    def _list(path: str = "", offset: int = 0, limit: int = 50):
        return _to_http(list_workspace, path, offset, limit)

    @rtr.post("/upload", dependencies=[Depends(rate_limit_dependency(20, 60))])
    async def _upload(file: UploadFile = File(...), target_dir: str = Form(""),
                      overwrite: bool = Form(False)):
        content = await file.read()
        return _to_http(write_file, content, target_dir, file.filename or "upload", overwrite)

    class _ImportReq(BaseModel):
        url: str
        target_dir: str = ""
        filename: Optional[str] = None
        overwrite: bool = False

    @rtr.post("/import-url", dependencies=[Depends(rate_limit_dependency(5, 60))])
    def _import(req: _ImportReq):
        return _to_http(import_url, req.url, req.target_dir, req.filename, req.overwrite)

    class _MkdirReq(BaseModel):
        path: str

    @rtr.post("/mkdir", dependencies=[Depends(rate_limit_dependency(20, 60))])
    def _mkdir(req: _MkdirReq):
        return _to_http(make_directory, req.path)

    @rtr.delete("", dependencies=[Depends(rate_limit_dependency(10, 60))])
    def _delete(path: str = Query(...)):
        return _to_http(delete_path, path)

    return rtr


_router = None

def _get_router():
    global _router
    if _router is None:
        _router = _make_router()
    return _router

# For api.py: `from workspace_routes import router` works via __getattr__
def __getattr__(name):
    if name == "router":
        return _get_router()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
