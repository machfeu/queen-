"""
env_check.py — Environment detection and bootstrap for Queen.

Pure logic, no Tkinter dependency. Testable standalone.
Detects Docker, Ollama, model availability, and can launch services.

All functions return structured dicts with status + details.
"""

import json
import logging
import os
import shutil
import subprocess
import sys
import time
from typing import Any, Dict, Optional
from urllib.request import urlopen, Request
from urllib.error import URLError

logger = logging.getLogger("queen.env_check")

OLLAMA_DEFAULT_URL = "http://localhost:11434"

# Download URLs
DOCKER_DOWNLOAD_URL = "https://www.docker.com/products/docker-desktop/"
OLLAMA_DOWNLOAD_URL = "https://ollama.com/download"

DOCKER_DESKTOP_PATHS_WIN = [
    os.path.expandvars(r"%ProgramFiles%\Docker\Docker\Docker Desktop.exe"),
    os.path.expandvars(r"%LOCALAPPDATA%\Programs\Docker\Docker\Docker Desktop.exe"),
]
OLLAMA_PATHS_WIN = [
    os.path.expandvars(r"%LOCALAPPDATA%\Programs\Ollama\ollama.exe"),
    os.path.expandvars(r"%ProgramFiles%\Ollama\ollama.exe"),
]


# ═══════════════════════════════════════════════════════════════════════
# Docker
# ═══════════════════════════════════════════════════════════════════════

def check_docker_installed() -> Dict[str, Any]:
    """Check if docker CLI is in PATH."""
    path = shutil.which("docker")
    if not path:
        return {"installed": False, "path": None, "version": None}
    try:
        proc = subprocess.run(
            ["docker", "--version"], capture_output=True, text=True, timeout=10
        )
        version = proc.stdout.strip() if proc.returncode == 0 else None
    except Exception:
        version = None
    return {"installed": True, "path": path, "version": version}


def check_docker_running() -> Dict[str, Any]:
    """Check if Docker engine is responding (docker info)."""
    try:
        proc = subprocess.run(
            ["docker", "info", "--format", "{{.ServerVersion}}"],
            capture_output=True, text=True, timeout=15,
        )
        if proc.returncode == 0:
            return {"running": True, "server_version": proc.stdout.strip()}
        return {"running": False, "error": proc.stderr.strip()[:300]}
    except FileNotFoundError:
        return {"running": False, "error": "docker not found"}
    except subprocess.TimeoutExpired:
        return {"running": False, "error": "docker info timed out"}
    except Exception as e:
        return {"running": False, "error": str(e)}


def launch_docker_desktop() -> Dict[str, Any]:
    """Attempt to start Docker Desktop (Windows)."""
    if sys.platform != "win32":
        return {"launched": False, "error": "Docker Desktop launch only supported on Windows"}

    for path in DOCKER_DESKTOP_PATHS_WIN:
        if os.path.isfile(path):
            try:
                subprocess.Popen([path], creationflags=subprocess.DETACHED_PROCESS)
                return {"launched": True, "path": path, "note": "Docker Desktop starting — may take 30-60s"}
            except Exception as e:
                return {"launched": False, "error": f"Failed to start: {e}", "path": path}

    return {"launched": False, "error": "Docker Desktop not found at known paths"}


def find_docker_desktop() -> Optional[str]:
    """Find Docker Desktop executable on Windows."""
    if sys.platform != "win32":
        return None
    for path in DOCKER_DESKTOP_PATHS_WIN:
        if os.path.isfile(path):
            return path
    return None


# ═══════════════════════════════════════════════════════════════════════
# Ollama
# ═══════════════════════════════════════════════════════════════════════

def check_ollama_installed() -> Dict[str, Any]:
    """Check if ollama CLI is available."""
    path = shutil.which("ollama")
    if path:
        return {"installed": True, "path": path}
    # Check known Windows paths
    if sys.platform == "win32":
        for p in OLLAMA_PATHS_WIN:
            if os.path.isfile(p):
                return {"installed": True, "path": p}
    return {"installed": False, "path": None}


def check_ollama_running(base_url: str = OLLAMA_DEFAULT_URL) -> Dict[str, Any]:
    """Check if Ollama API is responding."""
    try:
        req = Request(f"{base_url.rstrip('/')}/api/tags", method="GET")
        with urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            models = [m.get("name", "") for m in data.get("models", [])]
            return {"running": True, "models": models, "model_count": len(models)}
    except URLError as e:
        return {"running": False, "error": str(e.reason)[:200]}
    except Exception as e:
        return {"running": False, "error": str(e)[:200]}


def check_model_available(model_name: str, base_url: str = OLLAMA_DEFAULT_URL) -> Dict[str, Any]:
    """Check if a specific model is available in Ollama."""
    status = check_ollama_running(base_url)
    if not status.get("running"):
        return {"available": False, "ollama_running": False, "error": status.get("error")}

    models = status.get("models", [])
    # Ollama model names can have :tag — match base name
    base_name = model_name.split(":")[0]
    for m in models:
        if m.startswith(base_name):
            return {"available": True, "model": m, "ollama_running": True}

    return {"available": False, "model": model_name, "ollama_running": True,
            "installed_models": models}


def launch_ollama() -> Dict[str, Any]:
    """Attempt to start Ollama serve."""
    info = check_ollama_installed()
    if not info["installed"]:
        return {"launched": False, "error": "Ollama not installed"}

    ollama_path = info["path"]
    try:
        if sys.platform == "win32":
            subprocess.Popen(
                [ollama_path, "serve"],
                creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NO_WINDOW,
            )
        else:
            subprocess.Popen(
                [ollama_path, "serve"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        return {"launched": True, "path": ollama_path,
                "note": "Ollama starting — may take a few seconds"}
    except Exception as e:
        return {"launched": False, "error": str(e)}


def pull_model(model_name: str, base_url: str = OLLAMA_DEFAULT_URL) -> Dict[str, Any]:
    """Start pulling a model (async — returns immediately)."""
    info = check_ollama_installed()
    if not info["installed"]:
        return {"started": False, "error": "Ollama not installed"}

    try:
        proc = subprocess.Popen(
            [info["path"], "pull", model_name],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        )
        return {"started": True, "model": model_name, "pid": proc.pid,
                "note": f"Pulling {model_name} — this may take several minutes"}
    except Exception as e:
        return {"started": False, "error": str(e)}


# ═══════════════════════════════════════════════════════════════════════
# Full environment check
# ═══════════════════════════════════════════════════════════════════════

def full_check(ollama_url: str = OLLAMA_DEFAULT_URL, model_name: str = "") -> Dict[str, Any]:
    """Run all checks and return a structured status."""
    docker_installed = check_docker_installed()
    docker_running = check_docker_running() if docker_installed["installed"] else {"running": False}
    ollama_installed = check_ollama_installed()
    ollama_running = check_ollama_running(ollama_url) if ollama_installed["installed"] else {"running": False}

    model_status = {"available": False, "checked": False}
    if model_name and ollama_running.get("running"):
        model_status = check_model_available(model_name, ollama_url)
        model_status["checked"] = True

    all_ready = (
        docker_running.get("running", False)
        and ollama_running.get("running", False)
        and (model_status.get("available", False) or not model_name)
    )

    # Build guidance messages
    guidance = _build_guidance(docker_installed, docker_running, ollama_installed,
                               ollama_running, model_status, model_name)

    return {
        "docker": {**docker_installed, **docker_running, "desktop_path": find_docker_desktop()},
        "ollama": {**ollama_installed, **ollama_running},
        "model": model_status,
        "model_name": model_name,
        "ready": all_ready,
        "guidance": guidance,
    }


# ═══════════════════════════════════════════════════════════════════════
# Windows WSL check
# ═══════════════════════════════════════════════════════════════════════

def check_wsl_available() -> Dict[str, Any]:
    """Check if WSL is available (required by Docker Desktop on Windows)."""
    if sys.platform != "win32":
        return {"relevant": False}
    try:
        proc = subprocess.run(
            ["wsl", "--status"], capture_output=True, text=True, timeout=10,
        )
        if proc.returncode == 0:
            return {"relevant": True, "available": True, "output": proc.stdout.strip()[:300]}
        return {"relevant": True, "available": False, "error": proc.stderr.strip()[:300]}
    except FileNotFoundError:
        return {"relevant": True, "available": False, "error": "wsl command not found"}
    except Exception as e:
        return {"relevant": True, "available": False, "error": str(e)[:200]}


# ═══════════════════════════════════════════════════════════════════════
# Contextual guidance
# ═══════════════════════════════════════════════════════════════════════

def _build_guidance(docker_inst: dict, docker_run: dict,
                    ollama_inst: dict, ollama_run: dict,
                    model_st: dict, model_name: str) -> list:
    """Build a list of actionable guidance messages based on current state."""
    msgs = []

    if not docker_inst.get("installed"):
        msgs.append({
            "level": "critical",
            "title": "Docker non installé",
            "message": "Docker Desktop est requis pour faire tourner Queen.",
            "action": "install_docker",
            "url": DOCKER_DOWNLOAD_URL,
            "steps": [
                "Téléchargez Docker Desktop depuis docker.com",
                "Lancez l'installateur et suivez les instructions",
                "Sur Windows, WSL2 sera activé automatiquement si nécessaire",
                "Redémarrez si demandé, puis relancez ce vérificateur",
            ],
        })
    elif not docker_run.get("running"):
        error = docker_run.get("error", "")
        if "permission denied" in error.lower() or "denied" in error.lower():
            msgs.append({
                "level": "warning",
                "title": "Docker installé mais accès refusé",
                "message": "Docker est installé mais votre utilisateur n'a pas les droits.",
                "steps": [
                    "Sur Windows : lancez Docker Desktop en tant qu'administrateur",
                    "Sur Linux : ajoutez votre utilisateur au groupe docker (sudo usermod -aG docker $USER)",
                    "Déconnectez-vous et reconnectez-vous après",
                ],
            })
        else:
            msgs.append({
                "level": "warning",
                "title": "Docker installé mais arrêté",
                "message": "Docker Engine ne répond pas. Cliquez 'Lancer Docker Desktop' ou démarrez-le manuellement.",
                "action": "launch_docker",
            })

    if not ollama_inst.get("installed"):
        msgs.append({
            "level": "critical",
            "title": "Ollama non installé",
            "message": "Ollama est requis pour l'inférence LLM locale.",
            "action": "install_ollama",
            "url": OLLAMA_DOWNLOAD_URL,
            "steps": [
                "Téléchargez Ollama depuis ollama.com/download",
                "Lancez l'installateur (pas de droits admin requis)",
                "Ollama s'installe dans votre profil utilisateur",
                "Relancez ce vérificateur après l'installation",
            ],
        })
    elif not ollama_run.get("running"):
        msgs.append({
            "level": "warning",
            "title": "Ollama installé mais arrêté",
            "message": "L'API Ollama ne répond pas. Cliquez 'Lancer Ollama' pour le démarrer.",
            "action": "launch_ollama",
        })

    if ollama_run.get("running") and model_name and not model_st.get("available"):
        msgs.append({
            "level": "info",
            "title": f"Modèle {model_name} absent",
            "message": f"Le modèle {model_name} n'est pas encore téléchargé dans Ollama.",
            "action": "pull_model",
            "steps": [
                f"Cliquez 'Télécharger le modèle' pour lancer le téléchargement",
                f"Ou en ligne de commande : ollama pull {model_name}",
                "Le téléchargement peut prendre plusieurs minutes selon la taille du modèle",
            ],
        })

    if not msgs:
        msgs.append({
            "level": "ok",
            "title": "Environnement prêt",
            "message": "Tous les prérequis sont satisfaits. Vous pouvez démarrer Queen.",
        })

    return msgs
