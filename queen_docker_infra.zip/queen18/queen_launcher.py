"""Queen Launcher — desktop control panel for the local source checkout.

Goals:
- no command line required for normal usage
- edit .env from a small GUI
- start/stop/restart docker compose with optional overlays/profiles
- open the dashboard in a browser

Windows-friendly, but also works on Linux/macOS with Python + Tkinter.
"""

from __future__ import annotations

import os
import queue
import shutil
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path
from typing import Dict, List

import tkinter as tk
from tkinter import messagebox, ttk

from env_check import (
    full_check, check_docker_running, launch_docker_desktop,
    launch_ollama, pull_model, check_ollama_running,
)

PROJECT_ROOT = Path(__file__).resolve().parent
ENV_PATH = PROJECT_ROOT / ".env"
ENV_EXAMPLE_PATH = PROJECT_ROOT / ".env.example"
COMPOSE_FILE = PROJECT_ROOT / "docker-compose.yml"
REDIS_OVERLAY = PROJECT_ROOT / "docker-compose.redis-auth.yml"
DASHBOARD_URL = "http://127.0.0.1:8080"

ENV_ORDER = [
    "QUEEN_API_KEY",
    "REDIS_PASSWORD",
    "LLM_PROVIDER",
    "OLLAMA_BASE_URL",
    "OLLAMA_MODEL",
    "OPENAI_BASE_URL",
    "OPENAI_MODEL",
    "OPENAI_API_KEY",
    "POLICY_JOB_TIMEOUT",
    "POLICY_MAX_JOB_TIMEOUT",
    "POLICY_MAX_OUTPUT_BYTES",
    "POLICY_MAX_JOBS_PER_RUN",
    "POLICY_MAX_CONCURRENT_JOBS",
    "EVOLUTION_ITERS",
    "EVOLUTION_MAX_FILES",
    "EVOLUTION_EXPLORATION",
    "EVOLUTION_INSTRUCTION",
    "EVOLUTION_ALLOWLIST",
    "EVOLUTION_TARGETS",
]

DEFAULTS = {
    "QUEEN_API_KEY": "",
    "REDIS_PASSWORD": "",
    "LLM_PROVIDER": "ollama",
    "OLLAMA_BASE_URL": "http://ollama:11434",
    "OLLAMA_MODEL": "llama3.1:8b",
    "OPENAI_BASE_URL": "https://api.openai.com/v1",
    "OPENAI_MODEL": "gpt-4o-mini",
    "OPENAI_API_KEY": "",
    "POLICY_JOB_TIMEOUT": "300",
    "POLICY_MAX_JOB_TIMEOUT": "1800",
    "POLICY_MAX_OUTPUT_BYTES": "10000000",
    "POLICY_MAX_JOBS_PER_RUN": "20",
    "POLICY_MAX_CONCURRENT_JOBS": "5",
    "EVOLUTION_ITERS": "5",
    "EVOLUTION_MAX_FILES": "2",
    "EVOLUTION_EXPLORATION": "0.15",
    "EVOLUTION_INSTRUCTION": "Improve reliability and bug-resilience without changing external behavior.",
    "EVOLUTION_ALLOWLIST": "queen_core/redis_bus.py,queen_core/orchestrator.py,workers/worker_unified.py",
    "EVOLUTION_TARGETS": "queen_core/redis_bus.py,queen_core/orchestrator.py",
}


class LauncherApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Queen Launcher")
        self.root.geometry("980x760")
        self.root.minsize(900, 700)
        self.log_queue: "queue.Queue[str]" = queue.Queue()
        self.current_process: subprocess.Popen[str] | None = None

        self.env_values = self.load_env()
        self.build_ui()
        self.poll_log_queue()
        self.log("Launcher prêt.")

    def load_env(self) -> Dict[str, str]:
        data = dict(DEFAULTS)
        source = ENV_PATH if ENV_PATH.exists() else ENV_EXAMPLE_PATH
        if source.exists():
            for line in source.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                data[k.strip()] = v.strip()
        return data

    def save_env(self) -> None:
        data = {k: self.vars[k].get().strip() for k in ENV_ORDER}
        content = [
            "# Queen launcher generated .env",
            "# Tu peux encore l'éditer à la main si besoin.",
            "",
        ]
        for key in ENV_ORDER:
            value = data.get(key, "")
            content.append(f"{key}={value}")
        ENV_PATH.write_text("\n".join(content) + "\n", encoding="utf-8")
        self.log(f"Configuration enregistrée dans {ENV_PATH.name}")
        messagebox.showinfo("Queen Launcher", ".env mis à jour.")

    def compose_cmd(self, action: str) -> List[str]:
        cmd = ["docker", "compose", "-f", str(COMPOSE_FILE)]
        if self.vars["REDIS_PASSWORD"].get().strip() and REDIS_OVERLAY.exists():
            cmd += ["-f", str(REDIS_OVERLAY)]
        profiles = []
        if self.profile_ollama.get():
            profiles += ["--profile", "ollama"]
        if self.profile_scale.get():
            profiles += ["--profile", "scale"]
        cmd += profiles
        if action == "up":
            cmd += ["up", "-d", "--build"]
        elif action == "down":
            cmd += ["down"]
        elif action == "restart":
            cmd += ["up", "-d", "--build", "--force-recreate"]
        else:
            raise ValueError(action)
        return cmd

    def run_compose(self, action: str) -> None:
        self.save_env_silent()
        cmd = self.compose_cmd(action)
        self.log("$ " + " ".join(cmd))

        def worker() -> None:
            try:
                proc = subprocess.Popen(
                    cmd,
                    cwd=str(PROJECT_ROOT),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                )
                self.current_process = proc
                assert proc.stdout is not None
                for line in proc.stdout:
                    self.log(line.rstrip())
                code = proc.wait()
                self.log(f"Commande terminée avec code {code}")
            except FileNotFoundError:
                self.log("Docker ou docker compose introuvable. Vérifie Docker Desktop.")
                messagebox.showerror("Queen Launcher", "Docker ou docker compose introuvable.")
            except Exception as e:
                self.log(f"Erreur: {e}")
                messagebox.showerror("Queen Launcher", str(e))
            finally:
                self.current_process = None

        threading.Thread(target=worker, daemon=True).start()

    def save_env_silent(self) -> None:
        data = {k: self.vars[k].get().strip() for k in ENV_ORDER}
        content = ["# Queen launcher generated .env", ""]
        for key in ENV_ORDER:
            content.append(f"{key}={data.get(key, '')}")
        ENV_PATH.write_text("\n".join(content) + "\n", encoding="utf-8")

    def open_dashboard(self) -> None:
        webbrowser.open(DASHBOARD_URL)
        self.log(f"Ouverture du dashboard: {DASHBOARD_URL}")

    def open_project_folder(self) -> None:
        path = str(PROJECT_ROOT)
        if sys.platform.startswith("win"):
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])

    def detect_tools(self) -> None:
        docker = shutil.which("docker")
        python_bin = sys.executable
        lines = [f"Python: {python_bin}", f"Docker: {docker or 'non trouvé'}"]
        if docker:
            try:
                result = subprocess.run(["docker", "--version"], capture_output=True, text=True, timeout=5)
                lines.append(result.stdout.strip() or result.stderr.strip())
            except Exception as e:
                lines.append(f"docker --version a échoué: {e}")
        messagebox.showinfo("Outils détectés", "\n".join(lines))

    def log(self, msg: str) -> None:
        self.log_queue.put(f"[{time.strftime('%H:%M:%S')}] {msg}")

    def poll_log_queue(self) -> None:
        try:
            while True:
                line = self.log_queue.get_nowait()
                self.log_text.configure(state="normal")
                self.log_text.insert("end", line + "\n")
                self.log_text.see("end")
                self.log_text.configure(state="disabled")
        except queue.Empty:
            pass
        self.root.after(250, self.poll_log_queue)

    def build_ui(self) -> None:
        self.vars: Dict[str, tk.StringVar] = {k: tk.StringVar(value=self.env_values.get(k, DEFAULTS.get(k, ""))) for k in ENV_ORDER}
        self.profile_ollama = tk.BooleanVar(value=self.vars["LLM_PROVIDER"].get().strip().lower() == "ollama")
        self.profile_scale = tk.BooleanVar(value=False)

        notebook = ttk.Notebook(self.root)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)

        tab_launch = ttk.Frame(notebook)
        tab_env = ttk.Frame(notebook)
        tab_llm = ttk.Frame(notebook)
        tab_security = ttk.Frame(notebook)
        tab_evo = ttk.Frame(notebook)
        tab_logs = ttk.Frame(notebook)
        notebook.add(tab_env, text="Environnement")
        notebook.add(tab_launch, text="Lancement")
        notebook.add(tab_llm, text="LLM")
        notebook.add(tab_security, text="Sécurité")
        notebook.add(tab_evo, text="Évolution")
        notebook.add(tab_logs, text="Logs")

        self.build_env_tab(tab_env)
        self.build_launch_tab(tab_launch)
        self.build_llm_tab(tab_llm)
        self.build_security_tab(tab_security)
        self.build_evolution_tab(tab_evo)
        self.build_logs_tab(tab_logs)

    def build_env_tab(self, parent: ttk.Frame) -> None:
        frame = ttk.Frame(parent, padding=16)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="État de l'environnement", font=("Segoe UI", 16, "bold")).pack(anchor="w", pady=(0, 12))
        ttk.Label(frame, text="Vérifie que Docker, Ollama et le modèle LLM sont prêts avant de lancer Queen.").pack(anchor="w", pady=(0, 16))

        # Status indicators
        status_frame = ttk.LabelFrame(frame, text="Statut", padding=12)
        status_frame.pack(fill="x", pady=(0, 12))

        self._env_labels = {}
        items = [
            ("docker_installed", "Docker installé"),
            ("docker_running", "Docker Engine"),
            ("ollama_installed", "Ollama installé"),
            ("ollama_running", "Ollama API"),
            ("model_available", "Modèle LLM"),
            ("ready", "Queen prête"),
        ]
        for i, (key, label) in enumerate(items):
            ttk.Label(status_frame, text=label).grid(row=i, column=0, sticky="w", padx=(0, 16), pady=3)
            status_lbl = ttk.Label(status_frame, text="—", foreground="#888")
            status_lbl.grid(row=i, column=1, sticky="w", pady=3)
            self._env_labels[key] = status_lbl

        # Action buttons
        btn_frame = ttk.LabelFrame(frame, text="Actions", padding=12)
        btn_frame.pack(fill="x", pady=(0, 12))

        btns_row1 = ttk.Frame(btn_frame)
        btns_row1.pack(fill="x", pady=(0, 6))
        ttk.Button(btns_row1, text="Vérifier l'environnement", command=self._refresh_env_check).pack(side="left", padx=4)
        self._btn_launch_docker = ttk.Button(btns_row1, text="Lancer Docker Desktop", command=self._launch_docker, state="disabled")
        self._btn_launch_docker.pack(side="left", padx=4)
        self._btn_launch_ollama = ttk.Button(btns_row1, text="Lancer Ollama", command=self._launch_ollama, state="disabled")
        self._btn_launch_ollama.pack(side="left", padx=4)
        self._btn_pull_model = ttk.Button(btns_row1, text="Télécharger le modèle", command=self._pull_model, state="disabled")
        self._btn_pull_model.pack(side="left", padx=4)

        btns_row2 = ttk.Frame(btn_frame)
        btns_row2.pack(fill="x", pady=(6, 0))
        self._btn_start_queen = ttk.Button(btns_row2, text="Démarrer Queen", command=lambda: self.run_compose("up"), state="disabled")
        self._btn_start_queen.pack(side="left", padx=4)

        # Install buttons (lot 2)
        install_frame = ttk.LabelFrame(frame, text="Installation", padding=12)
        install_frame.pack(fill="x", pady=(0, 12))
        install_row = ttk.Frame(install_frame)
        install_row.pack(fill="x")
        self._btn_install_docker = ttk.Button(install_row, text="Installer Docker Desktop", command=self._install_docker, state="disabled")
        self._btn_install_docker.pack(side="left", padx=4)
        self._btn_install_ollama = ttk.Button(install_row, text="Installer Ollama", command=self._install_ollama, state="disabled")
        self._btn_install_ollama.pack(side="left", padx=4)
        ttk.Label(install_row, text="Ouvre la page de téléchargement officielle", foreground="#555").pack(side="left", padx=8)

        # Guidance panel (lot 2)
        self._guidance_frame = ttk.LabelFrame(frame, text="Guide", padding=12)
        self._guidance_frame.pack(fill="x", pady=(0, 8))
        self._guidance_label = ttk.Label(self._guidance_frame, text="Vérification en cours...", wraplength=700, justify="left")
        self._guidance_label.pack(fill="x")

        # Detail text
        self._env_detail = tk.Text(frame, wrap="word", state="disabled", height=6, font=("Consolas", 9))
        self._env_detail.pack(fill="both", expand=True, pady=(8, 0))

        # Auto-check on startup
        self.root.after(500, self._refresh_env_check)

    def _set_status(self, key: str, ok: bool, text: str) -> None:
        lbl = self._env_labels.get(key)
        if lbl:
            lbl.configure(text=text, foreground="#2d7d46" if ok else "#c0392b")

    def _env_detail_set(self, text: str) -> None:
        self._env_detail.configure(state="normal")
        self._env_detail.delete("1.0", "end")
        self._env_detail.insert("1.0", text)
        self._env_detail.configure(state="disabled")

    def _refresh_env_check(self) -> None:
        """Run full environment check in background thread."""
        for lbl in self._env_labels.values():
            lbl.configure(text="vérification...", foreground="#888")
        self._env_detail_set("Vérification en cours...")

        def worker():
            model_name = self.vars.get("OLLAMA_MODEL", tk.StringVar()).get() or "qwen2.5-coder:7b"
            ollama_url = self.vars.get("OLLAMA_BASE_URL", tk.StringVar()).get() or "http://localhost:11434"
            # For local check, use localhost even if .env says "ollama" (Docker internal name)
            if "ollama:" in ollama_url:
                ollama_url = ollama_url.replace("ollama:", "localhost:")
            result = full_check(ollama_url=ollama_url, model_name=model_name)
            self.root.after(0, lambda: self._apply_env_result(result))

        threading.Thread(target=worker, daemon=True).start()

    def _apply_env_result(self, result: dict) -> None:
        d = result.get("docker", {})
        o = result.get("ollama", {})
        m = result.get("model", {})

        self._set_status("docker_installed", d.get("installed", False),
                         d.get("version", "installé") if d.get("installed") else "non trouvé")
        self._set_status("docker_running", d.get("running", False),
                         f"actif (v{d.get('server_version', '?')})" if d.get("running") else
                         "arrêté" if d.get("installed") else "—")
        self._set_status("ollama_installed", o.get("installed", False),
                         "installé" if o.get("installed") else "non trouvé")
        self._set_status("ollama_running", o.get("running", False),
                         f"actif ({o.get('model_count', 0)} modèles)" if o.get("running") else
                         "arrêté" if o.get("installed") else "—")
        self._set_status("model_available", m.get("available", False),
                         m.get("model", result.get("model_name", "")) if m.get("available") else
                         f"absent: {result.get('model_name', '?')}" if m.get("checked") else "—")

        ready = result.get("ready", False)
        self._set_status("ready", ready, "prête à démarrer" if ready else "prérequis manquants")

        # Enable/disable buttons based on state
        self._btn_launch_docker.configure(
            state="normal" if (d.get("installed") and not d.get("running") and d.get("desktop_path")) else "disabled"
        )
        self._btn_launch_ollama.configure(
            state="normal" if (o.get("installed") and not o.get("running")) else "disabled"
        )
        self._btn_pull_model.configure(
            state="normal" if (o.get("running") and not m.get("available") and result.get("model_name")) else "disabled"
        )
        self._btn_start_queen.configure(state="normal" if ready else "disabled")

        # Install buttons — enabled only if the tool is NOT installed
        self._btn_install_docker.configure(
            state="normal" if not d.get("installed") else "disabled"
        )
        self._btn_install_ollama.configure(
            state="normal" if not o.get("installed") else "disabled"
        )

        # Guidance panel
        guidance = result.get("guidance", [])
        self._display_guidance(guidance)

        # Detail text
        import json
        self._env_detail_set(json.dumps(result, indent=2, default=str))

    def _display_guidance(self, guidance: list) -> None:
        """Show contextual guidance messages in the guidance panel."""
        if not guidance:
            self._guidance_label.configure(text="Aucun problème détecté.", foreground="#2d7d46")
            return

        lines = []
        for g in guidance:
            level = g.get("level", "info")
            icon = {"critical": "⛔", "warning": "⚠️", "info": "ℹ️", "ok": "✅"}.get(level, "•")
            lines.append(f"{icon} {g.get('title', '')}")
            if g.get("message"):
                lines.append(f"   {g['message']}")
            for step in g.get("steps", []):
                lines.append(f"   → {step}")
            lines.append("")

        color = "#c0392b" if any(g.get("level") == "critical" for g in guidance) else \
                "#e67e22" if any(g.get("level") == "warning" for g in guidance) else "#2d7d46"
        self._guidance_label.configure(text="\n".join(lines).strip(), foreground=color)

    def _install_docker(self) -> None:
        """Open Docker Desktop download page."""
        from env_check import DOCKER_DOWNLOAD_URL
        self.log(f"Ouverture de {DOCKER_DOWNLOAD_URL}")
        webbrowser.open(DOCKER_DOWNLOAD_URL)
        messagebox.showinfo(
            "Installer Docker Desktop",
            "La page de téléchargement Docker Desktop s'ouvre dans votre navigateur.\n\n"
            "Après l'installation :\n"
            "1. Lancez Docker Desktop\n"
            "2. Attendez que Docker soit prêt (icône dans la barre des tâches)\n"
            "3. Cliquez 'Vérifier l'environnement' ici\n\n"
            "Note : sur Windows, WSL2 sera activé automatiquement si nécessaire.\n"
            "Un redémarrage peut être requis."
        )

    def _install_ollama(self) -> None:
        """Open Ollama download page."""
        from env_check import OLLAMA_DOWNLOAD_URL
        self.log(f"Ouverture de {OLLAMA_DOWNLOAD_URL}")
        webbrowser.open(OLLAMA_DOWNLOAD_URL)
        messagebox.showinfo(
            "Installer Ollama",
            "La page de téléchargement Ollama s'ouvre dans votre navigateur.\n\n"
            "Après l'installation :\n"
            "1. Ollama s'installe dans votre profil (pas de droits admin)\n"
            "2. Cliquez 'Lancer Ollama' ici\n"
            "3. Puis 'Télécharger le modèle' pour obtenir le LLM requis"
        )

    def _launch_docker(self) -> None:
        self.log("Lancement de Docker Desktop...")
        result = launch_docker_desktop()
        if result.get("launched"):
            self.log(f"Docker Desktop lancé: {result.get('note', '')}")
            messagebox.showinfo("Docker", result.get("note", "Docker Desktop démarré"))
            # Re-check after delay
            self.root.after(15000, self._refresh_env_check)
        else:
            self.log(f"Échec: {result.get('error', '')}")
            messagebox.showerror("Docker", result.get("error", "Échec du lancement"))

    def _launch_ollama(self) -> None:
        self.log("Lancement d'Ollama...")
        result = launch_ollama()
        if result.get("launched"):
            self.log(f"Ollama lancé: {result.get('note', '')}")
            self.root.after(5000, self._refresh_env_check)
        else:
            self.log(f"Échec: {result.get('error', '')}")
            messagebox.showerror("Ollama", result.get("error", "Échec du lancement"))

    def _pull_model(self) -> None:
        model_name = self.vars.get("OLLAMA_MODEL", tk.StringVar()).get() or "qwen2.5-coder:7b"
        self.log(f"Téléchargement du modèle {model_name}...")
        result = pull_model(model_name)
        if result.get("started"):
            self.log(f"{result.get('note', '')}")
            messagebox.showinfo("Modèle", f"Téléchargement de {model_name} en cours.\n"
                                f"Cela peut prendre plusieurs minutes.\n"
                                f"Re-vérifiez l'environnement après.")
        else:
            self.log(f"Échec: {result.get('error', '')}")
            messagebox.showerror("Modèle", result.get("error", "Échec"))

    def build_launch_tab(self, parent: ttk.Frame) -> None:
        frame = ttk.Frame(parent, padding=16)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="Lancer Queen sans ligne de commande", font=("Segoe UI", 16, "bold")).pack(anchor="w", pady=(0, 12))
        ttk.Label(frame, text="1) Enregistre la configuration. 2) Lance Docker. 3) Ouvre le dashboard.").pack(anchor="w", pady=(0, 12))

        box = ttk.LabelFrame(frame, text="Profils et actions", padding=12)
        box.pack(fill="x", pady=(0, 12))
        ttk.Checkbutton(box, text="Activer le profil Ollama", variable=self.profile_ollama).grid(row=0, column=0, sticky="w", padx=4, pady=4)
        ttk.Checkbutton(box, text="Activer un second worker (profil scale)", variable=self.profile_scale).grid(row=0, column=1, sticky="w", padx=4, pady=4)

        btns = ttk.Frame(box)
        btns.grid(row=1, column=0, columnspan=2, sticky="w", pady=(12, 4))
        ttk.Button(btns, text="Enregistrer .env", command=self.save_env).pack(side="left", padx=4)
        ttk.Button(btns, text="Démarrer / mettre à jour", command=lambda: self.run_compose("up")).pack(side="left", padx=4)
        ttk.Button(btns, text="Redémarrer", command=lambda: self.run_compose("restart")).pack(side="left", padx=4)
        ttk.Button(btns, text="Arrêter", command=lambda: self.run_compose("down")).pack(side="left", padx=4)
        ttk.Button(btns, text="Ouvrir dashboard", command=self.open_dashboard).pack(side="left", padx=4)
        ttk.Button(btns, text="Ouvrir dossier source", command=self.open_project_folder).pack(side="left", padx=4)
        ttk.Button(btns, text="Vérifier Docker", command=self.detect_tools).pack(side="left", padx=4)

        help_box = ttk.LabelFrame(frame, text="Conseils", padding=12)
        help_box.pack(fill="x", pady=(0, 12))
        ttk.Label(help_box, text="• Si tu utilises OpenAI, remplis OPENAI_API_KEY puis mets LLM_PROVIDER=openai.").pack(anchor="w")
        ttk.Label(help_box, text="• Si REDIS_PASSWORD est renseigné, le lanceur active automatiquement l’overlay Redis AUTH.").pack(anchor="w")
        ttk.Label(help_box, text="• Le dashboard s’ouvre sur http://127.0.0.1:8080 .").pack(anchor="w")

    def build_llm_tab(self, parent: ttk.Frame) -> None:
        frame = ttk.Frame(parent, padding=16)
        frame.pack(fill="both", expand=True)
        self.add_entry(frame, 0, "Provider", "LLM_PROVIDER")
        self.add_entry(frame, 1, "Ollama URL", "OLLAMA_BASE_URL")
        self.add_entry(frame, 2, "Ollama Model", "OLLAMA_MODEL")
        self.add_entry(frame, 3, "OpenAI URL", "OPENAI_BASE_URL")
        self.add_entry(frame, 4, "OpenAI Model", "OPENAI_MODEL")
        self.add_entry(frame, 5, "OpenAI API Key", "OPENAI_API_KEY", show="*")
        policy = ttk.LabelFrame(frame, text="Politique", padding=12)
        policy.grid(row=6, column=0, columnspan=2, sticky="ew", pady=16)
        self.add_entry(policy, 0, "Timeout job", "POLICY_JOB_TIMEOUT")
        self.add_entry(policy, 1, "Timeout max", "POLICY_MAX_JOB_TIMEOUT")
        self.add_entry(policy, 2, "Output max bytes", "POLICY_MAX_OUTPUT_BYTES")
        self.add_entry(policy, 3, "Jobs max / run", "POLICY_MAX_JOBS_PER_RUN")
        self.add_entry(policy, 4, "Jobs concurrents", "POLICY_MAX_CONCURRENT_JOBS")

    def build_security_tab(self, parent: ttk.Frame) -> None:
        frame = ttk.Frame(parent, padding=16)
        frame.pack(fill="both", expand=True)
        self.add_entry(frame, 0, "Dashboard API Key", "QUEEN_API_KEY", show="*")
        self.add_entry(frame, 1, "Redis password", "REDIS_PASSWORD", show="*")
        ttk.Label(frame, text="Laisse vide pour un mode local ouvert. Remplis-les pour durcir l’accès.", foreground="#555").grid(row=2, column=0, columnspan=2, sticky="w", pady=(8, 0))

    def build_evolution_tab(self, parent: ttk.Frame) -> None:
        frame = ttk.Frame(parent, padding=16)
        frame.pack(fill="both", expand=True)
        self.add_entry(frame, 0, "Iterations", "EVOLUTION_ITERS")
        self.add_entry(frame, 1, "Max files", "EVOLUTION_MAX_FILES")
        self.add_entry(frame, 2, "Exploration", "EVOLUTION_EXPLORATION")
        self.add_text(frame, 3, "Instruction", "EVOLUTION_INSTRUCTION", height=4)
        self.add_text(frame, 4, "Allowlist CSV", "EVOLUTION_ALLOWLIST", height=4)
        self.add_text(frame, 5, "Targets CSV", "EVOLUTION_TARGETS", height=4)
        ttk.Label(frame, text="Ensuite lance l’évolution depuis l’onglet Evolution du dashboard.", foreground="#555").grid(row=6, column=0, columnspan=2, sticky="w", pady=(8, 0))

    def build_logs_tab(self, parent: ttk.Frame) -> None:
        frame = ttk.Frame(parent, padding=16)
        frame.pack(fill="both", expand=True)
        self.log_text = tk.Text(frame, wrap="word", state="disabled", height=30)
        self.log_text.pack(fill="both", expand=True)

    def add_entry(self, parent: ttk.Widget, row: int, label: str, key: str, show: str | None = None) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=6, padx=(0, 12))
        entry = ttk.Entry(parent, textvariable=self.vars[key], width=70, show=show)
        entry.grid(row=row, column=1, sticky="ew", pady=6)
        try:
            parent.grid_columnconfigure(1, weight=1)
        except Exception:
            pass

    def add_text(self, parent: ttk.Widget, row: int, label: str, key: str, height: int = 3) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="nw", pady=6, padx=(0, 12))
        widget = tk.Text(parent, height=height, width=70)
        widget.insert("1.0", self.vars[key].get())
        widget.grid(row=row, column=1, sticky="ew", pady=6)

        def sync_var(event=None) -> None:
            self.vars[key].set(widget.get("1.0", "end").strip())

        widget.bind("<KeyRelease>", sync_var)
        try:
            parent.grid_columnconfigure(1, weight=1)
        except Exception:
            pass


def main() -> None:
    root = tk.Tk()
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass
    app = LauncherApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
