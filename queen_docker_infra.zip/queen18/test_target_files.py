"""
test_target_files.py — Tests that target_files flows through the pipeline.

Run: python3 test_target_files.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from queen_core.planner import _fallback_plan
from queen_core.prompt_builder import build_prompt


def test_fallback_plan_includes_target_files():
    """target_files from constraints should appear in fallback plan jobs."""
    goal = {
        "title": "Fix scoring",
        "description": "Optimize the scoring module",
        "constraints": {
            "target_files": ["queen_core/evaluator.py", "queen_core/consensus.py"],
        },
    }
    plan = _fallback_plan(goal)
    jobs = plan["jobs"]

    # Research + codegen + test jobs should have target_files
    for job in jobs:
        if job["job_type"] in ("research", "codegen", "test"):
            assert "target_files" in job, f"Job step {job['step']} missing target_files"
            assert job["target_files"] == ["queen_core/evaluator.py", "queen_core/consensus.py"]
            assert "evaluator.py" in job["description"]

    print("PASS: test_fallback_plan_includes_target_files")


def test_fallback_plan_without_target_files():
    """Plan should work fine without target_files."""
    goal = {"title": "General task", "description": "Do something", "constraints": {}}
    plan = _fallback_plan(goal)
    jobs = plan["jobs"]
    assert len(jobs) >= 5
    # No target_files in research job
    research = jobs[0]
    assert research.get("target_files", []) == []
    assert "Fichiers cibles" not in research["description"]
    print("PASS: test_fallback_plan_without_target_files")


def test_prompt_builder_includes_target_files():
    """build_prompt should include target_files section in the user prompt."""
    job = {
        "job_type": "codegen",
        "payload": {
            "goal_title": "Fix scoring",
            "goal_description": "Optimize",
            "description": "Generate code changes",
            "target_files": ["queen_core/evaluator.py", "queen_core/consensus.py"],
            "success_criteria": "tests pass",
        },
    }
    system, user = build_prompt(job)

    assert "Fichiers cibles" in user, f"target_files section missing from prompt"
    assert "queen_core/evaluator.py" in user
    assert "queen_core/consensus.py" in user
    assert "Concentre ton travail" in user
    print("PASS: test_prompt_builder_includes_target_files")


def test_prompt_builder_without_target_files():
    """build_prompt should not add target_files section when empty."""
    job = {
        "job_type": "codegen",
        "payload": {
            "goal_title": "General",
            "goal_description": "Do stuff",
            "description": "Generate code",
            "success_criteria": "",
        },
    }
    system, user = build_prompt(job)
    assert "Fichiers cibles" not in user
    print("PASS: test_prompt_builder_without_target_files")


def test_target_files_in_research_prompt():
    """Research jobs should also get target_files in prompt."""
    job = {
        "job_type": "research",
        "payload": {
            "goal_title": "Analyze module",
            "goal_description": "Analyze the scoring module",
            "description": "Research the codebase",
            "target_files": ["src/scoring.py"],
            "existing_files": [],
            "success_criteria": "",
        },
    }
    system, user = build_prompt(job)
    assert "src/scoring.py" in user
    print("PASS: test_target_files_in_research_prompt")


# ── Runner ───────────────────────────────────────────────────────

if __name__ == "__main__":
    tests = [
        test_fallback_plan_includes_target_files,
        test_fallback_plan_without_target_files,
        test_prompt_builder_includes_target_files,
        test_prompt_builder_without_target_files,
        test_target_files_in_research_prompt,
    ]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"FAIL: {t.__name__} — {e}")
            import traceback; traceback.print_exc()
            failed += 1
    print(f"\n{'='*50}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    if failed:
        sys.exit(1)
    print("ALL TESTS PASSED")
