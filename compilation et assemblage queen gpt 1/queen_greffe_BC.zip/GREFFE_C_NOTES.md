# GREFFE C — Notes d'intégration

## Objet
Amorcer le lot 8A avec une primitive locale de sandboxing, sans brancher une sandbox externe lourde.

## Modules ajoutés
- `queen_core/runtime/sandbox_runner.py`

## Intégrations
- smoke import sandboxé dans `workers/worker_unified.py`
- rapport structuré `sandbox_smoke` dans les résultats de tests

## Limite honnête
Cette greffe ne remplace pas Arrakis/E2B. Elle prépare simplement le tronc à une future sandbox plus sérieuse.

## Tests
- inclus dans `test_guardrails_minimal.py`
- vérifie surtout le stripping des variables sensibles

## Rollback simple
1. retirer `queen_core/runtime/sandbox_runner.py`
2. retirer l'appel `run_python_snippet_sandboxed()` dans `worker_unified.py`
