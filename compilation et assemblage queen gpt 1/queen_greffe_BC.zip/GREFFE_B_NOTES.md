# GREFFE B — Notes d'intégration

## Objet
Ajouter une couche minimale de durcissement inspirée du lot 7 sans remplacer le cœur de Queen.

## Modules ajoutés
- `queen_core/guardrails/policy_engine.py`
- `queen_core/evals/scenario_runner.py`
- `queen_core/redteam/prompt_eval.py`

## Intégrations
- précheck des jobs planifiés dans `queen_core/orchestrator.py`
- gates enrichies avec `guardrails` et `redteam_minimal`
- blocage précoce possible avec statut `rails_blocked`
- contrôle des résultats de codegen dans `workers/worker_unified.py`
- pénalité d'évaluation en cas de findings guardrails dans `queen_core/evaluator.py`

## Tests
- `pytest -q test_mission_contract.py test_version_1b.py test_guardrails_minimal.py`
- Résultat: 18 tests passés

## Rollback simple
1. retirer `queen_core/guardrails`, `queen_core/evals`, `queen_core/redteam`
2. retirer les imports/appels associés dans `orchestrator.py`, `worker_unified.py`, `evaluator.py`
3. retirer `RunStatus.RAILS_BLOCKED` si souhaité
