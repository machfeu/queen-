# Greffe C — Lot 8A minimal

## Objet
Commencer le sandboxing sans brancher tout de suite une sandbox externe lourde.

## Plug inclus
- C1 `queen_core/runtime/sandbox_runner.py`
- C2 smoke import sandboxé dans `worker_unified.py`

## Limite honnête
Ce n'est pas Arrakis ni E2B. C'est une brique locale, utile pour fiabiliser le tronc avant une vraie sandbox externe.
