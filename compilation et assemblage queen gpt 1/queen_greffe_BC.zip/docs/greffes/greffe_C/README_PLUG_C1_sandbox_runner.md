# Plug C1 — Sandbox runner local

## Version antérieure
Queen disposait de sandboxs spécifiques aux benchmarks d'évolution, mais pas d'une primitive réutilisable côté runtime général.

## Amélioration
Ajout d'un exécuteur Python subprocess court, env épuré, timeout borné.

## Bugs rencontrés
- besoin d'un minimum utile sans dépendances externes

## Fixes appliqués
- stripping des variables sensibles
- exécution temporaire isolée
- rapport structuré `passed/stdout/stderr/timeout`
