# Greffe B — Lot 7 minimal

## Objet
Ajouter une première couche explicite de guardrails, d'évaluation offensive minimale et de durcissement des gates.

## Plugs inclus
- B1 `queen_core/guardrails/policy_engine.py`
- B2 `queen_core/evals/scenario_runner.py`
- B3 intégration orchestrator / gates
- B4 intégration worker codegen
- B5 pénalité evaluator en cas de findings

## Validation
- compilation Python
- tests `test_mission_contract.py`, `test_version_1b.py`, `test_guardrails_minimal.py`

## Rollback
Supprimer les packages `queen_core/guardrails`, `queen_core/evals`, `queen_core/redteam`, retirer les appels dans orchestrator / workers / evaluator.
