# Plug B3 — Intégration orchestrator

## Version antérieure
Le run partait au dispatch sans précheck de rails. Les gates finales n'avaient ni scan guardrail explicite ni scan offensif minimal.

## Amélioration
- précheck du plan avant dispatch
- nouveau statut `rails_blocked`
- gates enrichies avec `guardrails` et `redteam_minimal`

## Bugs rencontrés
- ne pas casser le flux Run / Patch existant

## Fixes appliqués
- blocage avant création des jobs si nécessaire
- enrichissement local des gates sans remplacer le pipeline
