# Plug B1 — GuardrailPolicyEngine

## Version antérieure
Aucune couche de rails explicite avant dispatch ni contrôle structuré des résultats de jobs.

## Amélioration
Ajout d'un moteur de rails minimal qui contrôle les requêtes, les résultats et les artefacts.

## Bugs rencontrés
- besoin de rester compatible avec le cœur existant sans modifier la DB
- nécessité de distinguer warning et blocage

## Fixes appliqués
- moteur séparé, branché comme adaptateur
- rapports structurés `passed / blocking_reasons / warnings`
