# Plug B2 — Scenario runner minimal

## Version antérieure
Aucune campagne offensive déclarative dans les gates.

## Amélioration
Ajout d'un runner minimal inspiré de promptfoo pour détecter injections, exfiltration et commandes dropper.

## Bugs rencontrés
- besoin d'une version frugale, sans dépendances externes

## Fixes appliqués
- catalogue court de scénarios critiques
- interface simple `evaluate_text / evaluate_artifacts`
