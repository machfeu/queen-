"""
job_chain.py — Chaînage des résultats entre jobs d'un même run.
Inspiré d'OpenManus : l'output d'une étape devient l'input de la suivante.

Greffe A:
- privilégie les handoffs explicites via depends_on
- injecte un contexte contractuel clair dans chaque job
"""

import json
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger("queen.job_chain")

MAX_CONTEXT_CHARS = 4000  # ~1000 tokens


def _safe_payload(job: Dict[str, Any]) -> Dict[str, Any]:
    payload = job.get("payload", {})
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except Exception:
            payload = {}
    return payload if isinstance(payload, dict) else {}


def collect_previous_results(
    memory,
    run_id: str,
    current_step: int,
    depends_on_steps: Optional[List[int]] = None,
) -> str:
    """Collect results from previous jobs, preferring explicit dependencies."""
    jobs = memory.list_jobs(run_id=run_id)
    if not jobs:
        return ""

    dependency_set = set()
    for s in depends_on_steps or []:
        try:
            val = int(s)
        except Exception:
            continue
        if val > 0:
            dependency_set.add(val)

    previous = []
    for j in jobs:
        payload = _safe_payload(j)
        try:
            job_step = int(payload.get("step", 0) or 0)
        except Exception:
            job_step = 0
        if job_step >= current_step:
            continue
        if j.get("status") != "success":
            continue
        if dependency_set and job_step not in dependency_set:
            continue

        result = j.get("result", {})
        if isinstance(result, str):
            try:
                result = json.loads(result)
            except Exception:
                result = {"raw": result}

        previous.append(
            {
                "step": job_step,
                "type": j.get("job_type", "unknown"),
                "title": payload.get("title", ""),
                "result": result,
            }
        )

    if not previous and dependency_set:
        return collect_previous_results(memory, run_id, current_step, depends_on_steps=[])
    if not previous:
        return ""

    previous.sort(key=lambda x: x["step"])
    parts = ["=== Résultats des étapes précédentes ===\n"]
    if dependency_set:
        parts.append(f"Handoffs attendus depuis les étapes: {sorted(dependency_set)}\n")
    for p in previous:
        result_text = _format_result(p["result"])
        parts.append(
            f"--- Étape {p['step']} ({p['type']}): {p['title']} ---\n"
            f"{result_text}\n"
        )
    context = "\n".join(parts)
    if len(context) > MAX_CONTEXT_CHARS:
        context = _truncate_context(previous)
    return context


def _format_result(result: Any) -> str:
    if isinstance(result, str):
        return result
    if isinstance(result, dict):
        useful_keys = [
            "summary",
            "analysis",
            "findings",
            "artifacts",
            "recommendations",
            "results",
            "score",
            "verdict",
        ]
        extracted = {k: result[k] for k in useful_keys if k in result}
        if extracted:
            return json.dumps(extracted, indent=2, ensure_ascii=False, default=str)
        full = json.dumps(result, indent=2, ensure_ascii=False, default=str)
        return full[:2000] + ("\n... [tronqué]" if len(full) > 2000 else "")
    return str(result)[:1000]


def _truncate_context(previous: List[Dict[str, Any]]) -> str:
    parts = ["=== Résumé des étapes précédentes (compressé) ===\n"]
    for p in previous:
        result = p["result"]
        summary = ""
        if isinstance(result, dict):
            summary = result.get("summary", "")
            artifacts = result.get("artifacts", [])
            if isinstance(artifacts, list):
                art_paths = [a.get("path", "?") for a in artifacts if isinstance(a, dict)]
                if art_paths:
                    summary += f" | Fichiers: {', '.join(art_paths[:10])}"
        if not summary:
            summary = str(result)[:200] + "..."
        parts.append(f"Étape {p['step']} ({p['type']}): {summary}")
    return "\n".join(parts)


def enrich_job_payload(memory, job: Dict[str, Any]) -> Dict[str, Any]:
    payload = _safe_payload(job)
    run_id = job.get("run_id", "")
    try:
        step = int(payload.get("step", 0) or 0)
    except Exception:
        step = 0
    depends_on_steps = payload.get("depends_on", [])
    if run_id and step > 1:
        context = collect_previous_results(memory, run_id, step, depends_on_steps=depends_on_steps)
        if context:
            payload["previous_context"] = context
            payload["handoff_context"] = {
                "depends_on_steps": depends_on_steps,
                "mode": "explicit_dependencies" if depends_on_steps else "all_previous",
            }
            logger.info("Injected %s chars context into job step %s", len(context), step)
    job["payload"] = payload
    return job
