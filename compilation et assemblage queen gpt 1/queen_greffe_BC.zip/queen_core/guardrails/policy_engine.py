"""
policy_engine.py — Greffe B / Lot 7 minimal.

This module adds a pragmatic guardrail layer without replacing Queen's core
policy engine. It is deliberately small:
- validate job requests before dispatch
- validate job results before patch/gates
- inspect artifacts for secrets, prompt injections and blocked code patterns
"""

from __future__ import annotations

from typing import Any, Dict, List

from queen_core.mission_contract import OUTPUTS_BY_JOB_TYPE
from queen_core.policy import (
    check_code_safety,
    check_text_guardrails,
    summarize_guardrail_findings,
    validate_file_path,
)


class GuardrailPolicyEngine:
    """Small policy adapter inspired by Lot 7 bricks.

    The goal is not to emulate NeMo Guardrails or promptfoo fully.
    It gives Queen a first explicit rail layer that can be extended later.
    """

    version = "greffe-b-1"

    def evaluate_job_request(self, job_type: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        findings: List[str] = []
        inspected_fields = (
            "title",
            "description",
            "goal_title",
            "goal_description",
            "previous_context",
            "success_criteria",
        )

        for field in inspected_fields:
            value = payload.get(field, "")
            if isinstance(value, str) and value.strip():
                ok, violations = check_text_guardrails(value, context=f"{job_type}:{field}")
                if not ok:
                    findings.extend(violations)

        passed = len(findings) == 0
        return {
            "passed": passed,
            "mode": "request",
            "job_type": job_type,
            "summary": summarize_guardrail_findings(findings),
            "blocking_reasons": findings if not passed else [],
        }

    def evaluate_job_result(self, job_type: str, result: Dict[str, Any], workspace_root: str = "") -> Dict[str, Any]:
        findings: List[str] = []
        warnings: List[str] = []
        result = result or {}

        required_outputs = OUTPUTS_BY_JOB_TYPE.get(job_type, [])
        if job_type == "codegen":
            # codegen must produce artifacts or clearly explain why it produced none
            if not isinstance(result.get("artifacts", []), list):
                findings.append("codegen result must expose an artifacts list")
        elif job_type == "test":
            if "all_passed" not in result:
                warnings.append("test result missing all_passed flag")
        elif job_type == "eval":
            for key in ("score", "verdict"):
                if key not in result:
                    findings.append(f"eval result missing required field: {key}")
        elif job_type == "research":
            if not any(key in result for key in ("summary", "analysis", "findings")):
                warnings.append("research result is thin: no summary/analysis/findings field")

        summary = result.get("summary", "")
        if isinstance(summary, str) and summary:
            ok, violations = check_text_guardrails(summary, context=f"{job_type}:summary")
            if not ok:
                findings.extend(violations)

        artifact_report = self.evaluate_artifacts(result.get("artifacts", []), workspace_root=workspace_root)
        if not artifact_report.get("passed", True):
            findings.extend(artifact_report.get("blocking_reasons", []))

        missing_optional = [key for key in required_outputs if key not in result]
        if missing_optional and job_type not in {"codegen", "research"}:
            warnings.append(f"missing declared contract keys: {missing_optional}")

        passed = len(findings) == 0
        return {
            "passed": passed,
            "mode": "result",
            "job_type": job_type,
            "warnings": warnings,
            "blocking_reasons": findings,
            "artifact_report": artifact_report,
            "summary": summarize_guardrail_findings(findings + warnings),
        }

    def evaluate_artifacts(self, artifacts: List[Dict[str, Any]], workspace_root: str = "") -> Dict[str, Any]:
        findings: List[str] = []
        inspected: List[Dict[str, Any]] = []

        for art in artifacts or []:
            if not isinstance(art, dict):
                findings.append("artifact entry must be a dict")
                continue

            path = (art.get("path", "") or "").strip()
            content = art.get("content", "") or ""
            art_findings: List[str] = []

            if path and workspace_root:
                ok, reason = validate_file_path(f"{workspace_root.rstrip('/')}/{path.lstrip('/')}" )
                if not ok:
                    art_findings.append(reason)

            if isinstance(content, str) and content:
                ok_text, text_violations = check_text_guardrails(content, context=f"artifact:{path or '?'}")
                if not ok_text:
                    art_findings.extend(text_violations)
                ok_code, code_violations = check_code_safety(content)
                if not ok_code:
                    art_findings.extend(code_violations)

            inspected.append({"path": path, "passed": len(art_findings) == 0, "findings": art_findings})
            findings.extend([f"{path or '?'}: {item}" for item in art_findings])

        return {
            "passed": len(findings) == 0,
            "inspected_count": len(inspected),
            "blocking_reasons": findings,
            "artifacts": inspected,
            "summary": summarize_guardrail_findings(findings),
        }


_ENGINE: GuardrailPolicyEngine | None = None


def get_guardrail_engine() -> GuardrailPolicyEngine:
    global _ENGINE
    if _ENGINE is None:
        _ENGINE = GuardrailPolicyEngine()
    return _ENGINE
