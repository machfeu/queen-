"""
mission_contract.py — Contrat opératoire commun pour les missions Queen.

Greffe A (Lot 1 ossature):
- normalise les plans produits par le planner
- explicite les handoffs entre étapes
- rend le QA gate non contournable pour les séquences codegen -> test -> eval -> patch
"""

from __future__ import annotations

from typing import Any, Dict, List, Tuple

VALID_JOB_TYPES = ("research", "codegen", "test", "eval", "patch")
CONTRACT_VERSION = "greffe-a-1"

STAGE_BY_JOB_TYPE = {
    "research": "discovery",
    "codegen": "build",
    "test": "qa",
    "eval": "review",
    "patch": "release",
}

OUTPUTS_BY_JOB_TYPE = {
    "research": ["analysis", "findings", "recommendations", "files_to_modify", "risks", "summary"],
    "codegen": ["artifacts", "summary"],
    "test": ["results", "all_passed", "summary"],
    "eval": ["score", "verdict", "justification"],
    "patch": ["files_changed", "summary", "notes"],
}

INPUTS_BY_JOB_TYPE = {
    "research": ["goal", "constraints", "workspace_snapshot"],
    "codegen": ["research_findings", "previous_context", "workspace"],
    "test": ["artifacts", "workspace"],
    "eval": ["test_results", "artifacts", "success_criteria"],
    "patch": ["approved_artifacts", "qa_summary"],
}


def _coerce_step(value: Any, fallback: int) -> int:
    try:
        step = int(value)
        return step if step > 0 else fallback
    except Exception:
        return fallback


def _clean_depends(depends_on: Any) -> List[int]:
    deps: List[int] = []
    if isinstance(depends_on, list):
        for item in depends_on:
            try:
                val = int(item)
            except Exception:
                continue
            if val > 0 and val not in deps:
                deps.append(val)
    return deps


def _make_job(step: int, job_type: str, title: str, description: str, depends_on: List[int]) -> Dict[str, Any]:
    return {
        "step": step,
        "job_type": job_type,
        "title": title,
        "description": description,
        "depends_on": depends_on,
        "estimated_duration_seconds": 60,
    }


def _attach_contract(job_spec: Dict[str, Any], success_criteria: str = "") -> Dict[str, Any]:
    job_type = job_spec.get("job_type", "research")
    depends_on = _clean_depends(job_spec.get("depends_on", []))
    contract = {
        "version": CONTRACT_VERSION,
        "stage": STAGE_BY_JOB_TYPE.get(job_type, "unknown"),
        "handoff": {
            "depends_on_steps": depends_on,
            "input_contract": INPUTS_BY_JOB_TYPE.get(job_type, []),
            "output_contract": OUTPUTS_BY_JOB_TYPE.get(job_type, []),
        },
        "qa": {
            "required_before_release": job_type in {"codegen", "patch"},
            "mandatory_checks": [
                "syntax_check" if job_type in {"codegen", "patch"} else "structured_output",
                "security_review" if job_type in {"codegen", "patch", "test"} else "consistency_review",
            ],
            "success_criteria": success_criteria or "non spécifié",
        },
    }
    enriched = dict(job_spec)
    enriched["depends_on"] = depends_on
    enriched["stage"] = contract["stage"]
    enriched["execution_contract"] = contract
    return enriched


def normalize_plan(plan_result: Dict[str, Any], goal: Dict[str, Any]) -> Dict[str, Any]:
    """Repair and normalize a plan into a shared mission contract."""
    plan_result = plan_result or {}
    constraints = (goal or {}).get("constraints", {}) or {}
    success_criteria = constraints.get("success_criteria", "")
    raw_jobs = plan_result.get("jobs", []) or []

    cleaned: List[Dict[str, Any]] = []
    for idx, raw in enumerate(raw_jobs, start=1):
        if not isinstance(raw, dict):
            continue
        job_type = str(raw.get("job_type", "")).strip().lower()
        if job_type not in VALID_JOB_TYPES:
            continue
        cleaned.append({
            "step": _coerce_step(raw.get("step"), idx),
            "job_type": job_type,
            "title": (raw.get("title") or f"Étape {idx}").strip(),
            "description": (raw.get("description") or raw.get("title") or "").strip(),
            "depends_on": _clean_depends(raw.get("depends_on", [])),
            "estimated_duration_seconds": max(30, min(int(raw.get("estimated_duration_seconds", 60) or 60), 1800)),
        })

    cleaned.sort(key=lambda x: (x["step"], x["job_type"]))
    if not cleaned:
        cleaned = [
            _make_job(1, "research", "Analyse du contexte", f"Analyser le contexte pour {(goal or {}).get('title', "l'objectif")}", []),
            _make_job(2, "codegen", "Implémentation", "Produire les modifications nécessaires.", [1]),
            _make_job(3, "test", "Contrôle qualité", "Tester et sécuriser les modifications.", [2]),
            _make_job(4, "eval", "Évaluation", "Évaluer la qualité du résultat.", [3]),
            _make_job(5, "patch", "Préparation du patch", "Préparer le patch final.", [4]),
        ]

    normalized: List[Dict[str, Any]] = []
    next_step = 1

    if cleaned[0]["job_type"] != "research":
        normalized.append(_make_job(next_step, "research", "Analyse du contexte", "Analyser le contexte avant toute modification.", []))
        next_step += 1

    for raw in cleaned:
        step = next_step
        depends_on = [normalized[-1]["step"]] if normalized else []
        if raw["job_type"] == "research" and normalized:
            depends_on = [normalized[-1]["step"]]
        job = dict(raw)
        job["step"] = step
        job["depends_on"] = depends_on
        normalized.append(job)
        next_step += 1

        if raw["job_type"] == "codegen":
            normalized.append(_make_job(
                next_step,
                "test",
                f"QA après {job['title']}",
                "Valider syntaxe, sécurité et cohérence des artefacts issus du codegen.",
                [job["step"]],
            ))
            next_step += 1

    # Strip trailing eval/patch duplicates before authoritative ending.
    while normalized and normalized[-1]["job_type"] in {"eval", "patch"}:
        normalized.pop()

    tail_dep = [normalized[-1]["step"]] if normalized else []
    normalized.append(_make_job(next_step, "eval", "Évaluation finale", "Évaluer la qualité globale du run avant intégration.", tail_dep))
    next_step += 1
    normalized.append(_make_job(next_step, "patch", "Préparation du patch final", "Préparer le patch final après validation QA.", [next_step - 1]))

    normalized = [_attach_contract(job, success_criteria=success_criteria) for job in normalized]
    plan_summary = plan_result.get("plan_summary") or f"Plan normalisé Queen ({len(normalized)} étapes)."
    return {
        "plan_summary": plan_summary,
        "jobs": normalized,
        "contract": {
            "version": CONTRACT_VERSION,
            "qa_gate": "mandatory",
            "handoff_mode": "explicit_dependencies",
            "terminal_sequence": ["eval", "patch"],
        },
    }


def build_job_execution_contract(job_spec: Dict[str, Any], goal: Dict[str, Any]) -> Dict[str, Any]:
    constraints = (goal or {}).get("constraints", {}) or {}
    success_criteria = constraints.get("success_criteria", "")
    enriched = _attach_contract(job_spec, success_criteria=success_criteria)
    return enriched.get("execution_contract", {})


def build_qa_gate_report(plan_jobs: List[Dict[str, Any]], jobs: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Authoritative QA gate. Blocks release if codegen lacks a successful linked test."""
    spec_by_step = {}
    for spec in plan_jobs or []:
        if isinstance(spec, dict):
            try:
                spec_by_step[int(spec.get("step", 0))] = spec
            except Exception:
                continue

    jobs_by_step: Dict[int, Dict[str, Any]] = {}
    for job in jobs or []:
        payload = job.get("payload", {}) or {}
        try:
            step = int(payload.get("step", 0) or 0)
        except Exception:
            step = 0
        if step > 0:
            jobs_by_step[step] = job

    checks = []
    blocking_reasons = []

    codegen_steps = [s for s, spec in spec_by_step.items() if spec.get("job_type") == "codegen"]
    if not codegen_steps:
        checks.append({"check": "qa_presence", "passed": True, "details": "No codegen step in plan."})

    for step in codegen_steps:
        linked_tests = [
            s for s, spec in spec_by_step.items()
            if spec.get("job_type") == "test" and step in (spec.get("depends_on", []) or [])
        ]
        if not linked_tests:
            blocking_reasons.append(f"No QA test linked to codegen step {step}.")
            checks.append({"check": f"qa_link_step_{step}", "passed": False, "details": "Missing linked test step."})
            continue

        passed = False
        details = []
        for test_step in linked_tests:
            test_job = jobs_by_step.get(test_step, {})
            test_result = test_job.get("result", {}) if isinstance(test_job, dict) else {}
            status = (test_job or {}).get("status", "")
            all_passed = isinstance(test_result, dict) and test_result.get("all_passed") is True
            details.append({"test_step": test_step, "status": status, "all_passed": all_passed})
            if status == "success" and all_passed:
                passed = True
        checks.append({"check": f"qa_result_step_{step}", "passed": passed, "details": details})
        if not passed:
            blocking_reasons.append(f"No successful QA result for codegen step {step}.")

    eval_steps = [s for s, spec in spec_by_step.items() if spec.get("job_type") == "eval"]
    eval_ok = any((jobs_by_step.get(step, {}) or {}).get("status") == "success" for step in eval_steps)
    checks.append({"check": "eval_job_completed", "passed": bool(eval_ok), "details": {"eval_steps": eval_steps}})
    if eval_steps and not eval_ok:
        blocking_reasons.append("The plan reached no successful eval job.")

    return {
        "passed": len(blocking_reasons) == 0,
        "blocking_reasons": blocking_reasons,
        "checks": checks,
        "contract_version": CONTRACT_VERSION,
    }
