"""Red team adapters for Greffe B."""

from .prompt_eval import PromptEvalRunnerAdapter
