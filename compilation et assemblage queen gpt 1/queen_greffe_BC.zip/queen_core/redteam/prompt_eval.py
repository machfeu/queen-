"""prompt_eval.py — compatibility wrapper for the minimal scenario runner."""

from queen_core.evals.scenario_runner import PromptEvalRunner


class PromptEvalRunnerAdapter(PromptEvalRunner):
    pass
