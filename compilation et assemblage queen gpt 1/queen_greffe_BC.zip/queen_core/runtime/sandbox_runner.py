"""
runtime/sandbox_runner.py — Greffe C / Lot 8A minimal sandbox runner.

This is not a full remote sandbox. It gives Queen a generic, local,
process-isolated execution primitive that can be reused by gates and tests.
"""

from __future__ import annotations

import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Dict, Any

STRIPPED_ENV_PREFIXES = (
    "OPENAI_",
    "QUEEN_",
    "ANTHROPIC_",
    "GOOGLE_",
    "AWS_",
    "AZURE_",
    "GITHUB_",
)


def _sandbox_env() -> Dict[str, str]:
    env = {}
    for key, value in os.environ.items():
        if any(key.startswith(prefix) for prefix in STRIPPED_ENV_PREFIXES):
            continue
        env[key] = value
    env.setdefault("PYTHONNOUSERSITE", "1")
    return env


def run_python_snippet_sandboxed(code: str, timeout: int = 5, cwd: str | None = None) -> Dict[str, Any]:
    """Execute Python code in a short-lived subprocess with stripped env vars."""
    with tempfile.TemporaryDirectory() as tmpdir:
        workdir = cwd or tmpdir
        script_path = Path(tmpdir) / "sandbox_exec.py"
        script_path.write_text(code, encoding="utf-8")

        try:
            proc = subprocess.run(
                [sys.executable, str(script_path)],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=workdir,
                env=_sandbox_env(),
            )
            return {
                "passed": proc.returncode == 0,
                "returncode": proc.returncode,
                "stdout": proc.stdout[:4000],
                "stderr": proc.stderr[:4000],
                "timeout": False,
                "sandboxed": True,
            }
        except subprocess.TimeoutExpired as exc:
            return {
                "passed": False,
                "returncode": None,
                "stdout": (exc.stdout or "")[:4000] if isinstance(exc.stdout, str) else "",
                "stderr": (exc.stderr or "")[:4000] if isinstance(exc.stderr, str) else "",
                "timeout": True,
                "sandboxed": True,
            }
