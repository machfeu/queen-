# Greffe A — Ossature / contrat de mission / QA gate

## Objectif
Première greffe structurante sur `queen18` sans remplacer le cœur.

## Ce qui a été implanté
- `queen_core/mission_contract.py`
  - normalisation des plans
  - contrat d'exécution partagé
  - séquence terminale forcée `eval -> patch`
  - injection automatique d'un test QA après chaque `codegen`
  - rapport QA autoritaire avant génération du patch
- `queen_core/planner.py`
  - passe maintenant par la normalisation du contrat de mission
- `queen_core/job_chain.py`
  - handoffs explicites basés sur `depends_on`
  - contexte injecté en priorité depuis les dépendances réelles
- `queen_core/prompt_builder.py`
  - le worker reçoit le contrat d'exécution directement dans le prompt
- `queen_core/orchestrator.py`
  - états de run plus explicites (`planning`, `dispatching`, `evaluating`, `qa_pending`)
  - QA gate obligatoire avant patch
- `queen_core/models.py`
  - enrichissement des statuts de run
- `test_mission_contract.py`
  - tests unitaires de la greffe

## Effet recherché
- éviter les plans flous
- éviter qu'un `codegen` parte au patch sans contrôle QA lié
- rendre les handoffs inter-étapes lisibles et auditables

## Limites assumées
- pas encore de sandboxing
- pas encore de guardrails offensifs lot 7
- pas encore de moteur de repo map / code intelligence
- le pipeline historique `eval/patch` côté worker existe encore ; l'orchestrateur reste l'autorité finale

## Validation locale
- `python -m py_compile ...` OK
- `pytest -q test_mission_contract.py test_version_1b.py` OK

## Prochaine greffe logique
Greffe B = lot 7 minimal : rails, scénarios d'échec obligatoires, campagne d'éval ciblée.
