from queen_core.mission_contract import normalize_plan, build_qa_gate_report


def test_normalize_plan_injects_research_and_qa_tail():
    goal = {"title": "Fix auth", "constraints": {"success_criteria": "Tests green"}}
    raw = {
        "plan_summary": "raw",
        "jobs": [
            {"step": 1, "job_type": "codegen", "title": "Patch auth", "description": "Fix auth middleware"},
        ],
    }
    plan = normalize_plan(raw, goal)
    types = [j["job_type"] for j in plan["jobs"]]
    assert types[0] == "research"
    assert "test" in types
    assert types[-2:] == ["eval", "patch"]
    assert all("execution_contract" in j for j in plan["jobs"])


def test_qa_gate_blocks_codegen_without_successful_test():
    plan_jobs = normalize_plan({
        "jobs": [{"step": 1, "job_type": "codegen", "title": "Patch", "description": "Do patch"}]
    }, {"constraints": {}})["jobs"]
    jobs = [
        {"status": "success", "payload": {"step": 1}, "result": {"artifacts": [{"path": "a.py"}] }},
        {"status": "failed", "payload": {"step": 2}, "result": {"all_passed": False}},
        {"status": "success", "payload": {"step": 3}, "result": {"score": 0.8}},
    ]
    report = build_qa_gate_report(plan_jobs, jobs)
    assert report["passed"] is False
    assert report["blocking_reasons"]
