"""
worker_unified.py — Worker unifié pour Queen V1.
Gère tous les types de jobs: research, codegen, test, eval, patch.
S'exécute en tant que non-root dans un container dédié.
"""

import json
import logging
import os
import subprocess
import sys
import tempfile
from typing import Dict, Any, List

sys.path.insert(0, "/app")

from workers.worker_base import WorkerBase
from queen_core.llm_client import generate, generate_json
from queen_core.policy import check_code_safety, validate_file_path
from queen_core.prompt_builder import build_prompt, load_skills_for_role
from queen_core.tool_registry import get_registry
from queen_core.guardrails.policy_engine import get_guardrail_engine
from queen_core.runtime.sandbox_runner import run_python_snippet_sandboxed
from queen_core.code_search.agent_fusion import build_repo_context_bundle
from queen_core.git.repo_map import build_repo_map

logger = logging.getLogger("worker.unified")


def _get_role_from_payload(payload: Dict[str, Any]) -> str:
    """Extrait le nom du rôle depuis les constraints du payload (fallback: payload['role'])."""
    constraints = payload.get("constraints", {})
    if isinstance(constraints, str):
        try:
            constraints = json.loads(constraints)
        except Exception:
            constraints = {}
    role = ""
    if isinstance(constraints, dict):
        role = (constraints.get("role") or "").strip()
    if not role:
        role = (payload.get("role") or "").strip()
    return role

def _collect_existing_files(workspace: str, max_files: int = 300) -> List[str]:
    """Liste bornée des fichiers visibles dans le workspace.

    Greffe D: cette liste sert aussi de support à la recherche de contexte repo.
    """
    existing_files: List[str] = []
    if not workspace or not os.path.exists(workspace):
        return existing_files
    for root, dirs, files in os.walk(workspace):
        dirs[:] = [d for d in dirs if d not in {'.git', '__pycache__', '.pytest_cache', 'node_modules', '.venv', 'venv'}]
        for filename in files:
            rel = os.path.relpath(os.path.join(root, filename), workspace).replace('\\', '/')
            existing_files.append(rel)
            if len(existing_files) >= max_files:
                return existing_files
    return existing_files


def _augment_payload_with_repo_context(payload: Dict[str, Any], workspace: str, max_chars: int = 2500) -> Dict[str, Any]:
    """Injecte un contexte repo hybride dans le payload si un workspace existe.

    La logique reste locale et purement informative: elle n'accorde aucun droit
    supplémentaire au worker, elle améliore juste la lecture du dépôt.
    """
    payload = dict(payload or {})
    payload['existing_files'] = payload.get('existing_files') or _collect_existing_files(workspace)
    if not workspace or not os.path.isdir(workspace):
        payload.setdefault('repo_context', 'Workspace absent: aucun contexte repo ciblé.')
        payload.setdefault('repo_context_meta', {'query_bundle': [], 'top_paths': []})
        return payload

    try:
        bundle = build_repo_context_bundle(workspace, payload, max_chars=max_chars)
    except Exception as exc:
        logger.warning('Repo context build failed: %s', exc)
        payload.setdefault('repo_context', 'Erreur locale pendant la construction du contexte repo.')
        payload.setdefault('repo_context_meta', {'query_bundle': [], 'top_paths': [], 'error': str(exc)})
        return payload

    payload['repo_context'] = bundle.get('context_text', '') or 'Aucun contexte repo ciblé trouvé.'
    payload['repo_context_meta'] = {'query_bundle': bundle.get('query_bundle', []), 'top_paths': bundle.get('top_paths', [])}

    # Greffe E: ajoute une repo map frugale pour mieux cadrer la génération
    # et la revue des futures modifications.
    try:
        repo_map = build_repo_map(workspace, max_entries=80, max_depth=4)
        payload['repo_map'] = repo_map.get('summary_text', '')
    except Exception as exc:
        logger.warning('Repo map build failed: %s', exc)
        payload.setdefault('repo_map', 'Erreur locale pendant la construction de la repo map.')
    return payload



class UnifiedWorker(WorkerBase):

    def register_handlers(self):
        self.handlers = {
            "research": self.handle_research,
            "codegen": self.handle_codegen,
            "test": self.handle_test,
            "eval": self.handle_eval,
            "patch": self.handle_patch,
        }

    # ─── Research ─────────────────────────────────────────────────────────

    def handle_research(self, job: Dict[str, Any]) -> Dict[str, Any]:
        """Research job: analyze context, gather information."""
        payload = job.get("payload", {})
        workspace = payload.get("workspace", "/workspace/default")

        # Greffe D: enrichit le payload avec une vue bornée du dépôt avant l'appel LLM.
        payload = _augment_payload_with_repo_context(payload, workspace)

        # Build specialized prompt with role + skills + previous context
        role_name = _get_role_from_payload(payload)
        skills_text = load_skills_for_role(role_name) if role_name else ""
        job["payload"] = payload
        system, user = build_prompt(job, role_name=role_name, extra_skills=skills_text)

        result = generate_json(user, system=system, run_id=job.get("run_id", ""))
        result["repo_context_used"] = payload.get("repo_context_meta", {})
        return result

    # ─── Codegen ──────────────────────────────────────────────────────────

    def handle_codegen(self, job: Dict[str, Any]) -> Dict[str, Any]:
        """Code generation job: create or modify code files."""
        payload = job.get("payload", {})
        workspace = payload.get("workspace", "/workspace/default")

        # Build specialized prompt
        guardrail_engine = get_guardrail_engine()
        request_guardrails = guardrail_engine.evaluate_job_request("codegen", payload)
        if not request_guardrails.get("passed", True):
            return {
                "artifacts": [],
                "summary": "Codegen blocked by guardrails",
                "guardrail_report": request_guardrails,
                "blocked": True,
            }

        payload = _augment_payload_with_repo_context(payload, workspace)
        job["payload"] = payload

        role_name = _get_role_from_payload(payload)
        skills_text = load_skills_for_role(role_name) if role_name else ""
        system, user = build_prompt(job, role_name=role_name, extra_skills=skills_text)

        result = generate_json(
            user,
            system=system,
            temperature=0.5,
            max_tokens=4096,
            run_id=job.get("run_id", ""),
        )
        result["repo_context_used"] = payload.get("repo_context_meta", {})

        # Validate generated code
        artifacts = result.get("artifacts", [])
        validated = []

        tool_reg = get_registry()
        file_write_def = tool_reg.get("file_write")
        python_exec_def = tool_reg.get("python_exec")

        for art in artifacts:
            content = art.get("content", "")
            path_rel = (art.get("path", "") or "").replace("\\", "/")

            # Extra policy from tools/file_write.yaml
            violations_extra = []
            if file_write_def and path_rel:
                for bp in (file_write_def.blocked_patterns or []):
                    if bp and bp in path_rel:
                        violations_extra.append(f"Blocked path pattern (file_write): {bp}")

                ext = os.path.splitext(path_rel)[1].lower()
                if ext and getattr(file_write_def, "allowed_extensions", None):
                    allowed = [e.lower() for e in (file_write_def.allowed_extensions or [])]
                    if allowed and ext not in allowed:
                        violations_extra.append(f"Extension not allowed by file_write: {ext}")

            if violations_extra:
                art["rejected"] = True
                art["violations"] = violations_extra
                validated.append(art)
                continue

            # Code safety (merge default + python_exec tool patterns)
            safe, violations = check_code_safety(content)
            if python_exec_def and getattr(python_exec_def, "blocked_patterns", None):
                for bp in (python_exec_def.blocked_patterns or []):
                    if bp and bp in content:
                        safe = False
                        violations.append(f"Blocked pattern (python_exec): {bp}")

            if safe and path_rel:
                # Write to workspace
                path_norm = path_rel.lstrip("/")
                full_path = os.path.join(workspace, path_norm)
                # 1.6.1 LOT 8: realpath resolves symlinks, commonpath is safer than startswith
                abs_ws = os.path.realpath(workspace)
                abs_full = os.path.realpath(full_path)
                try:
                    common = os.path.commonpath([abs_ws, abs_full])
                    path_ok = (common == abs_ws)
                except ValueError:
                    # Different drives on Windows, or empty paths
                    path_ok = False
                if not path_ok:
                    ok, reason = False, "Artifact path escapes workspace"
                else:
                    ok, reason = validate_file_path(full_path)
                if ok:
                    os.makedirs(os.path.dirname(full_path), exist_ok=True)
                    with open(full_path, "w", encoding="utf-8") as f:
                        f.write(content)
                else:
                    art["rejected"] = True
                    art["violations"] = [reason]
            else:
                art["rejected"] = True
                art["violations"] = violations or ["Invalid path"]

            validated.append(art)

        result["artifacts"] = validated
        result_guardrails = guardrail_engine.evaluate_job_result("codegen", result, workspace_root=workspace)
        result["guardrail_report"] = result_guardrails
        return result

    # ─── Test ─────────────────────────────────────────────────────────────

    def handle_test(self, job: Dict[str, Any]) -> Dict[str, Any]:
        """Test job: run lint, tests, security checks."""
        payload = job.get("payload", {})
        workspace = payload.get("workspace", "/workspace/default")

        results = {"lint": {}, "syntax": {}, "security": {}}

        # Find Python files
        py_files = []
        if os.path.exists(workspace):
            for root, dirs, files in os.walk(workspace):
                for f in files:
                    if f.endswith(".py"):
                        py_files.append(os.path.join(root, f))

        if not py_files:
            return {"results": results, "summary": "No Python files to test"}

        # Syntax check
        syntax_errors = []
        for fp in py_files:
            try:
                with open(fp, "r") as f:
                    compile(f.read(), fp, "exec")
            except SyntaxError as e:
                syntax_errors.append(f"{fp}: {e}")
        results["syntax"] = {
            "passed": len(syntax_errors) == 0,
            "errors": syntax_errors,
            "files_checked": len(py_files),
        }

        # Greffe C: execute a tiny smoke import in a stripped-env subprocess.
        sandbox_checks = []
        for fp in py_files[:5]:
            rel_name = os.path.splitext(os.path.basename(fp))[0]
            sandbox_code = (
                "import importlib.util, pathlib\n"
                f"p = pathlib.Path({fp!r})\n"
                "spec = importlib.util.spec_from_file_location('mod_under_test', p)\n"
                "mod = importlib.util.module_from_spec(spec)\n"
                "spec.loader.exec_module(mod)\n"
                "print('ok')\n"
            )
            sandbox_checks.append({"file": fp, **run_python_snippet_sandboxed(sandbox_code, timeout=5, cwd=workspace)})
        results["sandbox_smoke"] = {
            "passed": all(item.get("passed", False) for item in sandbox_checks) if sandbox_checks else True,
            "checks": sandbox_checks,
        }

        # Basic lint (py_compile)
        try:
            lint_result = subprocess.run(
                ["python", "-m", "py_compile"] + py_files[:10],
                capture_output=True, text=True, timeout=30,
                cwd=workspace,
            )
            results["lint"] = {
                "passed": lint_result.returncode == 0,
                "stdout": lint_result.stdout[:2000],
                "stderr": lint_result.stderr[:2000],
            }
        except (subprocess.TimeoutExpired, FileNotFoundError) as e:
            results["lint"] = {"passed": False, "error": str(e)}

        # Security check (basic pattern matching)
        security_issues = []
        for fp in py_files:
            try:
                with open(fp, "r") as f:
                    content = f.read()
                safe, violations = check_code_safety(content)
                if not safe:
                    security_issues.extend([f"{fp}: {v}" for v in violations])
            except Exception as e:
                logger.warning(f"Security check failed for {fp}: {e}")  # LOT 3: Was too silent
        results["security"] = {
            "passed": len(security_issues) == 0,
            "issues": security_issues,
        }

        all_passed = all(
            r.get("passed", False) for r in results.values() if isinstance(r, dict)
        )

        # Self-heal: auto-correction when tests fail (max 2 attempts)
        if not all_passed:
            try:
                from queen_core.self_heal import attempt_self_heal
                run_id = job.get("run_id", "")
                test_result = {"results": results, "all_passed": False}
                healed, heal_result = attempt_self_heal(
                    job=job,
                    test_result=test_result,
                    workspace=workspace,
                    attempt=1,
                    run_id=run_id,
                )
                if healed:
                    logger.info("Self-heal succeeded; returning healed results")
                    return {
                        "results": heal_result.get("retest_result", {}).get("results", results),
                        "all_passed": True,
                        "summary": f"Self-healed after {heal_result.get('attempt', 1)} attempt(s)",
                        "self_healed": True,
                        "heal_details": heal_result,
                    }
                else:
                    logger.info(f"Self-heal failed: {heal_result.get('status')}")
            except Exception as e:
                logger.warning(f"Self-heal error: {e}")

        return {
            "results": results,
            "all_passed": all_passed,
            "summary": "All checks passed" if all_passed else "Some checks failed",
        }

    # ─── Eval ─────────────────────────────────────────────────────────────

    def handle_eval(self, job: Dict[str, Any]) -> Dict[str, Any]:
        """Evaluation job: assess quality using multi-evaluator consensus."""
        payload = job.get("payload", {})
        run_id = job.get("run_id", "")

        # Build context for consensus evaluation (prefer chained context)
        previous_context = payload.get("previous_context", "")
        context = {
            "goal_title": payload.get("goal_title", ""),
            "goal_description": payload.get("goal_description", ""),
            "success_criteria": payload.get("success_criteria", ""),
            "result_summary": previous_context or payload.get("description", ""),
        }

        try:
            from queen_core.consensus import evaluate_with_consensus
            from queen_core.notifier import notify, NotifyEvent

            result = evaluate_with_consensus(
                context=context,
                num_evaluators=3,
                run_id=run_id,
            )

            # Notify if evaluators disagree significantly
            if result.get("score_spread", 0) > 0.3:
                notify(NotifyEvent.CONSENSUS_DISAGREEMENT, {
                    "run_id": run_id,
                    "scores": str(result.get("scores", [])),
                    "spread": str(result.get("score_spread", 0)),
                })

            return {
                "score": result.get("consensus_score", 0.0),
                "verdict": result.get("consensus_verdict", "retry"),
                "criteria_scores": {
                    r.get("focus", "unknown"): r.get("score", 0.0)
                    for r in result.get("individual_results", [])
                },
                "strengths": result.get("strengths", []),
                "weaknesses": result.get("weaknesses", []),
                "consensus": {
                    "num_evaluators": result.get("num_evaluators", 0),
                    "approvals": result.get("approvals", 0),
                    "rejections": result.get("rejections", 0),
                    "score_spread": result.get("score_spread", 0),
                },
                "individual_results": result.get("individual_results", []),
            }

        except Exception as e:
            # LOT 9: BUG-006 — NameError si import notifier échoue
            logger.warning(f"Consensus evaluation failed, falling back to single eval: {e}")
            # Fallback: single eval via prompt builder
            role_name = _get_role_from_payload(payload)
            skills_text = load_skills_for_role(role_name) if role_name else ""
            system, user = build_prompt(job, role_name=role_name, extra_skills=skills_text)
            return generate_json(user, system=system, run_id=run_id)

    # ─── Patch ────────────────────────────────────────────────────────────

    def handle_patch(self, job: Dict[str, Any]) -> Dict[str, Any]:
        """Patch job: generate diff from workspace changes."""
        payload = job.get("payload", {})
        workspace = payload.get("workspace", "/workspace/default")

        # Collect all files in workspace
        artifacts = []
        if os.path.exists(workspace):
            for root, dirs, files in os.walk(workspace):
                # Skip hidden dirs and backups
                dirs[:] = [d for d in dirs if not d.startswith(".")]
                for f in files:
                    if f.startswith("."):
                        continue
                    full = os.path.join(root, f)
                    rel = os.path.relpath(full, workspace)
                    try:
                        with open(full, "r", encoding="utf-8") as fh:
                            content = fh.read()
                        artifacts.append({"path": rel, "content": content})
                    except Exception:
                        pass

        return {
            "artifacts": artifacts,
            "files_count": len(artifacts),
            "workspace": workspace,
            "summary": f"Collected {len(artifacts)} files for patch generation",
        }


# ─── Entry Point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    worker = UnifiedWorker()
    worker.run()
