# Greffe J — Orchestration externe / observabilité minimale

## Source et intention
- Source lot: lot 9 orchestration externe et observabilité avancée
- README consultés: `README_LOT_9.md`, `INTEGRATION_NOTES.md`
- Approche choisie: préparer les interfaces et les payloads, sans brancher les services externes

## Version antérieure
- traces locales présentes mais sans export structuré vers observabilité avancée
- aucune représentation normalisée pour Prefect / Dapr / Dagger

## Améliorations apportées
- manifestes externes frugaux ajoutés
- bundle d'observabilité construit à partir des traces locales
- méthode `build_observability_exports()` ajoutée au trace store

## Bugs rencontrés
- aucun bug bloquant

## Fixes appliqués
- export pur data, sans side effect réseau
- utilisation des traces déjà présentes au lieu d'ajouter une nouvelle pile technique

## Rollback simple
- supprimer `queen_core/orchestration` et `queen_core/observability`
- retirer `build_observability_exports()` de `trace_store.py`
