# Notes Greffe D — Lot 8B code intelligence minimale

## Résumé exécutif
Greffe D ajoute une couche de lecture du dépôt avant action.
Queen sait maintenant fabriquer un contexte repo ciblé à partir de l'objectif, des chemins mentionnés et du code présent dans le workspace.

## Ce qui a été greffé
- `queen_core/code_search/fast_index.py`
- `queen_core/code_search/semantic_repo.py`
- `queen_core/code_search/agent_fusion.py`
- intégration dans `workers/worker_unified.py`
- enrichissement prompts dans `queen_core/prompt_builder.py`
- tests `test_codeintel_minimal.py`

## Gains
- moins de patchs à l'aveugle
- meilleurs rappels de fichiers utiles
- meilleure précision pour `research` et `codegen`
- base locale propre avant un vrai backend Zoekt/osgrep plus tard

## Limites honnêtes
- pas de recherche sémantique profonde
- pas d'AST avancé
- pas de symbol index complet
- pas de service externe ni persistance d'index

## Rollback simple
1. supprimer `queen_core/code_search/`
2. retirer les imports et appels `_augment_payload_with_repo_context` dans `workers/worker_unified.py`
3. retirer `repo_context` dans `queen_core/prompt_builder.py`
