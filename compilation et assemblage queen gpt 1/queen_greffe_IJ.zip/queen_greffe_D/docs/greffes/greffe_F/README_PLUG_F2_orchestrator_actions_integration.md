# Plug F2 — Intégration orchestrator / actions

## Version antérieure
L'orchestrator et les actions mettaient les statuts à jour directement.

## Amélioration
Passage progressif par `update_status_guarded()` sur les transitions clés.

## Bugs rencontrés
- garder le comportement existant tout en rendant les dérives visibles

## Fixes appliqués
- intégration douce, sans blocage dur
- conservation des champs annexes (`finished_at`, `approved_by`, etc.)

## Validation
`test_update_status_guarded_updates_and_audits_warning`
