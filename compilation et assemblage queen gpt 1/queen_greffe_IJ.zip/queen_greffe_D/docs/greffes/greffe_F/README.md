# Greffe F — Lot 2A formalisation moteur / états minimale

## Objet
Rendre les transitions d'état plus explicites sans remplacer l'orchestrateur actuel.

## Périmètre
- table de transitions pour goals, runs, jobs, patches
- helper `update_status_guarded()`
- audit des sauts d'état incohérents
- intégration douce dans orchestrator et actions

## Ce que cette greffe n'est pas encore
- pas un moteur d'agents externe
- pas un workflow engine
- pas de reprise distribuée avancée

## Validation
- compilation Python des fichiers modifiés
- tests ciblés Greffe F + non-régression courte

## Rollback
Supprimer `queen_core/runtime/state_machine.py`, retirer `update_status_guarded` dans `orchestrator.py` et `actions.py`.
