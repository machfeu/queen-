# Plug F1 — State machine frugale

## Version antérieure
Les statuts existaient déjà, mais sans tables de transitions explicites ni audit des sauts incohérents.

## Amélioration
Ajout de `queen_core/runtime/state_machine.py` avec validation des transitions pour goals, runs, jobs et patches.

## Bugs rencontrés
- ne pas casser le tronc en bloquant brutalement un flux déjà existant

## Fixes appliqués
- validation douce
- warnings dans les logs
- audit persisté si saut d'état incohérent

## Validation
- `test_validate_transition_accepts_expected_path`
- `test_validate_transition_flags_unexpected_jump`
