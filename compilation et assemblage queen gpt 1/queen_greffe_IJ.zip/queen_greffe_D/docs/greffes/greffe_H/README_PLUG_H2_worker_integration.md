# Plug H2 — intégration worker

## Version antérieure
Les résultats `research`, `codegen`, `eval`, `patch` pouvaient varier trop fortement de forme.

## Amélioration
Application des contrats typés directement dans `worker_unified.py`.

## Bugs rencontrés
- aucun bloquant; la principale contrainte était de ne pas gêner les guardrails ni la validation d'artifacts.

## Fixe appliqué
- normalisation placée après enrichissement / validation locale quand nécessaire.
