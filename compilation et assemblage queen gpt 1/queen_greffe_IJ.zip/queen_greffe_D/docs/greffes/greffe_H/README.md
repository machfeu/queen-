# Greffe H — lot 6 sorties typées frugales

## Intention
Réduire les sorties molles et rendre les résultats des jobs plus stables pour le reste du pipeline.

## Sous-plugs
- H1: contrats de sortie research/codegen/eval/patch
- H2: intégration worker
- H3: documentation et rollback simple
