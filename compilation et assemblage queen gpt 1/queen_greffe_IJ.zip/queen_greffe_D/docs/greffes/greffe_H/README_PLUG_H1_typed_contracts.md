# Plug H1 — contrats de sortie typés

## Version antérieure
Les workers renvoyaient des JSON corrects la plupart du temps, mais sans contrat stable en sortie.

## Amélioration
Ajout de contrats de sortie frugaux inspirés de PydanticAI, mais sans dépendance externe.

## Bugs rencontrés
- risque de casser le pipeline si on rend la validation trop stricte.

## Fixe appliqué
- validation permissive avec annotation `_schema_valid` et `_schema_errors`.
