# Plug E2 — Diff presenter

## Version antérieure
Le diff était généré et stocké, mais peu relu de façon structurée avant les gates.

## Amélioration
Ajout de `queen_core/review/diff_presenter.py` pour compter fichiers, hunks, ajouts, suppressions et surfaces sensibles.

## Bugs rencontrés
- rester compatible avec les diffs unifiés générés localement par Queen
- produire une estimation de risque simple sans sur-ingénierie

## Fixes appliqués
- parser frugal ligne par ligne
- heuristique de risque bornée
- alertes lisibles sur surfaces sensibles

## Validation
`test_diff_presenter_summarizes_changes`
