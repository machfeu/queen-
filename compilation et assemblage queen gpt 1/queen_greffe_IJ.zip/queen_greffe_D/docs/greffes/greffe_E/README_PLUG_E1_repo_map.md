# Plug E1 — RepoMapService

## Version antérieure
Queen disposait d'un contexte repo hybride via Greffe D, mais pas d'une vraie cartographie bornée du dépôt exploitable pour la revue de patch.

## Amélioration
Ajout de `queen_core/git/repo_map.py` pour résumer l'arborescence utile du workspace et les cibles d'un patch.

## Bugs rencontrés
- risque de produire une carte trop lourde sur un gros dépôt
- besoin de rester local, déterministe et sans dépendance git obligatoire

## Fixes appliqués
- profondeur bornée
- nombre d'entrées plafonné
- exclusion des dossiers parasites

## Validation
`test_repo_map_builds_summary`
