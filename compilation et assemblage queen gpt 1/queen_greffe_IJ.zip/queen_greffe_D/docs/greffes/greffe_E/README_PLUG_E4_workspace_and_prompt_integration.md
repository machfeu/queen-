# Plug E4 — Workspace provider + intégration prompt/worker

## Version antérieure
Le workspace existait de fait, mais sans provider explicite. Les prompts codegen connaissaient le repo context, pas une carte bornée du dépôt.

## Amélioration
- ajout de `queen_core/workspaces/provider.py`
- enrichissement du payload worker avec `repo_map`
- intégration de `repo_map` dans les prompts `codegen` et `patch`
- passage de l'orchestrator par un provider explicite pour le workspace cible

## Bugs rencontrés
- ne pas casser les handlers existants
- garder des prompts suffisamment courts

## Fixes appliqués
- provider minimal et local
- fallback doux en cas d'échec de repo map
- repo map textuelle bornée

## Validation
`test_prompt_builder_codegen_includes_repo_map`
