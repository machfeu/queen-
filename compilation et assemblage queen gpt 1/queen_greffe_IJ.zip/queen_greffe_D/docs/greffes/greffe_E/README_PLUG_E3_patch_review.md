# Plug E3 — Patch review bornée

## Version antérieure
Les gates validaient syntaxe, sécurité et chemins, mais pas la lisibilité globale du patch ni sa taille de revue.

## Amélioration
Ajout de `queen_core/review/patch_review.py` et d'un gate `diff_review` dans l'orchestrator.

## Bugs rencontrés
- éviter de bloquer tous les patches légitimes
- signaler la dérive par rapport au contexte repo ciblé sans créer de faux blocages partout

## Fixes appliqués
- seuils simples sur nombre de fichiers et volume de lignes
- warnings séparés des blocages
- comparaison douce avec `top_paths` issus du code intelligence

## Validation
`test_patch_review_blocks_large_patch`
