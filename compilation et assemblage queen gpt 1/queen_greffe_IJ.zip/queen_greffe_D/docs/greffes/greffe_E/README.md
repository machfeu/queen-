# Greffe E — Lot 3 action code bornée

## Objet
Renforcer la capacité d'action sur du code sans donner à Queen une autonomie sauvage.

## Périmètre de cette greffe
- repo map locale frugale
- revue structurée du diff avant application
- provider de workspace explicite
- enrichissement des prompts et du pipeline patch avec ces nouvelles briques

## Ce que cette greffe n'est pas encore
- pas un équivalent complet d'OpenHands
- pas une intégration git complète façon Aider
- pas d'agent multi-outils autonome sur repo principal

## Ordre interne des plugs
1. E1 — repo map frugale
2. E2 — diff presenter
3. E3 — patch review bornée
4. E4 — workspace provider + intégration orchestrator/worker/prompt

## Validation
- compilation Python des fichiers modifiés
- tests ciblés Greffes A/B/C/D + Greffe E

## Rollback
Supprimer `queen_core/git`, `queen_core/review`, `queen_core/workspaces`, retirer `repo_map` du prompt builder et du worker, puis retirer `diff_review` et `WorkspaceProvider` de l'orchestrator.
