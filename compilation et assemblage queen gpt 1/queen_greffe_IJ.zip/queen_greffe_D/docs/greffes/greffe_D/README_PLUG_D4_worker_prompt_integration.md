# Plug D4 — Intégration workers et prompts

## Version antérieure
Les prompts `research` et `codegen` étaient plus pauvres que nécessaire. Ils manquaient d'un vrai contexte repo ciblé.

## Amélioration
- injection de `repo_context` dans `prompt_builder.py`
- ajout de `_augment_payload_with_repo_context()` dans `workers/worker_unified.py`
- remontée de `repo_context_used` dans les résultats `research` et `codegen`

## Bugs rencontrés
- risque d'oublier les tests et evals si le champ `repo_context` devenait obligatoire

## Fix appliqué
- fallback explicite `Aucun contexte repo ciblé`
- intégration douce sans casser les handlers existants

## Fichiers touchés
- `workers/worker_unified.py`
- `queen_core/prompt_builder.py`
- `test_codeintel_minimal.py`

## Validation
- `test_prompt_builder_includes_repo_context`
- compilation Python des fichiers modifiés
