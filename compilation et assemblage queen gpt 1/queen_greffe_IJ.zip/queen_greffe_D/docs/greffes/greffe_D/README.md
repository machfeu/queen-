# Greffe D — Lot 8B code intelligence minimale

## But
Donner à Queen une lecture locale du dépôt avant génération ou modification de code, sans service externe, sans daemon, sans vector store.

## Périmètre de cette greffe
- recherche lexicale rapide de fichiers et snippets
- recherche sémantique frugale par recouvrement de tokens
- fusion de contexte repo pour les workers `research` et `codegen`
- injection du contexte repo dans les prompts

## Ce qui n'est pas encore fait
- vrai backend Zoekt
- vrai backend osgrep
- daemon de recherche à chaud
- index persistant multi-repo
- mémoire vectorielle Qdrant

## Ordre interne des plugs
1. D1 — index lexical rapide
2. D2 — recherche sémantique locale
3. D3 — fusion de contexte hybride
4. D4 — intégration workers et prompts

## Validation
- compilation Python des fichiers modifiés
- tests ciblés Greffe D
- non-régression des tests Greffes A/B/C ciblés

## Rollback
Supprimer le dossier `queen_core/code_search`, retirer l'appel à `_augment_payload_with_repo_context` dans `workers/worker_unified.py`, puis retirer `repo_context` de `prompt_builder.py`.
