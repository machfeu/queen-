# Plug D1 — Fast repo index

## Version antérieure
Aucune vraie recherche repo locale n'était présente. Les workers voyaient surtout `existing_files` et le contexte des jobs précédents.

## Amélioration
Ajout de `queen_core/code_search/fast_index.py` avec :
- parcours borné du workspace
- filtre d'extensions
- exclusion de dossiers parasites
- recherche lexicale avec scoring simple
- snippets avec numéros de lignes

## Bugs rencontrés
- risque de bruit excessif quand la requête contenait trop de mots faibles

## Fix appliqué
- tokenisation compacte
- stopwords minimaux
- limite de tokens et de résultats

## Fichiers touchés
- `queen_core/code_search/fast_index.py`
- `queen_core/code_search/__init__.py`

## Validation
`test_fast_index_finds_auth_file`
