# Plug D3 — Hybrid context adapter

## Version antérieure
Le dépôt n'était pas synthétisé en contexte ciblé. Le LLM recevait surtout une liste de fichiers et du texte libre.

## Amélioration
Ajout de `queen_core/code_search/agent_fusion.py` avec :
- bundle de requêtes dérivé de la mission
- recherche exacte + recherche sémantique
- fusion et déduplication des hits
- rendu texte compact prêt pour prompt

## Bugs rencontrés
- risque d'injecter trop de contexte et de noyer la mission

## Fix appliqué
- taille max du contexte
- nombre de requêtes limité
- top paths explicites pour audit

## Fichiers touchés
- `queen_core/code_search/agent_fusion.py`
- `queen_core/code_search/__init__.py`

## Validation
`test_agent_fusion_builds_repo_context`
