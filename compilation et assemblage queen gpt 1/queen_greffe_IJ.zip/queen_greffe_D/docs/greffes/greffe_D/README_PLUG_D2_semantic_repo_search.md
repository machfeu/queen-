# Plug D2 — Semantic repo search frugal

## Version antérieure
Aucune couche sémantique locale n'existait. Queen pouvait lire des fichiers, mais ne savait pas vraiment prioriser les plus proches de l'intention.

## Amélioration
Ajout de `queen_core/code_search/semantic_repo.py` avec :
- index léger par dépôt
- scoring par recouvrement de tokens
- bonus sur chemin et nom de fichier
- snippets courts pour expliquer les hits

## Bugs rencontrés
- risque de faux positifs sur requêtes trop génériques

## Fix appliqué
- scoring borné
- dépendance forte au recouvrement effectif des tokens
- résultats limités

## Fichiers touchés
- `queen_core/code_search/semantic_repo.py`
- `queen_core/code_search/__init__.py`

## Validation
`test_semantic_search_ranks_policy_for_constraints`
