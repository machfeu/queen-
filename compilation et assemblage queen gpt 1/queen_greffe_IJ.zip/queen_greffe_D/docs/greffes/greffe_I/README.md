# Greffe I — Browser / UI operator minimal

## Résumé
Cette greffe apporte une couche browser/operator **bornée** et **sèche**:
- plan navigateur local sans vrai daemon
- références de snapshots textuels
- aperçu de flux
- planification visuelle locale
- manifeste d'outils client browser

## Pourquoi cette forme
Le lot 10 recommande explicitement: commencer par un worker navigateur borné puis enrichir. C'est ce qui a été fait ici.

## Ce qui est reporté
- vrai daemon navigateur
- vraie boucle Playwright/Stagehand
- operator visuel riche
- mobile bridge
