# Plug I4 — Worker + client tools browser

## Version antérieure
Le worker unifié ne savait gérer ni browser ni UI operator.

## Amélioration
Ajout de handlers dédiés et d'un manifeste MCP client local pour outils navigateur.

## Fix appliqué
Tout reste en `dry_run`, sans side effects externes.
