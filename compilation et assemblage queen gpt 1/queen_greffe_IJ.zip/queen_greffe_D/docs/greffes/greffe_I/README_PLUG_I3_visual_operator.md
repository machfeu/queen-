# Plug I3 — Visual operator borné

## Version antérieure
Aucune planification visuelle structurée.

## Amélioration
Ajout d'un `VisualTaskPlanner` local qui construit une liste d'actions inspectables.

## Bugs rencontrés
Cibles sans selector/bbox possibles.

## Fix appliqué
Warnings explicites et fallback `inspect viewport`.
