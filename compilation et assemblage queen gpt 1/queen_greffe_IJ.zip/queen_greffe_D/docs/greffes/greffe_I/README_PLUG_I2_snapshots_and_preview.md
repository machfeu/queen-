# Plug I2 — Snapshots et preview

## Version antérieure
Aucune référence de snapshot textuelle ni vue compacte du flux d'actions.

## Amélioration
Ajout de références stables `snap_*` et d'un aperçu lisible des actions navigateur.

## Fix appliqué
Référence calculée sur un digest court et contenu borné.
