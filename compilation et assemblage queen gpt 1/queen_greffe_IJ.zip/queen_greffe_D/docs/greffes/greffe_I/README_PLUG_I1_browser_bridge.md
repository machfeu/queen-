# Plug I1 — BrowserDaemonBridge

## Version antérieure
Aucun pont navigateur structuré.

## Amélioration
Ajout d'un plan navigateur sec avec validation de domaines et taille bornée du plan.

## Bugs rencontrés
Le vrai risque était la sortie de périmètre par URL libre.

## Fix appliqué
Validation stricte `allowed_domains` et normalisation d'URL.
