# Plug G3 — manifeste MCP minimal

## Version antérieure
Aucun protocole standard formalisé pour exposer les outils de Queen.

## Amélioration
Ajout d'un manifeste `mcp-lite` local basé sur le registre d'outils déjà existant.

## Bugs rencontrés
- risque de surpromesse si on prétend implémenter tout MCP.

## Fixe appliqué
- réduction volontaire à un export de manifeste simple et honnête.
