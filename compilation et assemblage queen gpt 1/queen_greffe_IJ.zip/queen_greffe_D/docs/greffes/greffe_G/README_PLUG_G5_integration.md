# Plug G5 — intégration worker / prompt / orchestrator

## Version antérieure
Les workers avaient un contexte repo mais pas de mémoire durable ni de traces structurées par run.

## Amélioration
Injection de `memory_context` dans les prompts, traces de run dans l'orchestrateur, et persistance d'un résumé de run après évaluation.

## Bugs rencontrés
- risque de rendre le job fragile si la mémoire locale échoue.

## Fixe appliqué
- intégration best-effort avec fallback silencieux et logs warning.
