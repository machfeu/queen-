# Greffe G — lot 4 mémoire / traces / MCP utile

## Intention
Renforcer la continuité d'apprentissage de Queen sans basculer trop tôt dans une architecture lourde.

## Sous-plugs
- G1: mémoire durable frugale
- G2: traces locales JSONL
- G3: manifeste MCP minimal
- G4: connecteur filesystem borné
- G5: intégration worker / prompt / orchestrator
