# Plug G2 — traces locales JSONL

## Version antérieure
Logs Redis en temps réel, mais pas de traces de run faciles à archiver ou relire hors ligne.

## Amélioration
Ajout de `TraceStore` qui écrit des événements structurés par run en JSONL.

## Bugs rencontrés
- aucun bug bloquant, seulement la contrainte de rester sans dépendance externe.

## Fixe appliqué
- stockage fichier ultra simple sous `/data/traces`.
