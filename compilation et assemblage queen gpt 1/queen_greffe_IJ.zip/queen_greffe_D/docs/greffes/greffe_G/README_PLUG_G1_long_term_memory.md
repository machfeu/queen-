# Plug G1 — mémoire durable frugale

## Version antérieure
Queen persistait goals/runs/jobs/patches mais ne gardait pas de "souvenirs" réutilisables par recherche simple.

## Amélioration
Ajout de `LongTermMemoryStore` pour stocker des résumés durables et les réinjecter dans les prompts futurs.

## Bugs rencontrés
- collision de nom potentielle avec `queen_core.memory`

## Fixe appliqué
- package séparé `queen_core.memories`
