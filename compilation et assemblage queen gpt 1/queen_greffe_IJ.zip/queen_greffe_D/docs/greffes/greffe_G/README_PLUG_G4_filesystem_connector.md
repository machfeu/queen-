# Plug G4 — connecteur filesystem borné

## Version antérieure
Pas de brique MCP locale réutilisable pour le filesystem.

## Amélioration
Ajout d'un connecteur local `filesystem_mcp` limité au workspace, avec lecture et listage sûrs.

## Bugs rencontrés
- risque d'évasion de chemin (`..`) et fuite de fichiers sensibles.

## Fixe appliqué
- résolution par `realpath` + blocage explicite des segments sensibles.
