# Greffe J — Orchestration / observabilité minimales

## Résumé
Cette greffe prépare l'arrivée de Prefect, Dapr, Dagger, Helicone, LangWatch et AgentNeo sans les brancher pour de vrai.

## Ce qui est fait
- manifestes externes structurés
- exports d'observabilité basés sur les traces locales

## Ce qui est reporté
- services externes réels
- instrumentation réseau
- orchestration distribuée
