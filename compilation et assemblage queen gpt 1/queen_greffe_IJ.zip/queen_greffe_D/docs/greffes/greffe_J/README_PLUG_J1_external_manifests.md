# Plug J1 — Manifestes externes

## Version antérieure
Aucune représentation stable pour Prefect/Dapr/Dagger.

## Amélioration
Ajout de manifestes purs data prêts à être câblés plus tard.
