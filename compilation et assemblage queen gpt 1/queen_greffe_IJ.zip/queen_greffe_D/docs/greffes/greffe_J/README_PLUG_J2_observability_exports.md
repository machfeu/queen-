# Plug J2 — Exports d'observabilité

## Version antérieure
Les traces locales n'avaient pas de sortie normalisée vers Helicone/LangWatch/AgentNeo.

## Amélioration
Ajout d'un bundle d'export calculé localement depuis `TraceStore`.
