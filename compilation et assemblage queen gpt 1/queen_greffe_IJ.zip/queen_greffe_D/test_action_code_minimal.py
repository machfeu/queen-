"""Tests ciblés Greffe E — action code bornée."""
from __future__ import annotations
import os, shutil, tempfile
from queen_core.git.repo_map import build_repo_map
from queen_core.prompt_builder import build_prompt
from queen_core.review.diff_presenter import summarize_unified_diff
from queen_core.review.patch_review import build_patch_review_report

def _make_workspace(files:dict[str,str])->tuple[str,str]:
    tmpdir=tempfile.mkdtemp(); workspace=os.path.join(tmpdir,'repo'); os.makedirs(workspace,exist_ok=True)
    for rel,content in files.items():
        full=os.path.join(workspace,rel); os.makedirs(os.path.dirname(full),exist_ok=True)
        with open(full,'w',encoding='utf-8') as h: h.write(content)
    return tmpdir,workspace

def test_repo_map_builds_summary():
    tmpdir,workspace=_make_workspace({'queen_core/orchestrator.py':'print(1)\n','workers/worker_unified.py':'print(2)\n','README.md':'hello\n'})
    try:
        result=build_repo_map(workspace,max_entries=20,max_depth=3)
        assert result['file_count']>=3
        assert 'queen_core/orchestrator.py' in result['summary_text']
        print('PASS: test_repo_map_builds_summary')
    finally: shutil.rmtree(tmpdir)

def test_diff_presenter_summarizes_changes():
    diff="""--- a/app.py
+++ b/app.py
@@ -1,2 +1,3 @@
-print('old')
+print('new')
+print('extra')
"""
    result=summarize_unified_diff(diff)
    assert result['files_changed']==1 and result['additions']==2 and result['deletions']==1
    print('PASS: test_diff_presenter_summarizes_changes')

def test_patch_review_blocks_large_patch():
    tmpdir,workspace=_make_workspace({'app.py':'print(\'old\')\n'})
    try:
        huge_body='\n'.join(f'+line_{i}' for i in range(350))
        diff=f"--- a/app.py\n+++ b/app.py\n@@ -1,1 +1,350 @@\n-print('old')\n{huge_body}\n"
        report=build_patch_review_report([{'path':'app.py','content':'print(\'new\')\n'}],diff,workspace,repo_context_meta={'top_paths':['app.py']})
        assert report['passed'] is False
        assert any('trop volumineux' in r.lower() for r in report['blocking_reasons'])
        print('PASS: test_patch_review_blocks_large_patch')
    finally: shutil.rmtree(tmpdir)

def test_prompt_builder_codegen_includes_repo_map():
    job={'job_type':'codegen','payload':{'goal_title':'Stabiliser le worker','description':'Ajouter une revue de diff','repo_context':'- workers/worker_unified.py','repo_map':'=== Repo map bornée ===\n- workers/worker_unified.py','execution_contract':{'qa_required':True}}}
    _system,user=build_prompt(job)
    assert 'Repo map bornée' in user and 'Patch petit et ciblé' in user
    print('PASS: test_prompt_builder_codegen_includes_repo_map')

if __name__=='__main__':
    test_repo_map_builds_summary(); test_diff_presenter_summarizes_changes(); test_patch_review_blocks_large_patch(); test_prompt_builder_codegen_includes_repo_map(); print('All Greffe E tests passed')
