"""Tests Greffe G — mémoire durable, traces locales et MCP minimal."""
from __future__ import annotations

import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from connectors.filesystem_mcp import list_files, read_text
from queen_core.memories.long_term_store import LongTermMemoryStore
from queen_core.mcp.protocol import build_filesystem_server_manifest, build_mcp_tool_manifest
from queen_core.prompt_builder import build_prompt
from queen_core.telemetry.trace_store import TraceStore
from queen_core.tool_registry import ToolRegistry


def test_long_term_memory_search_and_context():
    tmpdir = tempfile.mkdtemp()
    try:
        store = LongTermMemoryStore(os.path.join(tmpdir, "queen.db"))
        store.remember(
            "Le middleware auth doit conserver le schéma Bearer et éviter les régressions de header.",
            source_type="run_outcome",
            source_id="run_auth",
            title="Auth flow stabilisé",
            tags=["auth", "bearer"],
            importance=0.8,
        )
        hits = store.search("auth bearer header", limit=3)
        assert hits and hits[0]["source_id"] == "run_auth"
        context = store.build_context({"goal_title": "Fix auth", "description": "repair bearer header"})
        assert "Mémoire durable utile" in context and "run_auth" in context
        print("PASS: test_long_term_memory_search_and_context")
    finally:
        shutil.rmtree(tmpdir)


def test_trace_store_records_and_summarizes():
    tmpdir = tempfile.mkdtemp()
    try:
        traces = TraceStore(tmpdir)
        trace_id = traces.new_trace_id("run")
        traces.record_event(trace_id, "run_started", {"goal_id": "goal_1"})
        traces.record_event(trace_id, "evaluation_completed", {"score": 0.91})
        summary = traces.summarize_trace(trace_id)
        assert summary["events"] == 2
        assert summary["event_types"] == ["run_started", "evaluation_completed"]
        print("PASS: test_trace_store_records_and_summarizes")
    finally:
        shutil.rmtree(tmpdir)


def test_mcp_manifest_and_filesystem_connector_are_bounded():
    tmpdir = tempfile.mkdtemp()
    try:
        tools_dir = os.path.join(tmpdir, "tools")
        os.makedirs(tools_dir, exist_ok=True)
        yaml_content = "\n".join(
            [
                "name: file_read",
                "description: read file content",
                "category: research",
                "command_template: cat {path}",
                "timeout_seconds: 30",
                "max_output_bytes: 1000",
                "sandbox: true",
                "enabled: true",
                "risk_level: low",
            ]
        )
        with open(os.path.join(tools_dir, "file_read.yaml"), "w", encoding="utf-8") as handle:
            handle.write(yaml_content)
        registry = ToolRegistry(tools_dir)
        manifest = build_mcp_tool_manifest(registry)
        assert manifest["server_name"] == "queen-local-tools"
        assert manifest["tools"][0]["name"] == "file_read"

        repo = os.path.join(tmpdir, "repo")
        os.makedirs(repo, exist_ok=True)
        with open(os.path.join(repo, "notes.txt"), "w", encoding="utf-8") as handle:
            handle.write("hello queen")
        listed = list_files(repo)
        assert listed["ok"] is True and listed["entries"]
        content = read_text(repo, "notes.txt")
        assert content["ok"] is True and "hello queen" in content["content"]
        escaped = read_text(repo, "../secret.txt")
        assert escaped["ok"] is False

        fs_manifest = build_filesystem_server_manifest(repo, read_only=True)
        assert fs_manifest["read_only"] is True and "fs.read" in fs_manifest["capabilities"]
        print("PASS: test_mcp_manifest_and_filesystem_connector_are_bounded")
    finally:
        shutil.rmtree(tmpdir)


def test_prompt_builder_includes_memory_context():
    job = {
        "job_type": "codegen",
        "payload": {
            "goal_title": "Fix auth",
            "description": "Patch bearer handling",
            "execution_contract": {"qa_required": True},
            "repo_context": "- queen_core/auth_middleware.py",
            "repo_map": "- queen_core/auth_middleware.py",
            "memory_context": "=== Mémoire durable utile (Greffe G) ===\n- [run_outcome:run_auth] Auth flow stabilisé",
        },
    }
    _system, user = build_prompt(job)
    assert "Mémoire durable utile" in user and "run_auth" in user
    print("PASS: test_prompt_builder_includes_memory_context")


if __name__ == "__main__":
    test_long_term_memory_search_and_context()
    test_trace_store_records_and_summarizes()
    test_mcp_manifest_and_filesystem_connector_are_bounded()
    test_prompt_builder_includes_memory_context()
    print("All Greffe G tests passed")
