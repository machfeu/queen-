"""Greffe D — tests de code intelligence minimale."""

import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from queen_core.code_search.fast_index import FastCodeSearchIndex
from queen_core.code_search.semantic_repo import SemanticRepoSearchWorker
from queen_core.code_search.agent_fusion import build_repo_context_bundle
from queen_core.prompt_builder import build_prompt


def _make_workspace() -> str:
    tmpdir = tempfile.mkdtemp()
    files = {
        "queen_core/auth_middleware.py": """
from fastapi import Request

def check_auth(request: Request) -> bool:
    token = request.headers.get('Authorization', '')
    return token.startswith('Bearer ')
""",
        "queen_core/policy.py": """
# policy helpers

def validate_goal_constraints(goal):
    return True
""",
        "README.md": "Project Queen with auth middleware and policy validation.\n",
    }
    for rel, content in files.items():
        full = os.path.join(tmpdir, rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as handle:
            handle.write(content.strip() + "\n")
    return tmpdir


def test_fast_index_finds_auth_file():
    workspace = _make_workspace()
    try:
        index = FastCodeSearchIndex(workspace)
        hits = index.search("auth middleware bearer token", max_results=3)
        assert hits, "Expected lexical hits"
        assert hits[0]["path"] == "queen_core/auth_middleware.py"
        print("PASS: test_fast_index_finds_auth_file")
    finally:
        shutil.rmtree(workspace)


def test_semantic_search_ranks_policy_for_constraints():
    workspace = _make_workspace()
    try:
        searcher = SemanticRepoSearchWorker(workspace)
        hits = searcher.search("validate goal constraints policy", max_results=3)
        assert hits, "Expected semantic hits"
        paths = [row["path"] for row in hits]
        assert "queen_core/policy.py" in paths[:2], paths
        print("PASS: test_semantic_search_ranks_policy_for_constraints")
    finally:
        shutil.rmtree(workspace)


def test_agent_fusion_builds_repo_context():
    workspace = _make_workspace()
    try:
        payload = {
            "goal_title": "Fix auth flow",
            "description": "Review queen_core/auth_middleware.py and improve bearer token handling",
            "success_criteria": "Auth middleware remains compatible and secure",
        }
        bundle = build_repo_context_bundle(workspace, payload, max_chars=1200)
        assert bundle["top_paths"], bundle
        assert "queen_core/auth_middleware.py" in bundle["top_paths"][:3]
        assert "Contexte repo ciblé" in bundle["context_text"]
        print("PASS: test_agent_fusion_builds_repo_context")
    finally:
        shutil.rmtree(workspace)


def test_prompt_builder_includes_repo_context():
    job = {
        "job_type": "codegen",
        "payload": {
            "goal_title": "Fix auth",
            "description": "Patch auth flow",
            "execution_contract": {"job_type": "codegen", "expected_inputs": []},
            "repo_context": "=== Contexte repo ciblé (Greffe D) ===\n- queen_core/auth_middleware.py",
        },
    }
    _, user = build_prompt(job)
    assert "Contexte repo ciblé" in user
    assert "queen_core/auth_middleware.py" in user
    print("PASS: test_prompt_builder_includes_repo_context")


if __name__ == "__main__":
    tests = [
        test_fast_index_finds_auth_file,
        test_semantic_search_ranks_policy_for_constraints,
        test_agent_fusion_builds_repo_context,
        test_prompt_builder_includes_repo_context,
    ]
    failed = 0
    for test in tests:
        try:
            test()
        except Exception as exc:
            failed += 1
            print(f"FAIL: {test.__name__} — {exc}")
            import traceback; traceback.print_exc()
    if failed:
        raise SystemExit(1)
    print("ALL GREFFE D TESTS PASSED")
