"""Tests Greffe I — browser / UI operator frugaux."""
from __future__ import annotations

import os
import sys
import types

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Greffe I: le worker importe redis_bus au chargement. On fournit un stub
# minimal pour éviter une dépendance externe dans ce test local.
redis_stub = types.SimpleNamespace(ConnectionPool=types.SimpleNamespace(from_url=lambda *a, **k: object()), Redis=lambda *a, **k: object(), ConnectionError=Exception)
sys.modules.setdefault('redis', redis_stub)

from queen_core.mcp.client_tools import build_browser_client_tool_manifest
from queen_core.prompt_builder import build_prompt
from queen_core.typed_outputs.contracts import apply_typed_contract
from queen_core.ui_automation.visual_planning import VisualTaskPlanner
from queen_core.web.ai_commands import AiCommandExecutor
from queen_core.web.daemon_bridge import BrowserDaemonBridge
from queen_core.web.snapshot_refs import create_snapshot_ref
from queen_core.web.stream_preview import StreamPreviewBridge
from queen_core.web_agent.extraction import StructuredResultExtractor
from workers.worker_unified import UnifiedWorker


def test_browser_bridge_blocks_out_of_scope_url():
    bridge = BrowserDaemonBridge(allowed_domains=['example.com'])
    plan = bridge.build_plan('Lire la page', start_url='https://evil.test/admin', extract_targets=['title'])
    assert plan['warnings'] and 'hors périmètre' in plan['warnings'][0]
    print('PASS: test_browser_bridge_blocks_out_of_scope_url')


def test_snapshot_ref_and_preview_are_stable():
    snap = create_snapshot_ref('Bonjour Queen navigateur', url='https://example.com', title='Accueil')
    preview = StreamPreviewBridge().build_preview([{'action': 'open', 'value': 'https://example.com'}], [snap])
    assert snap['snapshot_ref'].startswith('snap_')
    assert 'open' in preview['preview']
    print('PASS: test_snapshot_ref_and_preview_are_stable')


def test_visual_planner_and_ai_command_are_bounded():
    plan = VisualTaskPlanner().build_plan('Cliquer le bouton de recherche', targets=[{'action': 'click', 'selector': '#search', 'label': 'Recherche'}])
    cmd = AiCommandExecutor().build('page.extract', 'main_content')
    assert plan['actions'][0]['selector'] == '#search'
    assert cmd['ok'] is True
    assert AiCommandExecutor().build('rm -rf', 'oops')['ok'] is False
    print('PASS: test_visual_planner_and_ai_command_are_bounded')


def test_worker_handles_browser_and_ui_operator_jobs():
    worker = UnifiedWorker()
    browser = worker.handle_browser({
        'id': 'job_browser_1',
        'job_type': 'browser',
        'payload': {
            'goal_title': 'Explorer la doc',
            'description': 'Lire la page de démarrage',
            'start_url': 'https://example.com/docs',
            'allowed_domains': ['example.com'],
            'extract_targets': ['doc', 'guide'],
            'page_text': 'Example documentation guide and API overview',
        },
    })
    assert browser['_schema'] == 'browser'
    assert browser['plan']['actions'][0]['action'] == 'open'

    ui = worker.handle_ui_operator({
        'id': 'job_ui_1',
        'job_type': 'ui_operator',
        'payload': {
            'goal_title': 'Interagir avec le formulaire',
            'description': 'Cliquer le champ email',
            'visual_targets': [{'action': 'click', 'selector': '#email', 'label': 'Email'}],
        },
    })
    assert ui['_schema'] == 'ui_operator'
    assert ui['actions'][0]['selector'] == '#email'
    print('PASS: test_worker_handles_browser_and_ui_operator_jobs')


def test_prompt_builder_and_client_manifest_cover_new_jobs():
    _system, user = build_prompt({
        'job_type': 'browser',
        'payload': {
            'goal_title': 'Collecter les infos',
            'description': 'Lire une page bornée',
            'start_url': 'https://example.com',
            'allowed_domains': ['example.com'],
            'execution_contract': {'stage': 'navigation'},
            'repo_context': '- web worker',
            'memory_context': 'Aucun souvenir',
        },
    })
    manifest = build_browser_client_tool_manifest()
    normalized = apply_typed_contract('ui_operator', {'actions': [{'action': 'inspect'}], 'summary': 'ok'})
    assert 'Domaines autorisés' in user
    assert manifest['server_name'] == 'queen-browser-client-tools'
    assert normalized['_schema_valid'] is True
    print('PASS: test_prompt_builder_and_client_manifest_cover_new_jobs')


if __name__ == '__main__':
    test_browser_bridge_blocks_out_of_scope_url()
    test_snapshot_ref_and_preview_are_stable()
    test_visual_planner_and_ai_command_are_bounded()
    test_worker_handles_browser_and_ui_operator_jobs()
    test_prompt_builder_and_client_manifest_cover_new_jobs()
    print('All Greffe I tests passed')
