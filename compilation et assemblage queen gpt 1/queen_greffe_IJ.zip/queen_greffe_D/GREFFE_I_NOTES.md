# Greffe I — Browser / UI operator minimal

## Source et intention
- Source lot: lots 5 et 10 browser / computer-use / UI operator
- README consultés: `README_LOT_10.md`, `INTEGRATION_NOTES.md`, briques agent-browser / Midscene / Open Operator / HyperAgent
- Approche choisie: greffe frugale et locale, sans vrai navigateur, sans daemon externe, sans Playwright actif

## Version antérieure
- Aucune couche browser/operator exploitable dans le tronc
- Pas de job type dédié pour navigation ou interaction visuelle

## Améliorations apportées
- ajout des job types `browser` et `ui_operator`
- ajout d'un pont navigateur sec (`BrowserDaemonBridge`)
- ajout de snapshots textuels et d'un aperçu de flux
- ajout d'un planificateur visuel borné
- ajout d'un manifeste MCP client orienté browser local

## Bugs rencontrés
- aucun bug bloquant structurel
- risque anticipé: ouvrir trop tôt un vrai navigateur et casser le tronc

## Fixes appliqués
- mode `dry_run` imposé partout
- validation des domaines autorisés
- commandes IA limitées à une liste blanche

## Rollback simple
- supprimer les modules `queen_core/web*`, `queen_core/ui_automation`, `queen_core/web_agent`, `queen_core/mcp/client_tools.py`
- retirer les handlers `browser` et `ui_operator` du worker
- retirer les job types des validateurs et contrats
