# GREFFE F — Notes d'intégration

## Base de départ
- archive source: tronc Greffe E en cours

## Objectif
Formaliser les transitions d'état sans remplacer l'orchestrateur actuel.

## Résumé de la greffe
- tables de transitions goals/runs/jobs/patches
- helper `update_status_guarded()`
- warnings + audit en cas de saut incohérent
- intégration douce dans orchestrator et actions

## Limite honnête
Cette greffe n'est pas un moteur externe ni un runtime distribué. Elle sert à rendre les états plus lisibles et auditables.
