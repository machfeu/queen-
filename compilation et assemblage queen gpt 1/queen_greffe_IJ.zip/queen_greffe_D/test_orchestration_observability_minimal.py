"""Tests Greffe J — orchestration externe / observabilité frugales."""
from __future__ import annotations

import os
import shutil
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from queen_core.observability.exporters import build_observability_bundle
from queen_core.orchestration.external_manifests import (
    build_dagger_pipeline_manifest,
    build_dapr_app_manifest,
    build_prefect_flow_manifest,
)
from queen_core.telemetry.trace_store import TraceStore


def test_external_manifests_are_structured():
    plan = [{'step': 1, 'job_type': 'research'}, {'step': 2, 'job_type': 'browser'}]
    prefect = build_prefect_flow_manifest('run_1', 'goal_1', plan)
    dapr = build_dapr_app_manifest()
    dagger = build_dagger_pipeline_manifest('run_1', ['plan', 'dispatch'])
    assert prefect['engine'] == 'prefect'
    assert dapr['engine'] == 'dapr'
    assert dagger['stages'] == ['plan', 'dispatch']
    print('PASS: test_external_manifests_are_structured')


def test_trace_store_builds_observability_exports():
    tmpdir = tempfile.mkdtemp()
    try:
        traces = TraceStore(tmpdir)
        trace_id = traces.new_trace_id('run')
        traces.record_event(trace_id, 'run_started', {'goal_id': 'goal_1'})
        traces.record_event(trace_id, 'browser_planned', {'steps': 4})
        bundle = traces.build_observability_exports(trace_id, {'run_id': 'run_1', 'goal_id': 'goal_1', 'goal_title': 'Explorer le web', 'status': 'planned', 'job_count': 2})
        assert bundle['helicone']['request']['events'] == 2
        assert bundle['langwatch']['trace']['trace_id'] == trace_id
        assert bundle['agentneo']['agent_run']['goal_title'] == 'Explorer le web'
        print('PASS: test_trace_store_builds_observability_exports')
    finally:
        shutil.rmtree(tmpdir)


def test_observability_bundle_is_pure_data():
    bundle = build_observability_bundle({'run_id': 'run_2', 'status': 'ok'}, {'trace_id': 'trace_2', 'events': 3, 'event_types': ['a', 'b'], 'first_timestamp': 't1', 'last_timestamp': 't2'})
    assert set(bundle.keys()) == {'helicone', 'langwatch', 'agentneo'}
    print('PASS: test_observability_bundle_is_pure_data')


if __name__ == '__main__':
    test_external_manifests_are_structured()
    test_trace_store_builds_observability_exports()
    test_observability_bundle_is_pure_data()
    print('All Greffe J tests passed')
