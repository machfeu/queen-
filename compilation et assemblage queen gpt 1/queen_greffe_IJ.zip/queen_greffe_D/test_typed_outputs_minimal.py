"""Tests Greffe H — sorties typées frugales."""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from queen_core.typed_outputs.contracts import apply_typed_contract


def test_research_contract_normalizes_lists_and_summary():
    result = apply_typed_contract(
        "research",
        {"analysis": "ok", "findings": "f1", "recommendations": ["r1"], "summary": "done"},
    )
    assert result["_schema_valid"] is True
    assert result["findings"] == ["f1"]
    print("PASS: test_research_contract_normalizes_lists_and_summary")


def test_codegen_contract_flags_missing_artifact_content():
    result = apply_typed_contract(
        "codegen",
        {"artifacts": [{"path": "app.py", "content": "", "description": "empty"}], "summary": "test"},
    )
    assert result["_schema_valid"] is False
    assert "artifact_0_missing_content" in result["_schema_errors"]
    print("PASS: test_codegen_contract_flags_missing_artifact_content")


def test_eval_contract_clamps_score_and_verdict():
    result = apply_typed_contract("eval", {"score": 7.5, "verdict": "maybe"})
    assert result["score"] == 1.0
    assert result["verdict"] == "retry"
    assert result["_schema_valid"] is False
    print("PASS: test_eval_contract_clamps_score_and_verdict")


def test_patch_contract_collects_files_changed():
    result = apply_typed_contract(
        "patch",
        {
            "artifacts": [{"path": "queen_core/x.py", "content": "print(1)", "description": "x"}],
            "summary": "one file",
            "notes": "ok",
        },
    )
    assert result["_schema"] == "patch"
    assert result["artifacts"][0]["path"] == "queen_core/x.py"
    print("PASS: test_patch_contract_collects_files_changed")


if __name__ == "__main__":
    test_research_contract_normalizes_lists_and_summary()
    test_codegen_contract_flags_missing_artifact_content()
    test_eval_contract_clamps_score_and_verdict()
    test_patch_contract_collects_files_changed()
    print("All Greffe H tests passed")
