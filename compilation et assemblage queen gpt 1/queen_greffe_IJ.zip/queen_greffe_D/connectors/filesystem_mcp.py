"""filesystem_mcp.py — connecteur local de filesystem borné au workspace.

Greffe G:
- première brique MCP utile sans réseau
- suffisamment stricte pour servir de base future à un vrai serveur MCP
"""
from __future__ import annotations

import os
from typing import Dict, List, Tuple


BLOCKED_NAMES = {".git", ".env", "__pycache__", ".pytest_cache"}


def _resolve_safe_path(workspace_root: str, rel_path: str = "") -> Tuple[bool, str, str]:
    rel_path = (rel_path or "").replace("\\", "/").lstrip("/")
    if any(part in BLOCKED_NAMES for part in rel_path.split("/") if part):
        return False, "blocked_path_segment", ""
    candidate = os.path.realpath(os.path.join(workspace_root, rel_path))
    root = os.path.realpath(workspace_root)
    try:
        common = os.path.commonpath([root, candidate])
    except ValueError:
        return False, "invalid_path", ""
    if common != root:
        return False, "path_escapes_workspace", ""
    return True, "ok", candidate


def list_files(workspace_root: str, rel_path: str = "", max_entries: int = 100) -> Dict[str, object]:
    ok, reason, target = _resolve_safe_path(workspace_root, rel_path)
    if not ok:
        return {"ok": False, "error": reason, "entries": []}
    if not os.path.isdir(target):
        return {"ok": False, "error": "not_a_directory", "entries": []}
    entries: List[Dict[str, object]] = []
    for name in sorted(os.listdir(target)):
        if name in BLOCKED_NAMES:
            continue
        full = os.path.join(target, name)
        rel = os.path.relpath(full, workspace_root).replace("\\", "/")
        entries.append(
            {
                "name": name,
                "path": rel,
                "is_dir": os.path.isdir(full),
                "size": 0 if os.path.isdir(full) else os.path.getsize(full),
            }
        )
        if len(entries) >= max_entries:
            break
    return {"ok": True, "entries": entries}


def read_text(workspace_root: str, rel_path: str, max_bytes: int = 65536) -> Dict[str, object]:
    ok, reason, target = _resolve_safe_path(workspace_root, rel_path)
    if not ok:
        return {"ok": False, "error": reason}
    if not os.path.isfile(target):
        return {"ok": False, "error": "not_a_file"}
    with open(target, "rb") as handle:
        content = handle.read(max_bytes + 1)
    truncated = len(content) > max_bytes
    content = content[:max_bytes]
    return {
        "ok": True,
        "path": os.path.relpath(target, workspace_root).replace("\\", "/"),
        "content": content.decode("utf-8", errors="replace"),
        "truncated": truncated,
    }
