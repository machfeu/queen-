# GREFFE E — Notes d'intégration

## Base de départ
- archive source: `queen_greffe_D.zip`
- tronc fonctionnel: Greffes A + B + C + D déjà intégrées

## Objectif
Ajouter une action code plus propre, inspirée des idées OpenHands/Aider, sans remplacer le cœur ni brancher une autonomie dangereuse.

## Résumé de la greffe
- repo map locale frugale
- diff presenter
- patch review bornée branchée dans les gates
- workspace provider explicite
- prompts et workers enrichis avec `repo_map`

## Bugs rencontrés pendant la greffe
- aucun bug bloquant de logique métier
- vigilance sur la taille des prompts après ajout de `repo_map`

## Fixes appliqués
- repo map bornée en profondeur et en nombre d'entrées
- gate `diff_review` séparé et structuré
- provider workspace minimal pour préparer les futures extensions sans casser le tronc

## Limite honnête
Cette greffe ne fournit pas encore:
- une boucle git complète
- un vrai branching
- un agent logiciel multi-outils type OpenHands
- une repo map avancée type Aider
