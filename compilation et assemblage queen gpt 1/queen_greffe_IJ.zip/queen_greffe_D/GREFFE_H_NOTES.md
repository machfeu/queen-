# GREFFE H — Lot 6 typage de sorties frugal

## Objectif
Fiabiliser les sorties des jobs sans introduire de dépendance externe lourde.

## Résumé
- contrats de sortie typés stdlib ajoutés
- normalisation research / codegen / eval / patch
- validation permissive: erreurs annotées au lieu de casser brutalement le pipeline
- intégration dans les workers pour que les résultats aient une forme plus stable

## Limite volontaire
La partie GraphRAG / connaissance relationnelle reste reportée. Cette greffe couvre seulement la partie la plus rentable du lot 6 maintenant: les sorties typées.
