# GREFFE G — Lot 4 mémoire / traces / MCP utile

## Objectif
Ajouter une couche locale et frugale de mémoire durable, de traces exploitables et de protocole MCP minimal sans introduire de service externe ni remplacer le cœur de Queen.

## Résumé
- mémoire longue portée SQLite locale ajoutée
- traces JSONL locales ajoutées
- manifeste MCP minimal pour les outils + connecteur filesystem borné ajouté
- injection de mémoire durable dans les prompts des workers
- persistance d'un résumé de run dans la mémoire durable après évaluation

## Fichiers ajoutés
- queen_core/memories/__init__.py
- queen_core/memories/long_term_store.py
- queen_core/telemetry/__init__.py
- queen_core/telemetry/trace_store.py
- queen_core/mcp/__init__.py
- queen_core/mcp/protocol.py
- connectors/__init__.py
- connectors/filesystem_mcp.py
- test_memory_trace_mcp_minimal.py
- docs/greffes/greffe_G/*

## Fichiers modifiés
- queen_core/orchestrator.py
- workers/worker_unified.py
- queen_core/prompt_builder.py
- README_SUIVI_GREFFES.md

## Bugs rencontrés
- collision conceptuelle entre `queen_core/memory.py` et un futur package `queen_core/memory/`.
- risque de dépendance forte à une stack externe type Langfuse / Mem0 trop tôt.

## Fixes appliqués
- création d'un package distinct `queen_core/memories/` pour éviter toute collision Python.
- traces locales JSONL au lieu d'une dépendance observabilité externe.
- MCP réduit à un manifeste standard minimal + connecteur borné au workspace.

## Validation
- compilation Python OK
- tests Greffe G dédiés OK
- non-régression A/B/C/D/E/F OK

## Rollback simple
Supprimer les imports Greffe G dans `orchestrator.py`, `worker_unified.py`, `prompt_builder.py`, puis retirer:
- `queen_core/memories/`
- `queen_core/telemetry/`
- `queen_core/mcp/`
- `connectors/filesystem_mcp.py`
- `test_memory_trace_mcp_minimal.py`
