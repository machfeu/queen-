"""Greffe J — exports d'observabilité frugaux."""
