"""exporters.py — export frugal vers observabilité avancée.

Greffe J prépare des payloads pour Helicone, LangWatch et AgentNeo
sans dépendances ni appels réseau.
"""
from __future__ import annotations

from typing import Any, Dict, List


def build_helicone_payload(run_meta: Dict[str, Any], trace_summary: Dict[str, Any]) -> Dict[str, Any]:
    return {
        'target': 'helicone',
        'request': {
            'run_id': run_meta.get('run_id', ''),
            'goal_id': run_meta.get('goal_id', ''),
            'job_count': run_meta.get('job_count', 0),
            'events': trace_summary.get('events', 0),
        },
    }


def build_langwatch_payload(run_meta: Dict[str, Any], trace_summary: Dict[str, Any]) -> Dict[str, Any]:
    return {
        'target': 'langwatch',
        'trace': {
            'trace_id': trace_summary.get('trace_id', ''),
            'event_types': trace_summary.get('event_types', []),
            'status': run_meta.get('status', 'unknown'),
        },
    }


def build_agentneo_payload(run_meta: Dict[str, Any], trace_summary: Dict[str, Any]) -> Dict[str, Any]:
    return {
        'target': 'agentneo',
        'agent_run': {
            'run_id': run_meta.get('run_id', ''),
            'goal_title': run_meta.get('goal_title', ''),
            'events': trace_summary.get('events', 0),
            'window': [trace_summary.get('first_timestamp', ''), trace_summary.get('last_timestamp', '')],
        },
    }


def build_observability_bundle(run_meta: Dict[str, Any], trace_summary: Dict[str, Any]) -> Dict[str, Any]:
    return {
        'helicone': build_helicone_payload(run_meta, trace_summary),
        'langwatch': build_langwatch_payload(run_meta, trace_summary),
        'agentneo': build_agentneo_payload(run_meta, trace_summary),
    }
