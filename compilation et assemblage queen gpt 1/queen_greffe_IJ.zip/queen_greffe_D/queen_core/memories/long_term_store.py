"""long_term_store.py — mémoire durable frugale pour Queen.

Greffe G:
- ajoute une mémoire longue portée locale sans service externe
- stocke des résumés réutilisables des runs / goals / notes manuelles
- fournit une recherche lexicale bornée pour enrichir les prompts

Le design reste volontairement simple:
- SQLite local, table autonome
- scoring lexical + légère pondération d'importance
- aucun vector store externe, aucun daemon
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import threading
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional

_TOKEN_RE = re.compile(r"[a-zA-Z0-9_\-/]{2,}")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _tokenize(value: str) -> List[str]:
    return [token.lower() for token in _TOKEN_RE.findall(value or "")]


def derive_memory_query(payload: Dict[str, Any] | str | None) -> str:
    """Construit une requête mémoire frugale à partir d'un payload de job."""
    if isinstance(payload, str):
        return payload.strip()
    payload = payload or {}
    parts: List[str] = []
    for key in ("goal_title", "goal_description", "description", "success_criteria"):
        value = payload.get(key)
        if value:
            parts.append(str(value))
    meta = payload.get("repo_context_meta", {}) or {}
    top_paths = meta.get("top_paths", []) or []
    if top_paths:
        parts.append(" ".join(str(path) for path in top_paths[:5]))
    if not parts:
        parts.append(str(payload.get("title", "")))
    return " | ".join(part for part in parts if part).strip()


class LongTermMemoryStore:
    """Stockage mémoire durable local basé sur SQLite.

    Cette brique complète `queen_core.memory.Memory` sans la remplacer:
    - `Memory` garde la persistance transactionnelle du pipeline
    - `LongTermMemoryStore` garde des résumés réutilisables et recherchables
    """

    def __init__(self, db_path: str = "/data/queen.db"):
        self.db_path = db_path
        db_dir = os.path.dirname(db_path) or "."
        os.makedirs(db_dir, exist_ok=True)
        self._lock = threading.Lock()
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        with self._lock:
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS long_term_memory (
                    id TEXT PRIMARY KEY,
                    source_type TEXT NOT NULL,
                    source_id TEXT DEFAULT '',
                    title TEXT DEFAULT '',
                    content TEXT NOT NULL,
                    tags TEXT DEFAULT '[]',
                    importance REAL DEFAULT 0.5,
                    metadata TEXT DEFAULT '{}',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_ltm_source ON long_term_memory(source_type, source_id);
                CREATE INDEX IF NOT EXISTS idx_ltm_created ON long_term_memory(created_at DESC);
                """
            )
            self.conn.commit()

    def remember(
        self,
        content: str,
        *,
        source_type: str,
        source_id: str = "",
        title: str = "",
        tags: Optional[Iterable[str]] = None,
        importance: float = 0.5,
        metadata: Optional[Dict[str, Any]] = None,
        entry_id: str = "",
    ) -> str:
        """Ajoute un souvenir durable réutilisable dans les prompts futurs."""
        now = _utc_now()
        entry_id = entry_id or f"mem_{uuid.uuid4().hex[:10]}"
        payload = (
            entry_id,
            source_type,
            source_id,
            title,
            content,
            json.dumps(list(tags or []), ensure_ascii=False),
            max(0.0, min(float(importance), 1.0)),
            json.dumps(metadata or {}, ensure_ascii=False),
            now,
            now,
        )
        with self._lock:
            self.conn.execute(
                """
                INSERT OR REPLACE INTO long_term_memory
                (id, source_type, source_id, title, content, tags, importance, metadata, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                payload,
            )
            self.conn.commit()
        return entry_id

    def list_recent(self, limit: int = 20) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self.conn.execute(
                "SELECT * FROM long_term_memory ORDER BY created_at DESC LIMIT ?",
                (max(1, int(limit)),),
            ).fetchall()
        return [self._row_to_dict(row) for row in rows]

    def search(self, query: str, limit: int = 5, min_score: float = 0.08) -> List[Dict[str, Any]]:
        """Recherche frugale: recouvrement lexical + importance."""
        q_tokens = set(_tokenize(query))
        if not q_tokens:
            return []
        with self._lock:
            rows = self.conn.execute(
                "SELECT * FROM long_term_memory ORDER BY created_at DESC LIMIT 200"
            ).fetchall()
        scored: List[Dict[str, Any]] = []
        for row in rows:
            item = self._row_to_dict(row)
            haystack = " ".join([
                item.get("title", ""),
                item.get("content", ""),
                " ".join(item.get("tags", [])),
            ])
            doc_tokens = set(_tokenize(haystack))
            if not doc_tokens:
                continue
            overlap = q_tokens.intersection(doc_tokens)
            if not overlap:
                continue
            lexical = len(overlap) / max(len(q_tokens), 1)
            score = lexical + float(item.get("importance", 0.5)) * 0.15
            item["score"] = round(score, 4)
            item["matched_terms"] = sorted(overlap)
            if score >= min_score:
                scored.append(item)
        scored.sort(key=lambda row: (row.get("score", 0.0), row.get("created_at", "")), reverse=True)
        return scored[: max(1, int(limit))]

    def build_context(self, payload: Dict[str, Any] | str | None, limit: int = 4, max_chars: int = 1200) -> str:
        query = derive_memory_query(payload)
        hits = self.search(query, limit=limit)
        if not hits:
            return "Aucun souvenir durable utile retrouvé."

        lines = ["=== Mémoire durable utile (Greffe G) ==="]
        total = len(lines[0])
        for hit in hits:
            snippet = (hit.get("content", "") or "").replace("\n", " ").strip()
            if len(snippet) > 220:
                snippet = snippet[:217].rstrip() + "..."
            line = f"- [{hit['source_type']}:{hit.get('source_id', '')}] {hit.get('title', '')}: {snippet}"
            if total + len(line) > max_chars:
                break
            lines.append(line)
            total += len(line)
        return "\n".join(lines)

    def remember_run_outcome(
        self,
        goal: Dict[str, Any],
        run: Dict[str, Any],
        eval_result: Dict[str, Any],
        qa_report: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Convertit un run terminé en souvenir durable réutilisable."""
        verdict = eval_result.get("verdict", "unknown")
        score = eval_result.get("score", 0.0)
        title = f"{goal.get('title', 'Goal')} | verdict={verdict}"
        findings = eval_result.get("findings") or eval_result.get("justification") or ""
        blocking = []
        if qa_report and not qa_report.get("passed", True):
            blocking = qa_report.get("blocking_reasons", []) or []
        content = (
            f"Objectif: {goal.get('title', '')}\n"
            f"Description: {goal.get('description', '')}\n"
            f"Verdict: {verdict}\n"
            f"Score: {score}\n"
            f"Évaluation: {findings}\n"
            f"Blocages QA: {blocking}\n"
            f"Plan steps: {len(run.get('plan', []) or [])}"
        )
        tags = ["run", verdict, goal.get("constraints", {}).get("role", "")]
        metadata = {
            "run_id": run.get("id", ""),
            "goal_id": goal.get("id", ""),
            "score": score,
            "verdict": verdict,
            "qa_passed": bool((qa_report or {}).get("passed", True)),
        }
        return self.remember(
            content,
            source_type="run_outcome",
            source_id=run.get("id", ""),
            title=title,
            tags=[tag for tag in tags if tag],
            importance=0.55 if verdict == "approve" else 0.75,
            metadata=metadata,
        )

    @staticmethod
    def _row_to_dict(row: sqlite3.Row) -> Dict[str, Any]:
        data = dict(row)
        try:
            data["tags"] = json.loads(data.get("tags") or "[]")
        except Exception:
            data["tags"] = []
        try:
            data["metadata"] = json.loads(data.get("metadata") or "{}")
        except Exception:
            data["metadata"] = {}
        return data
