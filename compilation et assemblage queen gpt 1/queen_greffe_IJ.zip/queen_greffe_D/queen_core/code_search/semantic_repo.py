"""semantic_repo.py — recherche sémantique locale frugale."""

from __future__ import annotations

import os
from collections import Counter
from dataclasses import dataclass
from typing import Dict, List, Sequence

from queen_core.code_search.fast_index import DEFAULT_EXCLUDE_DIRS, DEFAULT_INCLUDE_EXTENSIONS, _extract_matching_lines, _tokenize


@dataclass
class RepoDocument:
    path: str
    tokens: Counter
    preview_lines: List[str]


class PerRepoIndexStore:
    def __init__(self, workspace_root: str, include_extensions: Sequence[str] | None = None, exclude_dirs: Sequence[str] | None = None, max_file_bytes: int = 200_000):
        self.workspace_root = os.path.realpath(workspace_root)
        self.include_extensions = {e.lower() for e in (include_extensions or DEFAULT_INCLUDE_EXTENSIONS)}
        self.exclude_dirs = set(exclude_dirs or DEFAULT_EXCLUDE_DIRS)
        self.max_file_bytes = max(2_000, int(max_file_bytes))
        self.documents: List[RepoDocument] = []
        self.rebuild()

    def rebuild(self) -> None:
        self.documents = []
        if not os.path.isdir(self.workspace_root):
            return
        for root, dirs, files in os.walk(self.workspace_root):
            dirs[:] = [d for d in dirs if d not in self.exclude_dirs]
            for filename in files:
                ext = os.path.splitext(filename)[1].lower()
                if ext and ext not in self.include_extensions:
                    continue
                full_path = os.path.join(root, filename)
                try:
                    size = os.path.getsize(full_path)
                except OSError:
                    continue
                if size > self.max_file_bytes:
                    continue
                try:
                    with open(full_path, "r", encoding="utf-8") as handle:
                        content = handle.read()
                except (OSError, UnicodeDecodeError):
                    continue
                rel_path = os.path.relpath(full_path, self.workspace_root).replace("\\", "/")
                tokens = Counter(_tokenize(rel_path + "\n" + content))
                preview_lines = [line for line in content.splitlines()[:12] if line.strip()][:4]
                self.documents.append(RepoDocument(path=rel_path, tokens=tokens, preview_lines=preview_lines))


class SemanticRepoSearchWorker:
    def __init__(self, workspace_root: str):
        self.store = PerRepoIndexStore(workspace_root)

    def search(self, query: str, max_results: int = 6) -> List[Dict[str, object]]:
        query_tokens = _tokenize(query)
        if not query_tokens:
            return []
        results: List[Dict[str, object]] = []
        for doc in self.store.documents:
            overlap = 0.0
            path_bonus = 0.0
            for token in query_tokens:
                freq = doc.tokens.get(token, 0)
                if not freq:
                    continue
                overlap += min(3.0, 1.0 + freq * 0.2)
                if token in doc.path.lower():
                    path_bonus += 0.75
            if not overlap:
                continue
            snippet_lines = _extract_matching_lines(doc.preview_lines, tokens=query_tokens, regex=None)
            results.append({"path": doc.path, "score": round(overlap + path_bonus, 3), "mode": "semantic_local", "matched_terms": [token for token in query_tokens if doc.tokens.get(token)], "snippets": snippet_lines})
        results.sort(key=lambda row: (-float(row.get("score", 0.0)), row.get("path", "")))
        return results[: max(1, int(max_results))]
