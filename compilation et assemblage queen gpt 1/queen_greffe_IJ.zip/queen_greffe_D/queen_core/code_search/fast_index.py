"""fast_index.py — index lexical rapide du dépôt.

Greffe D / plug D1.
Objectif: donner à Queen une recherche locale simple, rapide et bornée,
avant toute intégration d'un vrai moteur externe type Zoekt.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Dict, List, Sequence

DEFAULT_INCLUDE_EXTENSIONS = {".py", ".md", ".txt", ".yaml", ".yml", ".json", ".toml", ".ini", ".cfg"}
DEFAULT_EXCLUDE_DIRS = {".git", ".hg", ".svn", "__pycache__", ".pytest_cache", ".mypy_cache", "node_modules", ".venv", "venv", "dist", "build", ".idea", ".vscode"}
STOPWORDS = {"the", "and", "for", "with", "from", "into", "this", "that", "then", "else", "des", "les", "une", "dans", "pour", "avec", "sans", "plus", "moins", "code", "queen", "projet", "task", "job", "goal", "fix", "file", "fichier"}


@dataclass
class IndexedFile:
    path: str
    size: int
    content: str
    lines: List[str]


class FastCodeSearchIndex:
    def __init__(self, workspace_root: str, include_extensions: Sequence[str] | None = None, exclude_dirs: Sequence[str] | None = None, max_file_bytes: int = 200_000):
        self.workspace_root = os.path.realpath(workspace_root)
        self.include_extensions = {e.lower() for e in (include_extensions or DEFAULT_INCLUDE_EXTENSIONS)}
        self.exclude_dirs = set(exclude_dirs or DEFAULT_EXCLUDE_DIRS)
        self.max_file_bytes = max(2_000, int(max_file_bytes))
        self._files: List[IndexedFile] = []
        self._build_index()

    def _build_index(self) -> None:
        self._files = []
        if not os.path.isdir(self.workspace_root):
            return
        for root, dirs, files in os.walk(self.workspace_root):
            dirs[:] = [d for d in dirs if d not in self.exclude_dirs]
            for filename in files:
                ext = os.path.splitext(filename)[1].lower()
                if ext and ext not in self.include_extensions:
                    continue
                full_path = os.path.join(root, filename)
                try:
                    size = os.path.getsize(full_path)
                except OSError:
                    continue
                if size > self.max_file_bytes:
                    continue
                try:
                    with open(full_path, "r", encoding="utf-8") as handle:
                        content = handle.read()
                except (OSError, UnicodeDecodeError):
                    continue
                rel_path = os.path.relpath(full_path, self.workspace_root).replace("\\", "/")
                self._files.append(IndexedFile(path=rel_path, size=size, content=content, lines=content.splitlines()))

    def search(self, query: str, max_results: int = 6, regex: bool = False) -> List[Dict[str, object]]:
        query = (query or "").strip()
        if not query:
            return []
        tokens = _tokenize(query)
        pattern = re.compile(query, re.IGNORECASE) if regex else None
        hits: List[Dict[str, object]] = []
        for item in self._files:
            score = 0.0
            matched_terms: List[str] = []
            lower_path = item.path.lower()
            lower_content = item.content.lower()
            if regex and pattern:
                matches = list(pattern.finditer(item.content))
                if not matches:
                    continue
                score += min(6.0, float(len(matches)))
                matched_terms.append("regex")
            else:
                for token in tokens:
                    if token in lower_path:
                        score += 2.5
                        matched_terms.append(token)
                    content_count = lower_content.count(token)
                    if content_count:
                        score += min(4.0, 1.0 + content_count * 0.35)
                        matched_terms.append(token)
                if not score:
                    continue
            snippet_lines = _extract_matching_lines(item.lines, tokens=tokens, regex=pattern)
            hits.append({"path": item.path, "score": round(score, 3), "mode": "regex" if regex else "lexical", "matched_terms": sorted(set(matched_terms))[:12], "snippets": snippet_lines})
        hits.sort(key=lambda row: (-float(row.get("score", 0.0)), row.get("path", "")))
        return hits[: max(1, int(max_results))]


class RegexAndSymbolSearchAdapter:
    def __init__(self, workspace_root: str):
        self.index = FastCodeSearchIndex(workspace_root)

    def search(self, query: str, max_results: int = 6) -> List[Dict[str, object]]:
        regex_mode = bool(query and any(ch in query for ch in (".*", "^", "$", "\\b")))
        return self.index.search(query, max_results=max_results, regex=regex_mode)


def _tokenize(text: str) -> List[str]:
    raw = re.findall(r"[A-Za-z0-9_./-]+", text.lower())
    tokens: List[str] = []
    for token in raw:
        token = token.strip("._-/")
        if len(token) < 2 or token in STOPWORDS:
            continue
        tokens.append(token)
    seen = set()
    compact = []
    for token in tokens:
        if token not in seen:
            compact.append(token)
            seen.add(token)
        if len(compact) >= 12:
            break
    return compact


def _extract_matching_lines(lines: Sequence[str], tokens: Sequence[str], regex: re.Pattern[str] | None) -> List[Dict[str, object]]:
    results: List[Dict[str, object]] = []
    lower_tokens = [token.lower() for token in tokens if token]
    for lineno, line in enumerate(lines, start=1):
        line_lower = line.lower()
        hit = False
        if regex and regex.search(line):
            hit = True
        elif lower_tokens and any(token in line_lower for token in lower_tokens):
            hit = True
        if not hit:
            continue
        results.append({"line": lineno, "text": line[:240]})
        if len(results) >= 3:
            break
    if results:
        return results
    for lineno, line in enumerate(lines[:3], start=1):
        if line.strip():
            results.append({"line": lineno, "text": line[:240]})
    return results
