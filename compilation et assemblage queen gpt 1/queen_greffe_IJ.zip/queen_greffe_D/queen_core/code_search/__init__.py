"""Code intelligence locale pour Queen.

Greffe D:
- index lexical rapide inspiré du rôle de Zoekt
- recherche sémantique frugale inspirée d'osgrep
- fusion de contexte repo inspirée d'Agent-Fusion

Aucun service externe n'est requis à ce stade.
"""

from queen_core.code_search.fast_index import FastCodeSearchIndex, RegexAndSymbolSearchAdapter
from queen_core.code_search.semantic_repo import SemanticRepoSearchWorker, PerRepoIndexStore
from queen_core.code_search.agent_fusion import AgentFusionAdapter, build_repo_context_bundle

__all__ = [
    "FastCodeSearchIndex",
    "RegexAndSymbolSearchAdapter",
    "SemanticRepoSearchWorker",
    "PerRepoIndexStore",
    "AgentFusionAdapter",
    "build_repo_context_bundle",
]
