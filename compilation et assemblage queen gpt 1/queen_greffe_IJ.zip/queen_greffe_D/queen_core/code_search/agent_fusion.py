"""agent_fusion.py — fusion de contexte repo local."""

from __future__ import annotations

import os
import re
from typing import Any, Dict, List

from queen_core.code_search.fast_index import FastCodeSearchIndex, _tokenize
from queen_core.code_search.semantic_repo import SemanticRepoSearchWorker

FILE_PATTERN = re.compile(r"[A-Za-z0-9_./-]+\.(?:py|md|txt|yaml|yml|json|toml|ini|cfg)")


class AgentFusionAdapter:
    def __init__(self, workspace_root: str):
        self.workspace_root = os.path.realpath(workspace_root)
        self.fast = FastCodeSearchIndex(self.workspace_root)
        self.semantic = SemanticRepoSearchWorker(self.workspace_root)

    def gather_context(self, payload: Dict[str, Any], max_chars: int = 2500) -> Dict[str, Any]:
        queries = _build_query_bundle(payload)
        exact_hits: List[Dict[str, Any]] = []
        semantic_hits: List[Dict[str, Any]] = []
        for query in queries:
            exact_hits.extend(self.fast.search(query, max_results=4))
            semantic_hits.extend(self.semantic.search(query, max_results=4))
        merged_hits = _merge_hits(exact_hits, semantic_hits)
        context_text = _render_context(merged_hits, max_chars=max_chars)
        return {"query_bundle": queries, "exact_hits": exact_hits[:8], "semantic_hits": semantic_hits[:8], "merged_hits": merged_hits, "context_text": context_text, "top_paths": [hit.get("path") for hit in merged_hits[:6]]}


def build_repo_context_bundle(workspace_root: str, payload: Dict[str, Any], max_chars: int = 2500) -> Dict[str, Any]:
    if not workspace_root or not os.path.isdir(workspace_root):
        return {"query_bundle": [], "exact_hits": [], "semantic_hits": [], "merged_hits": [], "context_text": "", "top_paths": []}
    return AgentFusionAdapter(workspace_root).gather_context(payload, max_chars=max_chars)


def _build_query_bundle(payload: Dict[str, Any]) -> List[str]:
    fields = [payload.get("title", ""), payload.get("description", ""), payload.get("goal_title", ""), payload.get("goal_description", ""), payload.get("success_criteria", ""), payload.get("previous_context", "")]
    joined = "\n".join(str(item) for item in fields if item)
    files_from_text = FILE_PATTERN.findall(joined)
    queries: List[str] = []
    if payload.get("description"):
        queries.append(str(payload.get("description")))
    compact_goal = " ".join(str(part) for part in (payload.get("goal_title", ""), payload.get("title", "")) if part).strip()
    if compact_goal:
        queries.append(compact_goal)
    if payload.get("success_criteria"):
        queries.append(str(payload.get("success_criteria")))
    if files_from_text:
        queries.append(" ".join(files_from_text[:4]))
    bag = _tokenize(joined)
    if bag:
        queries.append(" ".join(bag[:8]))
    cleaned: List[str] = []
    seen = set()
    for query in queries:
        query = " ".join(str(query).split())
        if len(query) < 3:
            continue
        if query not in seen:
            cleaned.append(query[:220])
            seen.add(query)
    return cleaned[:4]


def _merge_hits(exact_hits: List[Dict[str, Any]], semantic_hits: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by_path: Dict[str, Dict[str, Any]] = {}
    for source_name, hits, weight in (("exact", exact_hits, 1.0), ("semantic", semantic_hits, 0.75)):
        for hit in hits:
            path = str(hit.get("path", ""))
            if not path:
                continue
            row = by_path.setdefault(path, {"path": path, "score": 0.0, "sources": [], "matched_terms": [], "snippets": []})
            row["score"] = round(float(row.get("score", 0.0)) + float(hit.get("score", 0.0)) * weight, 3)
            row["sources"].append(source_name)
            row["matched_terms"] = sorted(set(list(row.get("matched_terms", [])) + list(hit.get("matched_terms", []))))[:12]
            if not row["snippets"]:
                row["snippets"] = list(hit.get("snippets", []))[:3]
    merged = list(by_path.values())
    merged.sort(key=lambda row: (-float(row.get("score", 0.0)), row.get("path", "")))
    return merged[:8]


def _render_context(hits: List[Dict[str, Any]], max_chars: int = 2500) -> str:
    if not hits:
        return "Aucun contexte repo ciblé trouvé."
    lines = ["=== Contexte repo ciblé (Greffe D) ==="]
    for hit in hits:
        lines.append(f"- {hit.get('path')} | score={hit.get('score')} | sources={','.join(hit.get('sources', []))} | termes={', '.join(hit.get('matched_terms', []))}")
        for snippet in hit.get("snippets", [])[:2]:
            if isinstance(snippet, dict):
                lines.append(f"  L{snippet.get('line', '?')}: {snippet.get('text', '')}")
        candidate = "\n".join(lines)
        if len(candidate) >= max_chars:
            break
    text = "\n".join(lines)
    if len(text) > max_chars:
        text = text[: max_chars - 16].rstrip() + "\n... [tronqué]"
    return text
