"""external_manifests.py — export frugal vers orchestration externe.

Greffe J:
- ne branche aucun orchestrateur externe pour de vrai
- produit des manifestes structurés compatibles avec une greffe future
- évite d'enfler le tronc trop tôt
"""
from __future__ import annotations

from typing import Any, Dict, List


def build_prefect_flow_manifest(run_id: str, goal_id: str, plan: List[Dict[str, Any]] | None = None) -> Dict[str, Any]:
    plan = list(plan or [])
    return {
        'engine': 'prefect',
        'flow_name': f'queen-run-{run_id}',
        'parameters': {'run_id': run_id, 'goal_id': goal_id},
        'tasks': [{'step': item.get('step'), 'job_type': item.get('job_type')} for item in plan],
    }


def build_dapr_app_manifest(app_id: str = 'queen-orchestrator', pubsub_name: str = 'queen-pubsub') -> Dict[str, Any]:
    return {
        'engine': 'dapr',
        'app_id': app_id,
        'pubsub': pubsub_name,
        'bindings': ['queen:jobs', 'queen:results', 'queen:events'],
    }


def build_dagger_pipeline_manifest(run_id: str, stages: List[str] | None = None) -> Dict[str, Any]:
    stages = [str(s).strip() for s in (stages or []) if str(s).strip()]
    return {
        'engine': 'dagger',
        'pipeline_name': f'queen-{run_id}',
        'stages': stages or ['plan', 'dispatch', 'evaluate', 'release'],
    }
