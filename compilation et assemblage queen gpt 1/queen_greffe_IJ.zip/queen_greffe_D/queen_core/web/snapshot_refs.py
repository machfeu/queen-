"""snapshot_refs.py — références de snapshots légères et stables."""
from __future__ import annotations

import hashlib
from typing import Any, Dict


def create_snapshot_ref(content: str, url: str = '', title: str = '', max_chars: int = 300) -> Dict[str, Any]:
    content = (content or '').strip()
    preview = content[:max(0, max_chars)]
    digest = hashlib.sha1(f'{url}|{title}|{preview}'.encode('utf-8')).hexdigest()[:12]
    return {
        'snapshot_ref': f'snap_{digest}',
        'url': url,
        'title': title,
        'preview': preview,
        'chars': len(content),
    }


class SnapshotRefResolver:
    def make(self, content: str, url: str = '', title: str = '', max_chars: int = 300) -> Dict[str, Any]:
        return create_snapshot_ref(content, url=url, title=title, max_chars=max_chars)
