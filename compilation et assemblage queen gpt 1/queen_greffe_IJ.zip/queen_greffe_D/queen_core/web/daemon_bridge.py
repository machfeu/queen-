"""daemon_bridge.py — pont frugal vers un navigateur daemonisé, en mode sec.

Greffe I:
- ne lance aucun vrai navigateur dans le tronc
- construit et nettoie un plan de navigation borné
- prépare l'arrivée d'un daemon réel plus tard (agent-browser)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List
from urllib.parse import urlparse


_ALLOWED_SCHEMES = {"http", "https"}


def _normalize_url(url: str) -> str:
    url = (url or '').strip()
    if not url:
        return ''
    parsed = urlparse(url)
    if parsed.scheme and parsed.scheme.lower() in _ALLOWED_SCHEMES:
        return url
    if not parsed.scheme:
        return f'https://{url.lstrip("/")}'
    return ''


def _domain(url: str) -> str:
    parsed = urlparse(_normalize_url(url))
    return (parsed.netloc or '').lower()


@dataclass
class BrowserAction:
    action: str
    value: str = ''
    note: str = ''

    def as_dict(self) -> Dict[str, Any]:
        return {'action': self.action, 'value': self.value, 'note': self.note}


class BrowserDaemonBridge:
    """Construit un plan navigateur sec et borné.

    On reste volontairement loin d'un vrai bridge Playwright/Selenium ici.
    La brique sert à valider les intentions, les URLs et la taille du plan.
    """

    def __init__(self, allowed_domains: List[str] | None = None, max_steps: int = 6):
        self.allowed_domains = [d.lower().strip() for d in (allowed_domains or []) if str(d).strip()]
        self.max_steps = max(1, min(int(max_steps or 6), 12))

    def is_allowed_url(self, url: str) -> bool:
        normalized = _normalize_url(url)
        if not normalized:
            return False
        if not self.allowed_domains:
            return True
        host = _domain(normalized)
        return any(host == allowed or host.endswith('.' + allowed) for allowed in self.allowed_domains)

    def build_plan(self, intent: str, start_url: str = '', extract_targets: List[str] | None = None) -> Dict[str, Any]:
        intent = (intent or '').strip()
        start_url = _normalize_url(start_url)
        actions: List[BrowserAction] = []
        warnings: List[str] = []
        if start_url:
            if self.is_allowed_url(start_url):
                actions.append(BrowserAction('open', start_url, 'Ouverture bornée de la page de départ'))
            else:
                warnings.append(f'URL hors périmètre autorisé: {start_url}')
        actions.append(BrowserAction('wait', 'networkidle', 'Stabiliser la page avant lecture'))
        if extract_targets:
            for target in extract_targets[: max(1, self.max_steps - len(actions) - 1)]:
                actions.append(BrowserAction('extract', str(target), f'Extraire la cible {target}'))
        else:
            actions.append(BrowserAction('extract', 'main_content', 'Extraire le contenu principal'))
        actions.append(BrowserAction('snapshot', 'dom_text', 'Créer une référence de snapshot textuelle'))
        actions = actions[: self.max_steps]
        return {
            'intent': intent,
            'start_url': start_url,
            'allowed_domains': self.allowed_domains,
            'dry_run': True,
            'actions': [a.as_dict() for a in actions],
            'warnings': warnings,
            'summary': f"Plan navigateur borné de {len(actions)} actions pour: {intent or 'intention non précisée'}",
        }
