"""stream_preview.py — aperçu compact d'un flux d'actions navigateur."""
from __future__ import annotations

from typing import Any, Dict, Iterable, List


class StreamPreviewBridge:
    def build_preview(self, actions: Iterable[Dict[str, Any]], snapshots: Iterable[Dict[str, Any]] | None = None) -> Dict[str, Any]:
        actions = list(actions or [])
        snapshots = list(snapshots or [])
        preview_lines: List[str] = []
        for idx, action in enumerate(actions[:8], start=1):
            preview_lines.append(f"{idx}. {action.get('action', 'unknown')} -> {action.get('value', '')}")
        if snapshots:
            preview_lines.append(f"snapshots: {', '.join(s.get('snapshot_ref', '?') for s in snapshots[:3])}")
        return {
            'steps': len(actions),
            'preview': '\n'.join(preview_lines) if preview_lines else 'Aucune action navigateur.',
        }
