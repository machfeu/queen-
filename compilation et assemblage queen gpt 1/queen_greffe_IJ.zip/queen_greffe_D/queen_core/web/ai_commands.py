"""ai_commands.py — commandes IA bornées pour future couche Playwright/HyperAgent."""
from __future__ import annotations

from typing import Any, Dict, List


class AiCommandExecutor:
    ALLOWED = {'page.ai', 'page.extract', 'executeTask'}

    def build(self, command: str, argument: str = '') -> Dict[str, Any]:
        command = str(command or '').strip()
        if command not in self.ALLOWED:
            return {'ok': False, 'error': f'Commande IA non autorisée: {command}'}
        return {'ok': True, 'command': command, 'argument': str(argument or '').strip(), 'mode': 'dry_run'}
