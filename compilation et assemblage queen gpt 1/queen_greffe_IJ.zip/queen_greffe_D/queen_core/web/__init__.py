"""Greffe I — primitives web/browser frugales pour Queen."""
