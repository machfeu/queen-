"""playwright_bridge.py — pont IA Playwright en mode sec."""
from __future__ import annotations

from typing import Any, Dict, List


class PlaywrightAiBridge:
    def execute_task(self, task: str, url: str = '', capabilities: List[str] | None = None) -> Dict[str, Any]:
        capabilities = list(capabilities or ['goto', 'locator', 'extract'])
        return {
            'mode': 'dry_run',
            'task': str(task or '').strip(),
            'url': url,
            'capabilities': capabilities,
            'summary': f'Plan Playwright AI sec prêt pour {task or "tâche non précisée"}',
        }
