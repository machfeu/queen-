"""extraction.py — extracteur structuré local et frugal pour résultats web."""
from __future__ import annotations

import re
from typing import Any, Dict, List


class StructuredResultExtractor:
    def extract(self, text: str, targets: List[str] | None = None) -> Dict[str, Any]:
        text = text or ''
        targets = [str(t).strip() for t in (targets or []) if str(t).strip()]
        findings = []
        lowered = text.lower()
        for target in targets:
            pattern = re.escape(target.lower())
            hit = bool(re.search(pattern, lowered))
            findings.append({'target': target, 'found': hit})
        return {
            'targets': targets,
            'findings': findings,
            'excerpt': text[:400],
            'summary': f'Extraction structurée sur {len(targets)} cible(s).',
        }
