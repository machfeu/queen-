"""intent_loop.py — transforme une intention en plan navigateur borné."""
from __future__ import annotations

from typing import Any, Dict, List

from queen_core.web.daemon_bridge import BrowserDaemonBridge


class IntentToBrowserPlan:
    def __init__(self, allowed_domains: List[str] | None = None, max_steps: int = 6):
        self.bridge = BrowserDaemonBridge(allowed_domains=allowed_domains, max_steps=max_steps)

    def build(self, intent: str, start_url: str = '', extract_targets: List[str] | None = None) -> Dict[str, Any]:
        return self.bridge.build_plan(intent=intent, start_url=start_url, extract_targets=extract_targets)


class WebAgentLoopAdapter:
    """Boucle web agent minimale: intention -> plan -> résumé exécutable plus tard."""

    def __init__(self, allowed_domains: List[str] | None = None, max_steps: int = 6):
        self.planner = IntentToBrowserPlan(allowed_domains=allowed_domains, max_steps=max_steps)

    def run(self, intent: str, start_url: str = '', extract_targets: List[str] | None = None) -> Dict[str, Any]:
        plan = self.planner.build(intent=intent, start_url=start_url, extract_targets=extract_targets)
        return {
            'plan': plan,
            'status': 'planned',
            'summary': plan.get('summary', 'Plan navigateur construit'),
        }
