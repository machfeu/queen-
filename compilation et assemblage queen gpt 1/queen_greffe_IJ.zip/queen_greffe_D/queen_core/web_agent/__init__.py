"""Greffe I — boucle web agent minimale."""
