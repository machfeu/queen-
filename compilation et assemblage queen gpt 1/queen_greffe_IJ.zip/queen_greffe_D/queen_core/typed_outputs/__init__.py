"""Greffe H — sorties typées frugales pour Queen."""

from .contracts import apply_typed_contract, validate_job_output_contract

__all__ = ["apply_typed_contract", "validate_job_output_contract"]
