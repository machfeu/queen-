"""Greffe G — télémétrie locale frugale pour Queen."""

from .trace_store import TraceStore

__all__ = ["TraceStore"]
