"""Greffe G — protocole MCP minimal pour Queen."""

from .protocol import (
    build_mcp_tool_manifest,
    build_filesystem_server_manifest,
    build_mcp_server_index,
)

__all__ = [
    "build_mcp_tool_manifest",
    "build_filesystem_server_manifest",
    "build_mcp_server_index",
]
