"""client_tools.py — manifeste d'outils client pour opérateur web local."""
from __future__ import annotations

from typing import Any, Dict, List


def build_browser_client_tool_manifest(read_only: bool = True) -> Dict[str, Any]:
    tools = [
        {'name': 'browser.open', 'description': 'Ouvre une URL bornée', 'read_only': read_only},
        {'name': 'browser.extract', 'description': 'Extrait du texte / DOM simplifié', 'read_only': read_only},
        {'name': 'browser.snapshot', 'description': 'Crée une référence de snapshot', 'read_only': True},
    ]
    return {
        'server_name': 'queen-browser-client-tools',
        'read_only': read_only,
        'tools': tools,
    }
