"""protocol.py — export MCP minimal et utile pour Queen.

Greffe G:
- ne tente pas d'implémenter tout MCP
- formalise un manifeste de serveurs / outils réutilisable plus tard
- évite d'introduire un service réseau avant le besoin réel
"""
from __future__ import annotations

from typing import Any, Dict, Optional

from queen_core.tool_registry import ToolRegistry, get_registry


def _tool_schema(tool: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Chemin relatif dans le workspace"},
            "content": {"type": "string", "description": "Contenu texte à écrire ou analyser"},
        },
        "additionalProperties": True,
    }


def build_mcp_tool_manifest(registry: Optional[ToolRegistry] = None) -> Dict[str, Any]:
    registry = registry or get_registry()
    tools = []
    for tool in registry.list_tools(enabled_only=True):
        tools.append({
            "name": tool["name"],
            "description": tool.get("description", ""),
            "risk_level": tool.get("risk_level", "medium"),
            "requires_approval": bool(tool.get("requires_approval", False)),
            "inputSchema": _tool_schema(tool),
            "metadata": {
                "category": tool.get("category", "general"),
                "sandbox": bool(tool.get("sandbox", True)),
                "allowed_extensions": tool.get("allowed_extensions", []),
                "blocked_patterns": tool.get("blocked_patterns", []),
            },
        })
    return {
        "protocol": "mcp-lite",
        "version": "0.1",
        "server_name": "queen-local-tools",
        "tools": tools,
    }


def build_filesystem_server_manifest(workspace_root: str = "/workspace", read_only: bool = True) -> Dict[str, Any]:
    capabilities = ["fs.list", "fs.read"] if read_only else ["fs.list", "fs.read", "fs.write"]
    return {
        "name": "filesystem_mcp",
        "protocol": "mcp-lite",
        "version": "0.1",
        "root": workspace_root,
        "read_only": bool(read_only),
        "permissions": {
            "workspace_only": True,
            "blocked_patterns": ["..", ".git", ".env"],
        },
        "capabilities": capabilities,
    }


def build_mcp_server_index(workspace_root: str = "/workspace") -> Dict[str, Any]:
    return {
        "protocol": "mcp-lite",
        "servers": [
            build_filesystem_server_manifest(workspace_root=workspace_root, read_only=True),
        ],
    }
