"""visual_planning.py — planificateur visuel frugal.

Inspire la greffe Midscene sans dépendance externe.
"""
from __future__ import annotations

from typing import Any, Dict, List


class VisualTaskPlanner:
    def build_plan(self, goal: str, targets: List[Dict[str, Any]] | None = None, max_steps: int = 8) -> Dict[str, Any]:
        targets = list(targets or [])
        actions: List[Dict[str, Any]] = []
        warnings: List[str] = []
        for item in targets[:max_steps]:
            label = str(item.get('label') or item.get('selector') or 'target')
            selector = str(item.get('selector') or '')
            if not selector and not item.get('bbox'):
                warnings.append(f'Cible sans selector/bbox: {label}')
                continue
            actions.append({
                'action': str(item.get('action') or 'inspect'),
                'selector': selector,
                'label': label,
                'confidence': float(item.get('confidence', 0.5) or 0.5),
            })
        if not actions:
            actions.append({'action': 'inspect', 'selector': '', 'label': 'viewport', 'confidence': 0.3})
        return {
            'goal': str(goal or '').strip(),
            'dry_run': True,
            'actions': actions,
            'warnings': warnings,
            'summary': f'Plan visuel borné de {len(actions)} actions pour {goal or "objectif non précisé"}',
        }
