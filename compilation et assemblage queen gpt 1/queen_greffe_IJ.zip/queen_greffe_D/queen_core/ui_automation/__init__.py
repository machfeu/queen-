"""Greffe I — planning visuel frugal pour UI operator."""
