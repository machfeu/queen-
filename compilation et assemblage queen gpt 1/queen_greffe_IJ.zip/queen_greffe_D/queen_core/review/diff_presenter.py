"""diff_presenter.py — lecture humaine et métriques de diff.
Greffe E / plug E2."""
from __future__ import annotations
from typing import Dict, List
SENSITIVE_HINTS=('.env','docker-compose','requirements','pyproject','setup.py','auth','security','policy','patcher','orchestrator')
def summarize_unified_diff(diff_text:str)->Dict[str,object]:
    files:List[Dict[str,object]]=[]; current=None; total_additions=0; total_deletions=0; hunk_count=0
    for raw_line in (diff_text or '').splitlines():
        line=raw_line.rstrip('\n')
        if line.startswith('+++ b/'):
            current={'path':line[6:].strip(),'additions':0,'deletions':0,'hunks':0,'warnings':[]}; files.append(current)
        elif line.startswith('@@'):
            hunk_count+=1
            if current is not None: current['hunks']=int(current.get('hunks',0))+1
        elif line.startswith('+') and not line.startswith('+++'):
            total_additions+=1
            if current is not None: current['additions']=int(current.get('additions',0))+1
        elif line.startswith('-') and not line.startswith('---'):
            total_deletions+=1
            if current is not None: current['deletions']=int(current.get('deletions',0))+1
    warnings=[]
    for entry in files:
        path=str(entry.get('path','')); lower=path.lower(); file_warnings=[]
        for hint in SENSITIVE_HINTS:
            if hint in lower: file_warnings.append(f'Sensitive surface touched: {hint}')
        if path.endswith(('.sh','.ps1','.bat')): file_warnings.append('Executable script touched')
        if file_warnings:
            entry['warnings']=file_warnings; warnings.extend(f"{path}: {w}" for w in file_warnings)
    changed_lines=total_additions+total_deletions; risk_level=_estimate_risk(len(files),changed_lines,warnings)
    lines=['=== Diff review (Greffe E) ===',f'Fichiers touchés: {len(files)}',f'Ajouts: {total_additions}',f'Suppressions: {total_deletions}',f'Hunks: {hunk_count}',f'Risque estimé: {risk_level}']
    for entry in files[:12]: lines.append(f"- {entry.get('path')} | +{entry.get('additions',0)} / -{entry.get('deletions',0)} | hunks={entry.get('hunks',0)}")
    if warnings: lines.append('Alertes: '+' | '.join(warnings[:8]))
    return {'files':files,'file_paths':[e.get('path') for e in files],'files_changed':len(files),'additions':total_additions,'deletions':total_deletions,'changed_lines':changed_lines,'hunks':hunk_count,'warnings':warnings[:20],'risk_level':risk_level,'summary_text':'\n'.join(lines)}
def _estimate_risk(files_changed:int,changed_lines:int,warnings:List[str])->str:
    score=0
    if files_changed>=8: score+=2
    elif files_changed>=4: score+=1
    if changed_lines>=250: score+=2
    elif changed_lines>=80: score+=1
    if warnings: score+=1
    return 'high' if score>=4 else ('medium' if score>=2 else 'low')
