"""patch_review.py — revue bornée avant application de patch.
Greffe E / plug E3."""
from __future__ import annotations
from typing import Any, Dict, List, Sequence
from queen_core.git.repo_map import RepoMapService
from queen_core.review.diff_presenter import summarize_unified_diff
MAX_REVIEW_FILES=8; MAX_REVIEW_LINES=280
def build_patch_review_report(artifacts:Sequence[Dict[str,Any]],diff_text:str,workspace_path:str,repo_context_meta:Dict[str,Any]|None=None)->Dict[str,Any]:
    diff_summary=summarize_unified_diff(diff_text); target_summary=RepoMapService(workspace_path).summarize_targets(diff_summary.get('file_paths',[]) or [])
    warnings=[]; blocking_reasons=[]
    if not diff_text.strip(): blocking_reasons.append('Patch vide: aucun diff exploitable à reviewer')
    if int(diff_summary.get('files_changed',0))>MAX_REVIEW_FILES: blocking_reasons.append(f"Patch trop large pour une revue bornée ({diff_summary.get('files_changed')} fichiers > {MAX_REVIEW_FILES})")
    if int(diff_summary.get('changed_lines',0))>MAX_REVIEW_LINES: blocking_reasons.append(f"Patch trop volumineux pour une revue sûre ({diff_summary.get('changed_lines')} lignes > {MAX_REVIEW_LINES})")
    warnings.extend(list(diff_summary.get('warnings',[])))
    rejected_artifacts=[art.get('path','<unknown>') for art in artifacts if art.get('rejected')]
    if rejected_artifacts: warnings.append('Artifacts rejetés avant patch: '+', '.join(str(p) for p in rejected_artifacts[:10]))
    focus_report=_compute_focus_report(diff_summary.get('file_paths',[]) or [], repo_context_meta or {}); warnings.extend(focus_report.get('warnings',[]))
    passed=not blocking_reasons; lines=['=== Patch review report (Greffe E) ===',f'passed={passed}',f"files_changed={diff_summary.get('files_changed',0)}",f"changed_lines={diff_summary.get('changed_lines',0)}",f"risk_level={diff_summary.get('risk_level','unknown')}"]
    if blocking_reasons: lines.append('Blocking: '+' | '.join(blocking_reasons))
    if warnings: lines.append('Warnings: '+' | '.join(warnings[:8]))
    return {'passed':passed,'blocking_reasons':blocking_reasons,'warnings':warnings[:20],'diff_summary':diff_summary,'target_summary':target_summary,'focus_report':focus_report,'summary_text':'\n'.join(lines)}
def _compute_focus_report(file_paths:Sequence[str],repo_context_meta:Dict[str,Any])->Dict[str,Any]:
    target_paths=[str(p) for p in file_paths if p]; top_paths=[str(p) for p in (repo_context_meta.get('top_paths') or []) if p]
    if not target_paths or not top_paths: return {'overlap':[],'warnings':[]}
    overlap=[]
    for target in target_paths:
        for suggested in top_paths:
            if target==suggested or target.endswith(suggested) or suggested.endswith(target): overlap.append(target); break
    warnings=[]
    if not overlap and len(target_paths)>=2: warnings.append("Le patch s'écarte du contexte repo ciblé: aucun overlap avec les top_paths")
    elif len(overlap)<max(1,min(2,len(target_paths)//2)) and len(target_paths)>=3: warnings.append('Le patch ne recoupe que faiblement les fichiers les plus probables')
    return {'top_paths':top_paths[:8],'target_paths':target_paths[:12],'overlap':overlap[:12],'warnings':warnings}
