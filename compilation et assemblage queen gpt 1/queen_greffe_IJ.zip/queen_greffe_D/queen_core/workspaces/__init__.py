"""Greffe E — providers de workspace frugaux."""
