"""provider.py — provider de workspace frugal pour Queen.
Greffe E / plug E4."""
from __future__ import annotations
import os
from typing import Dict
class WorkspaceProvider:
    def __init__(self, workspace_base:str='/workspace'): self.workspace_base=os.path.realpath(workspace_base)
    def ensure_goal_workspace(self, goal_id:str)->Dict[str,str]:
        safe_goal_id=str(goal_id or 'default').replace('..','_').replace('/','_').replace('\\','_')
        path=os.path.realpath(os.path.join(self.workspace_base,safe_goal_id)); os.makedirs(path,exist_ok=True)
        return {'goal_id':safe_goal_id,'workspace_path':path,'workspace_base':self.workspace_base}
