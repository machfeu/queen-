"""Greffe E — helpers git/repo map frugaux."""
