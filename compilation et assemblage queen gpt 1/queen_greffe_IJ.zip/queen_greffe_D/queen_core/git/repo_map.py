"""repo_map.py — cartographie frugale de dépôt pour l'action code.

Greffe E / plug E1.
Inspiré de la logique "repo map" d'Aider, mais volontairement locale,
sans dépendance git obligatoire ni service externe.
"""
from __future__ import annotations
import os
from collections import Counter
from dataclasses import dataclass
from typing import Dict, Iterable, List, Sequence
EXCLUDE_DIRS={'.git','__pycache__','.pytest_cache','.mypy_cache','.venv','venv','node_modules','dist','build'}
TEXT_EXTENSIONS={'.py','.md','.txt','.yaml','.yml','.json','.toml','.ini','.cfg','.sh','.sql','.html','.css'}
@dataclass
class RepoNode:
    path:str; kind:str; depth:int; size:int=0
class RepoMapService:
    def __init__(self, workspace_root:str, max_entries:int=120, max_depth:int=4):
        self.workspace_root=os.path.realpath(workspace_root); self.max_entries=max(10,int(max_entries)); self.max_depth=max(1,int(max_depth))
    def build_map(self)->Dict[str,object]:
        entries:List[RepoNode]=[]; dir_counter:Counter[str]=Counter(); file_count=0
        if not os.path.isdir(self.workspace_root):
            return {'workspace_root':self.workspace_root,'entries':[],'summary_text':'Workspace absent: aucune repo map disponible.','file_count':0,'top_directories':[]}
        for root,dirs,files in os.walk(self.workspace_root):
            dirs[:]=[d for d in dirs if d not in EXCLUDE_DIRS]
            rel_root=os.path.relpath(root,self.workspace_root); depth=0 if rel_root=='.' else rel_root.count(os.sep)+1
            if depth>self.max_depth: dirs[:]=[]; continue
            if rel_root!='.':
                entries.append(RepoNode(path=rel_root.replace('\\','/')+'/',kind='dir',depth=depth)); dir_counter[rel_root.split(os.sep)[0]]+=1
            for filename in files:
                ext=os.path.splitext(filename)[1].lower()
                if ext and ext not in TEXT_EXTENSIONS: continue
                full=os.path.join(root,filename)
                try: size=os.path.getsize(full)
                except OSError: size=0
                rel_path=os.path.relpath(full,self.workspace_root).replace('\\','/')
                entries.append(RepoNode(path=rel_path,kind='file',depth=depth+1,size=size)); file_count+=1
                if rel_root!='.': dir_counter[rel_root.split(os.sep)[0]]+=1
                if len(entries)>=self.max_entries: break
            if len(entries)>=self.max_entries: break
        return {'workspace_root':self.workspace_root,'entries':[e.__dict__ for e in entries[:self.max_entries]],'summary_text':_render_map(entries[:self.max_entries]),'file_count':file_count,'top_directories':[n for n,_ in dir_counter.most_common(8)]}
    def summarize_targets(self,target_paths:Sequence[str])->Dict[str,object]:
        normalized=[_normalize_path(p) for p in target_paths if p]
        if not normalized: return {'target_paths':[],'top_directories':[],'summary_text':'Aucun fichier ciblé par le patch.'}
        top_dirs=[p.split('/',1)[0] for p in normalized if '/' in p]; counts=Counter(top_dirs); lines=['=== Cibles patchées (Greffe E) ===']
        for path in normalized[:20]: lines.append(f'- {path}')
        if counts: lines.append('Répartition dossiers: '+', '.join(f'{n}:{c}' for n,c in counts.most_common(6)))
        return {'target_paths':normalized[:20],'top_directories':[n for n,_ in counts.most_common(6)],'summary_text':'\n'.join(lines)}
def build_repo_map(workspace_root:str,max_entries:int=120,max_depth:int=4)->Dict[str,object]: return RepoMapService(workspace_root,max_entries,max_depth).build_map()
def _render_map(entries:Iterable[RepoNode])->str:
    lines=['=== Repo map bornée (Greffe E) ===']; count=0
    for entry in entries:
        indent='  '*max(0,entry.depth-1); suffix='/' if entry.kind=='dir' and not entry.path.endswith('/') else ''; size=f' ({entry.size} o)' if entry.kind=='file' and entry.size else ''
        lines.append(f'{indent}- {entry.path}{suffix}{size}'); count+=1
        if count>=60: lines.append('... [repo map tronquée]'); break
    if count==0: lines.append('Aucune entrée lisible dans le workspace.')
    return '\n'.join(lines)
def _normalize_path(path:str)->str: return str(path).replace('\\','/').lstrip('/')
