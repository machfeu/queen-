"""
prompt_builder.py — Construction de prompts spécialisés par type de job.
Inspiré d'Emergent AI : chaque worker a un prompt adapté à sa spécialité,
enrichi du contexte des étapes précédentes (chaînage OpenManus).
"""

import json
import logging
from typing import Any, Dict, Tuple

logger = logging.getLogger("queen.prompt_builder")

SYSTEM_PROMPTS = {
    "research": (
        "Tu es un analyste de code senior. Tu examines du code source, "
        "identifies les patterns, les dépendances, les points faibles, "
        "et produis des analyses structurées. Tu es méthodique et exhaustif. "
        "Tu réponds UNIQUEMENT en JSON valide."
    ),
    "codegen": (
        "Tu es un développeur Python senior. Tu écris du code propre, "
        "documenté, typé, testé. Tu ne casses jamais le code existant. "
        "Tu suis les conventions du projet. Tu ne génères JAMAIS de code "
        "dangereux (eval, exec, subprocess, os.system). "
        "Tu réponds UNIQUEMENT en JSON valide."
    ),
    "test": (
        "Tu es un ingénieur qualité Python. Tu vérifies la syntaxe, "
        "la sécurité, la conformité du code. Tu identifies les risques "
        "et les régressions potentielles. Tu es rigoureux et exhaustif."
    ),
    "eval": (
        "Tu es un évaluateur de code expert. Tu juges la qualité globale "
        "d'un ensemble de modifications : lisibilité, maintenabilité, "
        "performance, sécurité, couverture de tests. Tu attribues un score "
        "entre 0 et 1 avec des justifications précises par critère. "
        "Tu réponds UNIQUEMENT en JSON valide."
    ),
    "patch": (
        "Tu es un intégrateur de code. Tu collectes les fichiers générés, "
        "produis un diff unifié propre, et vérifies que tout est cohérent "
        "avant l'intégration. Tu réponds UNIQUEMENT en JSON valide."
    ),
}

USER_TEMPLATES = {
    "research": """Analyse ce contexte pour un objectif d'amélioration de code:

Objectif: {goal_title}
Description: {goal_description}
Tâche spécifique: {description}

Contrat d'exécution:
{execution_contract}

Fichiers existants dans le workspace:
{existing_files}

Contexte repo ciblé:
{repo_context}

Mémoire durable utile:
{memory_context}

{previous_context}

Fournis une analyse structurée en JSON:
{{
  "analysis": "ton analyse détaillée",
  "findings": ["point 1", "point 2"],
  "recommendations": ["recommandation 1", "recommandation 2"],
  "files_to_modify": ["file1.py", "file2.py"],
  "risks": ["risque potentiel"],
  "summary": "résumé en 2 phrases"
}}""",

    "codegen": """Génère du code Python pour:

Objectif: {goal_title}
Tâche: {description}

Contrat d'exécution:
{execution_contract}

Contexte repo ciblé:
{repo_context}

Mémoire durable utile:
{memory_context}

Repo map bornée:
{repo_map}

{previous_context}

Règles:
- Code propre, commenté, typé
- Pas de subprocess, eval, exec, os.system
- Pas d'import de packages dangereux
- Fichiers dans le workspace uniquement
- Patch petit et ciblé: touche le moins de fichiers possible
- Diff lisible et réversible
- Respecte les handoffs et la QA attendue

Réponds en JSON:
{{
  "artifacts": [
    {{
      "path": "relative/path/file.py",
      "content": "# code complet ici...",
      "description": "ce que fait ce fichier"
    }}
  ],
  "summary": "résumé de ce qui a été généré"
}}""",

    "test": """Exécute la QA prévue par le contrat:

Objectif: {goal_title}
Tâche: {description}

Contrat d'exécution:
{execution_contract}

Contexte repo ciblé:
{repo_context}

Mémoire durable utile:
{memory_context}

{previous_context}

Vérifie en priorité:
- syntaxe
- sécurité
- cohérence du handoff
- conformité aux critères de succès

Réponds en JSON avec un booléen all_passed et un résumé.""",

    "eval": """Évalue la qualité de ces modifications:

Objectif: {goal_title}
Critères de succès: {success_criteria}

Contrat d'exécution:
{execution_contract}

Contexte repo ciblé:
{repo_context}

Mémoire durable utile:
{memory_context}

{previous_context}

Score chaque critère de 0 à 1 et donne un verdict global.
Réponds en JSON:
{{
  "score": 0.0,
  "criteria": {{
    "correctness": {{"score": 0.0, "reason": "..."}},
    "readability": {{"score": 0.0, "reason": "..."}},
    "security": {{"score": 0.0, "reason": "..."}},
    "testing": {{"score": 0.0, "reason": "..."}}
  }},
  "verdict": "approve|retry|reject",
  "justification": "explication globale"
}}""",

    "patch": """Collecte et prépare le patch final:

Objectif: {goal_title}

Contrat d'exécution:
{execution_contract}

Contexte repo ciblé:
{repo_context}

Mémoire durable utile:
{memory_context}

Repo map bornée:
{repo_map}

{previous_context}

Produis un résumé du patch en JSON:
{{
  "files_changed": ["file1.py", "file2.py"],
  "summary": "résumé des modifications",
  "breaking_changes": false,
  "notes": "remarques pour le reviewer"
}}""",
}


def _format_json_block(value: Any) -> str:
    if not value:
        return "Aucun"
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, indent=2, ensure_ascii=False, default=str)
    except Exception:
        return str(value)


def build_prompt(job: Dict[str, Any], role_name: str = "", extra_skills: str = "") -> Tuple[str, str]:
    job_type = job.get("job_type", "codegen")
    payload = job.get("payload", {})
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except Exception:
            payload = {}

    system = SYSTEM_PROMPTS.get(job_type, SYSTEM_PROMPTS["codegen"])

    if role_name:
        try:
            from queen_core.role_registry import get_role_registry
            role_reg = get_role_registry()
            role = role_reg.get(role_name)
            if role:
                role_prompt = role.build_system_prompt()
                system = f"{role_prompt}\n\n{system}"
                logger.debug("Enriched system prompt with role '%s'", role_name)
        except ImportError:
            pass

    if extra_skills:
        system += f"\n\n=== Connaissances disponibles ===\n{extra_skills}"

    template = USER_TEMPLATES.get(job_type, "")
    previous_context = payload.get("previous_context", "")
    if previous_context:
        previous_context = f"\n=== Contexte des étapes précédentes ===\n{previous_context}\n"

    existing_files = payload.get("existing_files", [])
    if isinstance(existing_files, list) and existing_files:
        existing_files_str = json.dumps(existing_files[:50], indent=2, ensure_ascii=False)
    else:
        existing_files_str = str(existing_files) if existing_files else "Aucun"

    execution_contract = _format_json_block(payload.get("execution_contract", {}))
    repo_context = _format_json_block(payload.get("repo_context", "") or "Aucun contexte repo ciblé.")
    repo_map = _format_json_block(payload.get("repo_map", "") or "Aucune repo map bornée.")
    memory_context = _format_json_block(payload.get("memory_context", "") or "Aucun souvenir durable utile.")

    if template:
        user = template.format(
            goal_title=payload.get("goal_title", ""),
            goal_description=payload.get("goal_description", ""),
            description=payload.get("description", ""),
            existing_files=existing_files_str,
            previous_context=previous_context,
            success_criteria=payload.get("success_criteria", ""),
            execution_contract=execution_contract,
            repo_context=repo_context,
            repo_map=repo_map,
            memory_context=memory_context,
        )
    else:
        user = (
            f"Tâche: {payload.get('description', '')}\n"
            f"Objectif: {payload.get('goal_title', '')}\n\n"
            f"Contrat d'exécution:\n{execution_contract}\n\n"
            f"{previous_context}\n\n"
            "Réponds en JSON."
        )

    return system, user


def load_skills_for_role(role_name: str) -> str:
    try:
        from queen_core.role_registry import get_role_registry
        from queen_core.skill_registry import get_skill_registry

        role_reg = get_role_registry()
        skill_reg = get_skill_registry()
        role = role_reg.get(role_name)
        if not role or not role.skills:
            return ""

        parts = []
        total_chars = 0
        max_chars = 6000
        for skill_name in role.skills:
            content = skill_reg.read_skill(skill_name)
            if content and total_chars + len(content) < max_chars:
                parts.append(f"--- Skill: {skill_name} ---\n{content}")
                total_chars += len(content)
                logger.debug("Loaded skill '%s' (%s chars)", skill_name, len(content))
        return "\n\n".join(parts)

    except ImportError:
        return ""
    except Exception as e:
        logger.warning("Failed to load skills for role %s: %s", role_name, e)
        return ""
