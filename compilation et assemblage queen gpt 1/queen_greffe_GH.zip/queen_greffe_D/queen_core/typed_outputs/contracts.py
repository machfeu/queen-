"""contracts.py — contrats de sortie typés, version stdlib et frugale.

Greffe H:
- apporte des contrats de sortie inspirés de PydanticAI sans dépendance externe
- normalise les résultats des jobs avant qu'ils ne circulent plus loin dans Queen
- reste permissif: on annote les erreurs au lieu de casser brutalement le pipeline
"""
from __future__ import annotations

from typing import Any, Dict, List, Tuple

_ALLOWED_VERDICTS = {"approve", "retry", "reject"}


def _as_str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    if isinstance(value, str):
        return value
    return str(value)


def _as_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "ok"}
    if isinstance(value, (int, float)):
        return bool(value)
    return default


def _as_list_of_str(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [_as_str(item).strip() for item in value if _as_str(item).strip()]
    if isinstance(value, str):
        stripped = value.strip()
        return [stripped] if stripped else []
    return [_as_str(value).strip()] if _as_str(value).strip() else []


def _clamp_score(value: Any) -> float:
    try:
        score = float(value)
    except Exception:
        return 0.0
    return max(0.0, min(score, 1.0))


def _normalize_artifacts(value: Any, errors: List[str]) -> List[Dict[str, Any]]:
    artifacts: List[Dict[str, Any]] = []
    if not isinstance(value, list):
        if value not in (None, ""):
            errors.append("artifacts_not_list")
        return artifacts
    for idx, item in enumerate(value):
        if not isinstance(item, dict):
            errors.append(f"artifact_{idx}_not_object")
            continue
        path = _as_str(item.get("path", "")).replace("\\", "/").lstrip("/")
        content = _as_str(item.get("content", ""))
        description = _as_str(item.get("description", ""))
        entry = dict(item)
        entry.update({"path": path, "content": content, "description": description})
        if not path:
            errors.append(f"artifact_{idx}_missing_path")
        if not content:
            errors.append(f"artifact_{idx}_missing_content")
        artifacts.append(entry)
    return artifacts


def _normalize_research(value: Dict[str, Any]) -> Dict[str, Any]:
    errors: List[str] = []
    normalized = {
        "analysis": _as_str(value.get("analysis", "")),
        "findings": _as_list_of_str(value.get("findings")),
        "recommendations": _as_list_of_str(value.get("recommendations")),
        "files_to_modify": _as_list_of_str(value.get("files_to_modify")),
        "risks": _as_list_of_str(value.get("risks")),
        "summary": _as_str(value.get("summary", "")),
    }
    if not normalized["analysis"]:
        errors.append("analysis_missing")
    if not normalized["summary"]:
        errors.append("summary_missing")
    return _annotate(normalized, "research", errors)


def _normalize_codegen(value: Dict[str, Any]) -> Dict[str, Any]:
    errors: List[str] = []
    normalized = dict(value)
    normalized["artifacts"] = _normalize_artifacts(value.get("artifacts"), errors)
    normalized["summary"] = _as_str(value.get("summary", ""))
    if not normalized["summary"]:
        errors.append("summary_missing")
    return _annotate(normalized, "codegen", errors)


def _normalize_eval(value: Dict[str, Any]) -> Dict[str, Any]:
    errors: List[str] = []
    verdict = _as_str(value.get("verdict", "retry")).lower()
    if verdict not in _ALLOWED_VERDICTS:
        errors.append("verdict_invalid")
        verdict = "retry"
    normalized = dict(value)
    normalized["score"] = _clamp_score(value.get("score", 0.0))
    normalized["verdict"] = verdict
    normalized["strengths"] = _as_list_of_str(value.get("strengths"))
    normalized["weaknesses"] = _as_list_of_str(value.get("weaknesses"))
    normalized.setdefault("criteria_scores", value.get("criteria_scores", {}))
    normalized.setdefault("justification", _as_str(value.get("justification", "")))
    return _annotate(normalized, "eval", errors)


def _normalize_patch(value: Dict[str, Any]) -> Dict[str, Any]:
    errors: List[str] = []
    normalized = dict(value)
    normalized["artifacts"] = _normalize_artifacts(value.get("artifacts"), errors)
    normalized["files_changed"] = _as_list_of_str(value.get("files_changed"))
    normalized["summary"] = _as_str(value.get("summary", ""))
    normalized["notes"] = _as_str(value.get("notes", ""))
    normalized["breaking_changes"] = _as_bool(value.get("breaking_changes", False))
    return _annotate(normalized, "patch", errors)


def _annotate(value: Dict[str, Any], schema_name: str, errors: List[str]) -> Dict[str, Any]:
    value["_schema"] = schema_name
    value["_schema_valid"] = len(errors) == 0
    value["_schema_errors"] = errors
    return value


def validate_job_output_contract(job_type: str, value: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(value, dict):
        value = {"raw": value}
    if job_type == "research":
        return _normalize_research(value)
    if job_type == "codegen":
        return _normalize_codegen(value)
    if job_type == "eval":
        return _normalize_eval(value)
    if job_type == "patch":
        return _normalize_patch(value)
    return _annotate(dict(value), job_type or "unknown", [])


def apply_typed_contract(job_type: str, value: Dict[str, Any]) -> Dict[str, Any]:
    """Alias explicite: applique un contrat de sortie frugal au résultat du job."""
    return validate_job_output_contract(job_type, value)
