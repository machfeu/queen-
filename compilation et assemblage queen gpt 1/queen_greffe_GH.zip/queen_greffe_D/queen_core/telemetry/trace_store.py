"""trace_store.py — traces locales frugales pour Queen.

Greffe G:
- remplace le besoin immédiat d'une stack d'observabilité lourde
- écrit des événements structurés en JSONL
- reste exploitable hors-ligne et facile à relire / archiver
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class TraceStore:
    def __init__(self, base_dir: str = "/data/traces"):
        self.base_dir = base_dir
        os.makedirs(base_dir, exist_ok=True)

    def new_trace_id(self, prefix: str = "trace") -> str:
        return f"{prefix}_{uuid.uuid4().hex[:10]}"

    def _trace_path(self, trace_id: str) -> str:
        return os.path.join(self.base_dir, f"{trace_id}.jsonl")

    def record_event(self, trace_id: str, event_type: str, payload: Dict[str, Any] | None = None) -> str:
        event = {
            "trace_id": trace_id,
            "event_type": event_type,
            "timestamp": _utc_now(),
            "payload": payload or {},
        }
        with open(self._trace_path(trace_id), "a", encoding="utf-8") as handle:
            handle.write(json.dumps(event, ensure_ascii=False) + "\n")
        return trace_id

    def read_events(self, trace_id: str) -> List[Dict[str, Any]]:
        path = self._trace_path(trace_id)
        if not os.path.exists(path):
            return []
        events: List[Dict[str, Any]] = []
        with open(path, "r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return events

    def summarize_trace(self, trace_id: str) -> Dict[str, Any]:
        events = self.read_events(trace_id)
        event_types = [event.get("event_type", "") for event in events]
        return {
            "trace_id": trace_id,
            "events": len(events),
            "event_types": event_types,
            "first_timestamp": events[0]["timestamp"] if events else "",
            "last_timestamp": events[-1]["timestamp"] if events else "",
        }
