# Suivi des greffes Queen

## Ligne directrice validée
1. stabilisation du tronc queen18 dans queen_multipart_fix
2. lot 1 ossature
3. lot 7 guardrails / évaluation
4. lot 8A sandboxing
5. lot 8B code intelligence
6. lot 3 action code
7. lot 2A formalisation moteur / états
8. lot 4 mémoire / traces / MCP utile
9. lot 6 sorties typées puis connaissance avancée
10. lots 5 et 10 browser / computer-use / UI operator
11. lot 9 orchestration externe / observabilité avancée

## État actuel
- Greffe A: réalisée et validée
- Greffe B: réalisée en version minimale exploitable
- Greffe C: amorcée avec un sandbox runner local générique
- Greffe D: réalisée en version minimale exploitable (code intelligence locale)

## Discipline de travail
- micro-greffes avec rollback simple
- commentaires dans le code quand la logique change
- un README par plug
- aucun remplacement brutal du cœur

## Dernière avancée
- contexte repo hybride injecté dans les jobs research/codegen
- index lexical local et recherche sémantique frugale ajoutés
- documentation Greffe D ajoutée avec rollback simple
