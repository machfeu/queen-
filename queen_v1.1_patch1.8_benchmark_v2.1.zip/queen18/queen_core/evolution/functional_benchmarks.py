"""
functional_benchmarks.py — Benchmarks that EXECUTE candidate code in a subprocess.

Unlike static benchmarks, these actually run Python against the candidate
to verify that Queen's modules work, not just that they parse.

Each benchmark runs in a subprocess with:
  - PYTHONPATH set to candidate_src
  - Timeout (default 15s)
  - Isolated from the main process

If the subprocess exits 0, the benchmark passes.
If it crashes or times out, the benchmark fails.
Partial scoring via stdout: print a float [0.0, 1.0] as the last line.
"""

from __future__ import annotations

import logging
import os
import subprocess
import time
from typing import Any, Dict, List, Tuple

logger = logging.getLogger("queen.evolution.benchmark")

FUNCTIONAL_TIMEOUT = 15  # seconds per benchmark


def _run_python_check(candidate_src: str, code: str, timeout: int = FUNCTIONAL_TIMEOUT) -> float:
    """Run a Python snippet in a subprocess with candidate_src on PYTHONPATH.
    Returns the score (0.0-1.0) printed by the snippet, or 0.0 on failure."""
    env = dict(os.environ)
    env["PYTHONPATH"] = candidate_src + (
        ":" + env.get("PYTHONPATH", "") if env.get("PYTHONPATH") else ""
    )
    # Don't let candidate code access Redis/DB/network
    env["REDIS_URL"] = ""
    env["QUEEN_FUNCTIONAL_BENCH"] = "1"

    try:
        proc = subprocess.run(
            ["python3", "-c", code],
            env=env,
            cwd=candidate_src,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            text=True,
        )
        if proc.returncode != 0:
            logger.debug(f"Functional bench failed (rc={proc.returncode}): {proc.stderr[:500]}")
            return 0.0

        # Try to read score from last line of stdout
        lines = proc.stdout.strip().splitlines()
        if lines:
            try:
                score = float(lines[-1])
                return max(0.0, min(1.0, score))
            except ValueError:
                pass
        # If no score printed but exit 0, it's a pass
        return 1.0

    except subprocess.TimeoutExpired:
        logger.debug(f"Functional bench timed out after {timeout}s")
        return 0.0
    except Exception as e:
        logger.debug(f"Functional bench error: {e}")
        return 0.0


# ═══════════════════════════════════════════════════════════════════════
# Scenario 1: Core module import + basic instantiation
# ═══════════════════════════════════════════════════════════════════════

_SCENARIO_IMPORT = """
import sys
score = 0.0
total = 5

# 1. Import queen_core
try:
    import queen_core
    score += 1
except Exception:
    pass

# 2. Import models and create a Goal
try:
    from queen_core.models import Goal, Run, Job, Patch
    g = Goal(title="bench test", description="functional benchmark")
    assert g.id.startswith("goal_")
    assert g.title == "bench test"
    score += 1
except Exception:
    pass

# 3. Import policy and validate constraints
try:
    from queen_core.policy import validate_goal_constraints
    c = validate_goal_constraints({"risk_level": "high", "timeout": 60})
    assert c["risk_level"] == "high"
    assert c["timeout"] == 60
    score += 1
except Exception:
    pass

# 4. Import patcher and generate a diff
try:
    from queen_core.patcher import generate_diff
    diff = generate_diff("/nonexistent", "hello\\n", filename="test.py")
    assert "+hello" in diff
    score += 1
except Exception:
    pass

# 5. Import tool_registry
try:
    from queen_core.tool_registry import ToolDef
    t = ToolDef({"name": "bench_tool", "description": "test", "timeout_seconds": 30})
    errs = t.validate()
    assert len(errs) == 0
    score += 1
except Exception:
    pass

print(score / total)
"""


# ═══════════════════════════════════════════════════════════════════════
# Scenario 2: Policy round-trip — constraints in, validated out
# ═══════════════════════════════════════════════════════════════════════

_SCENARIO_POLICY = """
score = 0.0
total = 4

# 1. Default constraints
try:
    from queen_core.policy import validate_goal_constraints
    c = validate_goal_constraints({})
    assert "timeout" in c
    assert "risk_level" in c
    assert c["require_manual_approval"] is True
    score += 1
except Exception:
    pass

# 2. Risk level normalization
try:
    from queen_core.policy import validate_goal_constraints
    c = validate_goal_constraints({"risk_level": "INVALID"})
    assert c["risk_level"] == "medium"  # fallback
    score += 1
except Exception:
    pass

# 3. Timeout clamping
try:
    from queen_core.policy import validate_goal_constraints, MAX_JOB_TIMEOUT
    c = validate_goal_constraints({"timeout": 999999})
    assert c["timeout"] <= MAX_JOB_TIMEOUT
    score += 1
except Exception:
    pass

# 4. Code safety check
try:
    from queen_core.policy import check_code_safety
    safe, violations = check_code_safety("x = 1\\nprint(x)")
    assert safe is True
    assert len(violations) == 0
    unsafe, v2 = check_code_safety("os.system('rm -rf /')")
    assert unsafe is False
    score += 1
except Exception:
    pass

print(score / total)
"""


# ═══════════════════════════════════════════════════════════════════════
# Scenario 3: Patcher round-trip — generate diff, apply, verify
# ═══════════════════════════════════════════════════════════════════════

_SCENARIO_PATCHER = """
import os, tempfile, shutil

score = 0.0
total = 3
tmpdir = tempfile.mkdtemp()

try:
    workspace = os.path.join(tmpdir, "ws")
    os.makedirs(workspace)

    # Need to override WORKSPACE_BASE for validation
    import queen_core.policy as pol
    import queen_core.patcher as pat
    old_pol = pol.WORKSPACE_BASE
    old_pat = pat.WORKSPACE_BASE
    pol.WORKSPACE_BASE = workspace
    pat.WORKSPACE_BASE = workspace

    # 1. Write original file
    orig = "# original\\nprint(1)\\n"
    with open(os.path.join(workspace, "test.py"), "w") as f:
        f.write(orig)
    score += 0.5  # file created

    # 2. Generate diff
    diff = pat.generate_diff(os.path.join(workspace, "test.py"), "# modified\\nprint(2)\\n", filename="test.py")
    if "+# modified" in diff and "-# original" in diff:
        score += 0.5

    # 3. Apply patch
    result = pat.apply_patch(diff, workspace)
    if result.get("applied"):
        with open(os.path.join(workspace, "test.py")) as f:
            content = f.read()
        if "modified" in content:
            score += 1.0

    # 4. Rollback
    backup_dir = result.get("backup_dir", "")
    if backup_dir and os.path.isdir(backup_dir):
        pat.rollback(backup_dir, workspace)
        with open(os.path.join(workspace, "test.py")) as f:
            content = f.read()
        if "original" in content:
            score += 1.0

    pol.WORKSPACE_BASE = old_pol
    pat.WORKSPACE_BASE = old_pat
except Exception as e:
    import sys
    print(f"Error: {e}", file=sys.stderr)

shutil.rmtree(tmpdir, ignore_errors=True)
print(score / total)
"""


def bench_core_imports(candidate_src: str) -> float:
    """Functional: import core modules, instantiate key classes."""
    return _run_python_check(candidate_src, _SCENARIO_IMPORT)


def bench_policy_roundtrip(candidate_src: str) -> float:
    """Functional: validate constraints, check code safety."""
    return _run_python_check(candidate_src, _SCENARIO_POLICY)


def bench_patcher_roundtrip(candidate_src: str) -> float:
    """Functional: generate diff, apply, rollback."""
    return _run_python_check(candidate_src, _SCENARIO_PATCHER)


# ═══════════════════════════════════════════════════════════════════════
# Scenario 4 (v2.1): Memory CRUD round-trip — mini Queen workflow
# ═══════════════════════════════════════════════════════════════════════

_SCENARIO_MEMORY_CRUD = """
import os, sys, tempfile, shutil
score = 0.0
total = 6
tmpdir = tempfile.mkdtemp()
db_path = os.path.join(tmpdir, "bench.db")

try:
    from queen_core.models import Goal, Run, Job, Patch, init_db
    from queen_core.memory import Memory

    # 1. Init DB via migrations
    conn = init_db(db_path)
    conn.close()
    score += 1

    # 2. Create Memory + Goal
    mem = Memory(db_path)
    g = Goal(title="bench goal", description="test CRUD")
    mem.create_goal(g)
    fetched = mem.get_goal(g.id)
    assert fetched is not None
    assert fetched["title"] == "bench goal"
    score += 1

    # 3. Create Run linked to Goal
    r = Run(goal_id=g.id)
    mem.create_run(r)
    fetched_r = mem.get_run(r.id)
    assert fetched_r is not None
    assert fetched_r["goal_id"] == g.id
    score += 1

    # 4. Create Job linked to Run
    j = Job(run_id=r.id, goal_id=g.id, job_type="test")
    mem.create_job(j)
    jobs = mem.list_jobs(run_id=r.id)
    assert len(jobs) == 1
    score += 1

    # 5. Update statuses
    mem.update_goal_status(g.id, "completed")
    mem.update_run(r.id, status="applied")
    mem.update_job(j.id, status="success")
    updated_g = mem.get_goal(g.id)
    assert updated_g["status"] == "completed"
    score += 1

    # 6. Stats coherent
    stats = mem.get_stats()
    assert stats["goals_total"] >= 1
    assert stats["runs_total"] >= 1
    assert stats["jobs_total"] >= 1
    score += 1

except Exception as e:
    print(f"Error: {e}", file=sys.stderr)

shutil.rmtree(tmpdir, ignore_errors=True)
print(score / total)
"""


# ═══════════════════════════════════════════════════════════════════════
# Scenario 5 (v2.1): Migration idempotence — create, migrate, insert, re-migrate
# ═══════════════════════════════════════════════════════════════════════

_SCENARIO_MIGRATION = """
import os, sys, tempfile, shutil, sqlite3
score = 0.0
total = 4
tmpdir = tempfile.mkdtemp()
db_path = os.path.join(tmpdir, "bench_mig.db")

try:
    from queen_core.migrations import run_migrations, get_schema_info

    # 1. First migration on empty DB
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    applied = run_migrations(conn)
    assert applied >= 2
    score += 1

    # 2. Schema info correct
    info = get_schema_info(conn)
    assert info["current_version"] >= 2
    score += 1

    # 3. Insert data
    conn.execute("INSERT INTO goals (id, title, created_at, updated_at) VALUES ('g1', 'test', '2025', '2025')")
    conn.commit()
    row = conn.execute("SELECT title FROM goals WHERE id='g1'").fetchone()
    assert row[0] == "test"
    score += 1

    # 4. Re-migrate is idempotent — data survives
    applied2 = run_migrations(conn)
    assert applied2 == 0  # nothing new to apply
    row2 = conn.execute("SELECT title FROM goals WHERE id='g1'").fetchone()
    assert row2[0] == "test"
    score += 1

    conn.close()

except Exception as e:
    print(f"Error: {e}", file=sys.stderr)

shutil.rmtree(tmpdir, ignore_errors=True)
print(score / total)
"""


def bench_memory_crud(candidate_src: str) -> float:
    """Functional: full Goal→Run→Job CRUD round-trip on temp SQLite DB."""
    return _run_python_check(candidate_src, _SCENARIO_MEMORY_CRUD)


def bench_migration_idempotence(candidate_src: str) -> float:
    """Functional: migrations on empty DB, insert data, re-migrate, data survives."""
    return _run_python_check(candidate_src, _SCENARIO_MIGRATION)


FUNCTIONAL_BENCHMARKS: List[Tuple[str, "BenchmarkFn"]] = [
    ("functional:core_imports", bench_core_imports),
    ("functional:policy_roundtrip", bench_policy_roundtrip),
    ("functional:patcher_roundtrip", bench_patcher_roundtrip),
    ("functional:memory_crud", bench_memory_crud),
    ("functional:migration_idempotence", bench_migration_idempotence),
]

# Type alias (same as static_benchmarks)
from typing import Callable
BenchmarkFn = Callable[[str], float]
