"""
bench_runner.py — Orchestrates static and functional benchmarks.

Benchmark v2: clear separation between static analysis (fast, safe, no execution)
and functional tests (subprocess, timeout, actual execution).

Score computation:
  - static_score:     average of static benchmarks     (weight: 0.35)
  - functional_score: average of functional benchmarks  (weight: 0.65)
  - benchmark_score:  weighted combination

The functional benchmarks weigh more because they prove the code WORKS,
not just that it LOOKS OK.
"""

from __future__ import annotations

import importlib.util
import logging
import os
import time
from typing import Any, Callable, Dict, List, Tuple

from .static_benchmarks import STATIC_BENCHMARKS
from .functional_benchmarks import FUNCTIONAL_BENCHMARKS

logger = logging.getLogger("queen.evolution.benchmark")

BenchmarkFn = Callable[[str], float]

W_STATIC = 0.35
W_FUNCTIONAL = 0.65


def _discover_user_benchmarks(benchmarks_dir: str) -> List[Tuple[str, BenchmarkFn]]:
    """Load bench_* functions from .py files in benchmarks_dir."""
    found: List[Tuple[str, BenchmarkFn]] = []
    if not os.path.isdir(benchmarks_dir):
        return found
    for fn in sorted(os.listdir(benchmarks_dir)):
        if not fn.endswith(".py") or fn.startswith("_"):
            continue
        path = os.path.join(benchmarks_dir, fn)
        try:
            spec = importlib.util.spec_from_file_location(f"bench_{fn[:-3]}", path)
            if not spec or not spec.loader:
                continue
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            for name in dir(mod):
                if name.startswith("bench_") and callable(getattr(mod, name)):
                    found.append((f"user:{fn}::{name}", getattr(mod, name)))
        except Exception as e:
            logger.warning(f"Failed to load benchmark file {fn}: {e}")
    return found


def _run_one(name: str, fn: BenchmarkFn, candidate_src: str) -> Dict[str, Any]:
    """Run a single benchmark with timing. Catches all exceptions."""
    t0 = time.time()
    try:
        score = fn(candidate_src)
        score = max(0.0, min(1.0, float(score)))
        elapsed = time.time() - t0
        return {"score": score, "time_s": round(elapsed, 3), "error": None}
    except Exception as e:
        elapsed = time.time() - t0
        logger.warning(f"Benchmark {name} failed: {e}")
        return {"score": 0.0, "time_s": round(elapsed, 3), "error": str(e)}


def run_benchmarks(
    candidate_src: str,
    benchmarks_dir: str = "",
) -> Dict[str, Any]:
    """
    Run all benchmarks (static + functional + user) against a candidate.

    Returns:
        {
            "benchmark_score": float,           # weighted aggregate 0.0-1.0
            "static_score": float,              # average of static benchmarks
            "functional_score": float,          # average of functional benchmarks
            "benchmark_count": int,
            "static_count": int,
            "functional_count": int,
            "benchmark_results": {name: {"score", "time_s", "error"}},
        }
    """
    # Static benchmarks
    static_results: Dict[str, Dict[str, Any]] = {}
    static_scores: List[float] = []
    for name, fn in STATIC_BENCHMARKS:
        r = _run_one(name, fn, candidate_src)
        static_results[name] = r
        static_scores.append(r["score"])

    # Functional benchmarks
    functional_results: Dict[str, Dict[str, Any]] = {}
    functional_scores: List[float] = []
    for name, fn in FUNCTIONAL_BENCHMARKS:
        r = _run_one(name, fn, candidate_src)
        functional_results[name] = r
        functional_scores.append(r["score"])

    # User benchmarks (treated as static — no subprocess isolation guarantee)
    user_benchmarks = _discover_user_benchmarks(benchmarks_dir) if benchmarks_dir else []
    for name, fn in user_benchmarks:
        r = _run_one(name, fn, candidate_src)
        static_results[name] = r
        static_scores.append(r["score"])

    # Compute aggregates
    static_avg = sum(static_scores) / len(static_scores) if static_scores else 0.0
    functional_avg = sum(functional_scores) / len(functional_scores) if functional_scores else 0.0

    # Weighted aggregate
    if functional_scores and static_scores:
        benchmark_score = W_STATIC * static_avg + W_FUNCTIONAL * functional_avg
    elif functional_scores:
        benchmark_score = functional_avg
    elif static_scores:
        benchmark_score = static_avg
    else:
        benchmark_score = 0.0

    all_results = {**static_results, **functional_results}

    return {
        "benchmark_score": round(benchmark_score, 4),
        "static_score": round(static_avg, 4),
        "functional_score": round(functional_avg, 4),
        "benchmark_count": len(all_results),
        "static_count": len(static_scores),
        "functional_count": len(functional_scores),
        "benchmark_results": all_results,
    }
