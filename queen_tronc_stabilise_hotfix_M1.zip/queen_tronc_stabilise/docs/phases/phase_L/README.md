# README — Phase L / tests E2E

## Rôle
Cette phase ne greffe pas de nouvelle capacité métier. Elle **stresse le tronc consolidé** avec des scénarios représentatifs.

## Fichier principal
- `test_phase_L_e2e.py`

## Ancien état
Avant cette phase, le dépôt possédait surtout :
- des tests unitaires de greffes A→J
- des validations locales par brique
- une consolidation Phase K

## Amélioration apportée
Après cette phase, le dépôt possède aussi :
- une validation du pipeline complet happy path
- une validation du blocage guardrails avant dispatch
- une validation d'un run browser borné sans patch
- une validation de la réutilisation mémoire
- une validation de l'audit des transitions d'état incohérentes

## Bugs rencontrés
- dépendance `redis` absente au moment d'importer `workers.worker_unified` dans la campagne locale

## Correctif appliqué
- injection d'un stub `redis` minimal dans le harnais de test
- aucun changement du code runtime de Queen

## Rollback
Pour annuler la Phase L, il suffit de retirer :
- `test_phase_L_e2e.py`
- `PHASE_L_E2E.md`
- `TEST_REPORT_PHASE_L.md`
- `docs/phases/phase_L/`
