# Plug A5 — QA gate autoritaire

## Version antérieure
- la QA n’était pas une barrière explicite avant patch

## Améliorations apportées
- gate `qa_pending` et contrôle avant patch

## Bugs rencontrés
- un `codegen` pouvait pousser trop vite vers patch

## Fixes appliqués
- validation orchestrateur avant autorisation de patch

## Fichiers touchés
- `queen_core/orchestrator.py`

## Rollback simple
- retirer les modifications de ce plug et relancer les tests ciblés de Greffe A
