# Plug A1 — Mission contract partagé

## Version antérieure
- aucune source unique de contrat de mission
- plan potentiellement incomplet ou ambigu

## Améliorations apportées
- normalisation des plans
- complétion des métadonnées d'exécution
- chaîne terminale `eval -> patch` forcée

## Bugs rencontrés
- fallback de plan fragile
- quoting défectueux corrigé pendant la greffe A

## Fixes appliqués
- helpers de normalisation dédiés
- fallback texte sécurisé
- tests unitaires dédiés

## Fichiers touchés
- `queen_core/mission_contract.py`

## Rollback simple
- retirer les modifications de ce plug et relancer les tests ciblés de Greffe A
