# Plug A4 — Contrat injecté dans les prompts

## Version antérieure
- workers peu guidés par un cadre d’exécution commun

## Améliorations apportées
- contexte d’exécution visible directement dans les prompts

## Bugs rencontrés
- risque de dérive de rôle et de sortie

## Fixes appliqués
- section contrat mission ajoutée au prompt builder

## Fichiers touchés
- `queen_core/prompt_builder.py`

## Rollback simple
- retirer les modifications de ce plug et relancer les tests ciblés de Greffe A
