# Plug A6 — Statuts de run enrichis

## Version antérieure
- statuts trop grossiers pour auditer finement le pipeline

## Améliorations apportées
- statuts `planning`, `dispatching`, `evaluating`, `qa_pending` ajoutés

## Bugs rencontrés
- visibilité limitée sur les phases réelles du run

## Fixes appliqués
- champs alignés sur le flux de greffe A

## Fichiers touchés
- `queen_core/models.py`

## Rollback simple
- retirer les modifications de ce plug et relancer les tests ciblés de Greffe A
