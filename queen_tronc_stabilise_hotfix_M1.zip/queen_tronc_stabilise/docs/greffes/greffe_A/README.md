# Greffe A — Ossature, contrat de mission et QA gate

## Source et intention
- Source lot : lot 1 ossature
- Tronc hôte : `queen18` issu de `queen_multipart_fix`
- Approche choisie : structurer le flux existant sans remplacer l'orchestrateur ni le pipeline historique

## Version antérieure
- planification encore trop implicite
- handoffs entre jobs partiellement déduits
- absence d'un contrat de mission partagé entre planner, orchestrateur et workers
- pas de QA gate explicite et obligatoire avant la génération du patch

## Améliorations apportées
- contrat de mission partagé ajouté
- normalisation des plans avant exécution
- handoffs explicites basés sur `depends_on`
- injection du contrat directement dans les prompts workers
- QA gate autoritaire avant patch
- enrichissement des statuts de run

## Bugs rencontrés
- plans partiels ou mal formés
- ambiguïté sur la chaîne terminale `eval -> patch`
- flux pouvant autoriser un patch trop tôt

## Fixes appliqués
- normalisation et complétion automatique du plan
- séquence terminale forcée
- test QA injecté après les étapes `codegen`
- contrôle final au niveau orchestrateur avant patch

## Fichiers touchés
- `queen_core/mission_contract.py`
- `queen_core/planner.py`
- `queen_core/job_chain.py`
- `queen_core/prompt_builder.py`
- `queen_core/orchestrator.py`
- `queen_core/models.py`
- `test_mission_contract.py`

## Validation
- compilation Python locale
- `pytest -q test_mission_contract.py test_version_1b.py`

## Rollback simple
- retirer `queen_core/mission_contract.py`
- retirer les points d'appel dans planner/job_chain/prompt_builder/orchestrator/models
- supprimer `test_mission_contract.py`
