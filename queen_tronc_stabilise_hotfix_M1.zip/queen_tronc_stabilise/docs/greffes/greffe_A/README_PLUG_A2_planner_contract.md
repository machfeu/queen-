# Plug A2 — Planner branché sur le contrat

## Version antérieure
- le planner produisait un plan sans contrat partagé

## Améliorations apportées
- sortie planner normalisée avant exécution

## Bugs rencontrés
- écarts de structure entre plan LLM et attentes orchestrateur

## Fixes appliqués
- appel systématique au normaliseur de contrat

## Fichiers touchés
- `queen_core/planner.py`

## Rollback simple
- retirer les modifications de ce plug et relancer les tests ciblés de Greffe A
