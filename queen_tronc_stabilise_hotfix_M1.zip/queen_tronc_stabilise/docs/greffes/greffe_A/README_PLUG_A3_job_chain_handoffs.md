# Plug A3 — Handoffs explicites

## Version antérieure
- transmission de contexte trop implicite

## Améliorations apportées
- `depends_on` pris comme source prioritaire du contexte

## Bugs rencontrés
- chaînage inter-jobs peu lisible

## Fixes appliqués
- handoffs dérivés des dépendances réelles

## Fichiers touchés
- `queen_core/job_chain.py`

## Rollback simple
- retirer les modifications de ce plug et relancer les tests ciblés de Greffe A
