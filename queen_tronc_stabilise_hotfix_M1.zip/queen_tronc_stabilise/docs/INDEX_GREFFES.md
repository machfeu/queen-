# Index des greffes Queen

## Tronc consolidé
- Base hôte : `queen18` issu de `queen_multipart_fix`
- Ligne directrice : micro-greffes A → J, puis consolidation du tronc
- État : tronc unifié, nettoyé, testable localement

## Greffes disponibles
- `greffe_A` — README présent
- `greffe_B` — README présent
- `greffe_C` — README présent
- `greffe_D` — README présent
- `greffe_E` — README présent
- `greffe_F` — README présent
- `greffe_G` — README présent
- `greffe_H` — README présent
- `greffe_I` — README présent
- `greffe_J` — README présent

## Notes racine disponibles
- `GREFFE_A_NOTES.md`
- `GREFFE_B_NOTES.md`
- `GREFFE_C_NOTES.md`
- `GREFFE_D_NOTES.md`
- `GREFFE_E_NOTES.md`
- `GREFFE_F_NOTES.md`
- `GREFFE_G_NOTES.md`
- `GREFFE_H_NOTES.md`
- `GREFFE_I_NOTES.md`
- `GREFFE_J_NOTES.md`

## Règles de travail conservées
- pas de remplacement brutal du cœur
- rollback simple par micro-greffe
- commentaires dans le code quand la logique change
- README par plug et par greffe
