"""Tests Greffe F — transitions d'état frugales."""
from __future__ import annotations

import os
import shutil
import tempfile

from queen_core.memory import Memory
from queen_core.models import Goal, Run, Patch, GoalStatus, RunStatus, PatchStatus
from queen_core.runtime.state_machine import validate_transition, update_status_guarded


def test_validate_transition_accepts_expected_path():
    report = validate_transition("run", "planning", "dispatching")
    assert report["allowed"] is True
    print("PASS: test_validate_transition_accepts_expected_path")


def test_validate_transition_flags_unexpected_jump():
    report = validate_transition("goal", "pending", "completed")
    assert report["allowed"] is False and "transition_not_allowed" in report["reason"]
    print("PASS: test_validate_transition_flags_unexpected_jump")


def test_update_status_guarded_updates_and_audits_warning():
    tmpdir = tempfile.mkdtemp()
    try:
        mem = Memory(os.path.join(tmpdir, "queen.db"))
        goal = Goal(id="goal_sm", title="Goal SM")
        mem.create_goal(goal)
        run = Run(id="run_sm", goal_id=goal.id, status=RunStatus.PLANNING.value)
        mem.create_run(run)
        patch = Patch(id="patch_sm", run_id=run.id, goal_id=goal.id, status=PatchStatus.GENERATED.value)
        mem.create_patch(patch)

        rep_goal = update_status_guarded(mem, "goal", goal.id, GoalStatus.PLANNING.value)
        rep_run = update_status_guarded(mem, "run", run.id, RunStatus.GATES_PASSED.value)
        rep_patch = update_status_guarded(mem, "patch", patch.id, PatchStatus.GATES_RUNNING.value)

        assert rep_goal["applied"] is True
        assert rep_run["applied"] is False
        assert rep_patch["applied"] is True
        assert mem.get_goal(goal.id)["status"] == GoalStatus.PLANNING.value
        assert mem.get_run(run.id)["status"] == RunStatus.PLANNING.value
        assert mem.get_patch(patch.id)["status"] == PatchStatus.GATES_RUNNING.value

        audits = mem.list_audit(entity_type="run", entity_id=run.id)
        assert any(a.get("action") == "state_transition_blocked" for a in audits)
        print("PASS: test_update_status_guarded_updates_and_audits_warning")
    finally:
        shutil.rmtree(tmpdir)


if __name__ == "__main__":
    test_validate_transition_accepts_expected_path()
    test_validate_transition_flags_unexpected_jump()
    test_update_status_guarded_updates_and_audits_warning()
    print("All Greffe F tests passed")
