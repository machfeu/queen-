import os

from queen_core.memory import Memory
from queen_core.models import Goal, Run, Patch, GoalStatus, RunStatus, PatchStatus
from queen_core.runtime.sandbox_runner import _safe_output
from queen_core.runtime.state_machine import update_status_guarded
from queen_core.patcher import generate_diff, _parse_unified_diff


def test_generate_diff_uses_standard_context(tmp_path):
    original = tmp_path / "demo.txt"
    original.write_text("".join(f"line{i}\n" for i in range(20)), encoding="utf-8")
    new_lines = [f"line{i}\n" for i in range(20)]
    new_lines[10] = "CHANGED\n"
    diff = generate_diff(str(original), "".join(new_lines), filename="demo.txt")
    hunks = [line for line in diff.splitlines() if line.startswith("@@")]
    assert hunks
    assert hunks[0] == "@@ -8,7 +8,7 @@"


def test_parse_unified_diff_ignores_malformed_context_line():
    diff = """--- a/demo.txt
+++ b/demo.txt
@@ -1 +1 @@
 line ok
MALFORMED_CONTEXT
+new
"""
    changes = _parse_unified_diff(diff)
    assert changes
    assert "MALFORMED_CONTEXT" not in changes[0]["new_content"]
    assert "line ok" in changes[0]["new_content"]


def test_apply_patch_atomic_persists_backup_dir(tmp_path):
    db_path = tmp_path / "queen.db"
    mem = Memory(str(db_path))
    goal = Goal(title="g", status=GoalStatus.RUNNING.value)
    run = Run(goal_id=goal.id, status=RunStatus.APPROVED.value)
    patch = Patch(run_id=run.id, goal_id=goal.id, status=PatchStatus.APPROVED.value)
    mem.create_goal(goal)
    mem.create_run(run)
    mem.create_patch(patch)
    mem.apply_patch_atomic(patch.id, run.id, goal.id, now="2026-03-12T00:00:00+00:00", backup_dir="/tmp/backup_1")
    saved = mem.get_patch(patch.id)
    assert saved["backup_dir"] == "/tmp/backup_1"


def test_safe_output_decodes_bytes():
    assert _safe_output("café".encode("utf-8")) == "café"


def test_invalid_transition_is_blocked(tmp_path):
    db_path = tmp_path / "queen.db"
    mem = Memory(str(db_path))
    goal = Goal(title="g", status=GoalStatus.RUNNING.value)
    mem.create_goal(goal)
    report = update_status_guarded(mem, "goal", goal.id, GoalStatus.PENDING.value)
    assert report["allowed"] is False
    assert report["applied"] is False
    assert mem.get_goal(goal.id)["status"] == GoalStatus.RUNNING.value


def test_memory_connections_are_wal_ready(tmp_path):
    from queen_core.memories.long_term_store import LongTermMemoryStore

    db_path = tmp_path / "queen.db"
    mem = Memory(str(db_path))
    ltm = LongTermMemoryStore(str(db_path))
    journal1 = mem.conn.execute("PRAGMA journal_mode").fetchone()[0]
    journal2 = ltm.conn.execute("PRAGMA journal_mode").fetchone()[0]
    assert str(journal1).lower() == "wal"
    assert str(journal2).lower() == "wal"
