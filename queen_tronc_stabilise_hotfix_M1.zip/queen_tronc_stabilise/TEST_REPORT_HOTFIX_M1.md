# TEST REPORT — HOTFIX M1

## Objet
Validation des correctifs issus de l'audit croisé sur le tronc consolidé.

## Campagnes exécutées
- `pytest -q test_hotfix_claude_findings.py test_phase_L_e2e.py test_version_1b.py test_action_code_minimal.py test_state_machine_minimal.py`
- `pytest -q test_mission_contract.py test_guardrails_minimal.py test_codeintel_minimal.py test_action_code_minimal.py test_state_machine_minimal.py test_memory_trace_mcp_minimal.py test_typed_outputs_minimal.py test_browser_operator_minimal.py test_orchestration_observability_minimal.py test_phase_L_e2e.py test_hotfix_claude_findings.py test_version_1b.py`

## Résultats
- campagne ciblée: **29 tests passés**
- campagne élargie: **56 tests passés**

## Points confirmés
- bug rollback confirmé et corrigé
- bug contexte diff confirmé et corrigé
- bug parse diff permissif confirmé et corrigé
- bug `python` vs `sys.executable` confirmé et corrigé
- risque SQLite dual-connection confirmé et atténué par WAL/busy_timeout
- robustesse timeout sandbox améliorée
- state machine reformatée + transitions invalides désormais bloquées par défaut

## Point rejeté comme faux positif
- Les jobs `browser` et `ui_operator` sont bien persistés via la boucle de résultats de l'orchestrateur (`pop_result -> memory.update_job(...)`).
