"""state_machine.py — formalisation frugale des transitions d'état.
Greffe F / lot 2A minimal.

Hotfix: fichier reformaté pour maintenance + blocage explicite des
transitions interdites, sauf si force_transition=True est demandé.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Mapping

logger = logging.getLogger("queen.state_machine")

RUN_TRANSITIONS: Mapping[str, set[str]] = {
    "planning": {"rails_blocked", "dispatching", "gates_failed"},
    "rails_blocked": set(),
    "dispatching": {"running", "rejected", "gates_failed"},
    "running": {"evaluating", "rejected", "gates_failed"},
    "evaluating": {"qa_pending", "gates_failed", "rejected", "gates_passed"},
    "qa_pending": {"gates_pending", "gates_failed", "gates_passed"},
    "gates_pending": {"gates_passed", "gates_failed", "approved"},
    "gates_passed": {"approved", "applied", "gates_failed"},
    "approved": {"applied", "rolled_back", "rejected"},
    "applied": {"rolled_back"},
    "gates_failed": set(),
    "rejected": set(),
    "rolled_back": set(),
}

GOAL_TRANSITIONS: Mapping[str, set[str]] = {
    "pending": {"planning", "paused", "failed"},
    "planning": {"running", "failed", "paused"},
    "running": {"paused", "completed", "failed"},
    "paused": {"running", "failed"},
    "completed": set(),
    "failed": set(),
}

PATCH_TRANSITIONS: Mapping[str, set[str]] = {
    "generated": {"gates_running", "rejected"},
    "gates_running": {"gates_passed", "gates_failed"},
    "gates_passed": {"approved", "rejected", "applied"},
    "approved": {"applied", "rolled_back", "rejected"},
    "applied": {"rolled_back"},
    "gates_failed": set(),
    "rejected": set(),
    "rolled_back": set(),
}

JOB_TRANSITIONS: Mapping[str, set[str]] = {
    "queued": {"running", "cancelled", "failed", "timeout", "success"},
    "running": {"success", "failed", "timeout", "cancelled"},
    "success": set(),
    "failed": {"queued", "cancelled"},
    "timeout": {"queued", "cancelled"},
    "cancelled": set(),
}

TRANSITION_TABLES = {
    "run": RUN_TRANSITIONS,
    "goal": GOAL_TRANSITIONS,
    "patch": PATCH_TRANSITIONS,
    "job": JOB_TRANSITIONS,
}


def validate_transition(kind: str, current_status: str, target_status: str) -> Dict[str, Any]:
    table = TRANSITION_TABLES.get(kind, {})
    current = str(current_status or "")
    target = str(target_status or "")

    if not current:
        return {
            "allowed": True,
            "reason": "unknown_current_status",
            "kind": kind,
            "from": current,
            "to": target,
        }
    if current == target:
        return {
            "allowed": True,
            "reason": "idempotent",
            "kind": kind,
            "from": current,
            "to": target,
        }

    allowed_targets = table.get(current)
    if allowed_targets is None:
        return {
            "allowed": True,
            "reason": "untracked_current_status",
            "kind": kind,
            "from": current,
            "to": target,
        }

    allowed = target in allowed_targets
    return {
        "allowed": allowed,
        "reason": "ok" if allowed else f"transition_not_allowed:{current}->{target}",
        "kind": kind,
        "from": current,
        "to": target,
        "allowed_targets": sorted(allowed_targets),
    }


def update_status_guarded(memory: Any, kind: str, entity_id: str, target_status: str, **extra_fields: Any) -> Dict[str, Any]:
    getter_name = {
        "run": "get_run",
        "goal": "get_goal",
        "patch": "get_patch",
        "job": "get_job",
    }[kind]
    current_obj = getattr(memory, getter_name)(entity_id)
    current_status = (current_obj or {}).get("status", "")
    force_transition = bool(extra_fields.pop("force_transition", False))

    report = validate_transition(kind, current_status, target_status)
    report["applied"] = False

    if not report.get("allowed", True):
        logger.warning("State transition blocked for %s %s: %s", kind, entity_id, report)
        try:
            memory.audit("state_transition_blocked", kind, entity_id, details=report)
        except Exception:
            pass
        if not force_transition:
            return report
        report["forced"] = True

    if kind == "goal":
        memory.update_goal_status(entity_id, target_status)
    elif kind == "run":
        memory.update_run(entity_id, status=target_status, **extra_fields)
    elif kind == "patch":
        memory.update_patch(entity_id, status=target_status, **extra_fields)
    elif kind == "job":
        memory.update_job(entity_id, status=target_status, **extra_fields)

    report["applied"] = True
    return report
