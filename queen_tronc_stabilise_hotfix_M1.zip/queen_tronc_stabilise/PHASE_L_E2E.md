# Phase L — Campagne E2E du tronc consolidé

## Objectif
Valider le tronc Queen consolidé sur des **scénarios bout en bout** qui traversent réellement le pipeline, au lieu de se limiter aux tests unitaires des greffes A→J.

## Ce qui a été ajouté
- `test_phase_L_e2e.py`
- `TEST_REPORT_PHASE_L.md`
- `docs/phases/phase_L/README.md`

## Scénarios couverts
1. **Happy path complet**
   - `goal -> plan -> jobs -> eval -> patch -> approve -> apply`
   - vérifie le diff, les gates, l'écriture workspace, les traces et la mémoire durable

2. **Blocage guardrails avant dispatch**
   - vérifie qu'une demande douteuse est stoppée avant création des jobs
   - vérifie le statut `rails_blocked`, la trace dédiée et la mémoire de blocage

3. **Run browser borné sans patch**
   - vérifie qu'un run navigateur utile peut finir proprement sans artefacts codegen
   - vérifie que le tronc ne force pas un patch vide

4. **Réutilisation mémoire sur run suivant**
   - vérifie qu'un résultat durable peut être retrouvé et réinjecté dans le contexte de travail ultérieur

5. **Audit d'une transition d'état incohérente**
   - vérifie que la machine d'état n'est pas silencieuse quand un saut de statut est douteux

## Choix de design
- pas de Redis réel
- pas de LLM réel
- pas de navigateur réel
- stubs locaux pour tester le **tronc** et non l'infrastructure externe

## Résultat
- campagne Phase L : **5 scénarios E2E passés**
- non-régression ciblée relancée : **50 tests passés**

## Limite honnête
La Phase L ne remplace pas encore une campagne Docker distribuée complète avec Redis, workers séparés et vraies intégrations navigateur / orchestration. Elle valide le tronc logique local et son comportement de pipeline.
