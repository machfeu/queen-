# Hotfix M1 ajouté le 2026-03-12

- rollback ciblé par `patch.backup_dir`
- parsing diff durci (`n=3`, lignes malformées ignorées)
- worker `py_compile` via `sys.executable`
- `LongTermMemoryStore` aligné WAL/busy_timeout
- sandbox timeout stdout/stderr robuste
- state machine reformatée + transitions interdites bloquées par défaut
- faux positif écarté: résultats `browser` / `ui_operator` déjà persistés côté orchestrateur

# Suivi des greffes Queen

## Ligne directrice validée
1. stabilisation du tronc queen18 dans queen_multipart_fix
2. lot 1 ossature
3. lot 7 guardrails / évaluation
4. lot 8A sandboxing
5. lot 8B code intelligence
6. lot 3 action code
7. lot 2A formalisation moteur / états
8. lot 4 mémoire / traces / MCP utile
9. lot 6 sorties typées puis connaissance avancée
10. lots 5 et 10 browser / computer-use / UI operator
11. lot 9 orchestration externe / observabilité avancée

## État actuel
- Greffe A: réalisée et validée
- Greffe B: réalisée en version minimale exploitable
- Greffe C: amorcée avec un sandbox runner local générique
- Greffe D: réalisée en version minimale exploitable (code intelligence locale)
- Greffe E: réalisée en version bornée exploitable (repo map + diff review + workspace provider)
- Greffe F: réalisée en version minimale exploitable (tables de transitions + audit doux)
- Greffe G: réalisée en version minimale utile (mémoire durable + traces locales + MCP lite)
- Greffe H: réalisée en version minimale utile (sorties typées frugales, GraphRAG reporté)
- Greffe I: réalisée en version minimale utile (browser/operator bornés, client tools locaux, vrai navigateur reporté)
- Greffe J: réalisée en version minimale utile (manifestes orchestration + exports observabilité, intégrations externes reportées)

## Discipline de travail
- micro-greffes avec rollback simple
- commentaires dans le code quand la logique change
- un README par plug
- aucun remplacement brutal du cœur

## Dernière avancée
- contexte repo hybride injecté dans les jobs research/codegen
- index lexical local et recherche sémantique frugale ajoutés
- documentation Greffe D ajoutée avec rollback simple
- revue de diff branchée dans les gates avec README Greffe E
- transitions d'état explicites et auditées avec README Greffe F

- mémoire durable SQLite locale ajoutée et injectée dans les prompts
- traces JSONL locales ajoutées par run
- manifeste MCP lite et connecteur filesystem borné ajoutés
- contrats de sortie typés ajoutés sur research/codegen/eval/patch

- couche browser/operator frugale ajoutée avec plan navigateur sec
- snapshots textuels, aperçu de flux et manifeste client browser ajoutés
- planificateur visuel borné ajouté pour UI operator
- manifestes Prefect / Dapr / Dagger ajoutés en sortie purement locale
- exports Helicone / LangWatch / AgentNeo construits depuis les traces locales

## Phase K — Consolidation du tronc
- archive A→J unifiée dans un tronc unique
- caches Python et pytest retirés
- artefact `dashboard.zip` retiré de la racine car redondant avec `dashboard/`
- index des greffes ajouté
- documentation Greffe A complétée
- validation locale relancée : 45 tests passés

## Phase L — Tests E2E du tronc
- campagne E2E ajoutée via `test_phase_L_e2e.py`
- happy path complet validé jusqu'à `approve/apply`
- blocage guardrails pré-dispatch validé
- run browser borné sans patch validé
- réutilisation mémoire durable validée
- audit des transitions d'état incohérentes validé
- non-régression relancée : 50 tests passés
