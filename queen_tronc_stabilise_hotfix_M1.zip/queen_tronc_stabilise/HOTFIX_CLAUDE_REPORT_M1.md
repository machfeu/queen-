# HOTFIX M1 — audit croisé des bugs remontés

Cette passe corrige en priorité les défauts à plus fort impact signalés pendant l'audit croisé:
- rollback ciblant le mauvais backup
- parsing/apply de diff trop permissif
- invocation Python non portable dans les workers
- seconde connexion SQLite sans pragmas WAL/busy timeout
- sortie timeout sandbox robuste
- state machine reformattée + transitions invalides bloquées par défaut

## Correctifs appliqués
- `patches.backup_dir` ajouté au schéma et persisté au moment du `apply_patch`
- `rollback_patch()` utilise désormais le `backup_dir` du patch
- `patcher.generate_diff()` repasse à `n=3`
- `_parse_unified_diff()` ignore désormais les lignes de contexte mal formées au lieu de les injecter
- `worker_unified.py` utilise `sys.executable`
- `LongTermMemoryStore` active WAL / busy_timeout
- `sandbox_runner` décode proprement `stdout/stderr` même en bytes
- `state_machine.py` reformaté et `update_status_guarded()` bloque les transitions interdites, sauf forçage explicite

## Point non retenu comme bug confirmé
- Les handlers `browser` et `ui_operator` sont bien persistés côté orchestrateur via la boucle générale `pop_result -> memory.update_job(...)`.

## Compatibilité
- Les anciens patches sans `backup_dir` gardent un fallback legacy sur le dernier backup global.
- Les transitions invalides peuvent encore être forcées via `force_transition=True` si un cas legacy l'exige.
