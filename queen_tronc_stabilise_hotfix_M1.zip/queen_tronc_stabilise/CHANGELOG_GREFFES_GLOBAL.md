# Changelog global des greffes

## Phase K — Consolidation du tronc stabilisé
- unification du dépôt greffé A → J
- nettoyage des artefacts de travail (`__pycache__`, `.pytest_cache`, `.pyc`)
- suppression de l'archive redondante `dashboard.zip`
- ajout de la documentation manquante de Greffe A
- ajout d'un index global des greffes
- ajout d'un README racine de synthèse pour le tronc stabilisé
- validation locale par la suite de tests ciblés A → J

## Greffe A — Ossature
- contrat de mission partagé
- normalisation des plans
- QA gate autoritaire
- statuts de run enrichis

## Greffe B — Guardrails / évaluation minimale
- moteur de guardrails simple
- scénarios offensifs déclaratifs
- précheck avant dispatch

## Greffe C — Sandboxing minimal
- sandbox runner local générique
- smoke import subprocess
- filtration de variables sensibles

## Greffe D — Code intelligence minimale
- index lexical local
- recherche sémantique frugale
- contexte repo hybride dans les prompts

## Greffe E — Action code bornée
- repo map frugale
- revue structurée de diff
- gate `diff_review`
- workspace provider explicite

## Greffe F — Formalisation moteur / états minimale
- tables de transitions
- audit des sauts d'état incohérents
- intégration douce dans orchestrator / actions

## Greffe G — Mémoire / traces / MCP lite
- mémoire durable locale
- traces JSONL par run
- manifeste MCP minimal et connecteur filesystem borné

## Greffe H — Sorties typées minimales
- contrats de sortie research / codegen / eval / patch
- validation structurée frugale

## Greffe I — Browser / UI operator bornés
- plans navigateur et visuel en dry-run
- snapshots textuels
- manifeste client browser minimal

## Greffe J — Orchestration / observabilité externes minimales
- manifestes Prefect / Dapr / Dagger
- exports Helicone / LangWatch / AgentNeo
- aucun appel réseau ni dépendance externe branchée
